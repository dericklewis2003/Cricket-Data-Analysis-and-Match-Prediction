import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Search, Trophy, User, Target, BarChart3, UserPlus, RefreshCw, ChevronDown, Activity, Award } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { cricketDataService, type PlayerInfo } from "@/services/cricket-data-api";

const Players: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [searchInputValue, setSearchInputValue] = useState("");
  const [selectedPlayer, setSelectedPlayer] = useState<string | null>(null);

  // Handle search form submission
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setSearchQuery(searchInputValue);
    setSelectedPlayer(null);
  };

  // Query for player search
  const playerSearchQuery = useQuery({
    queryKey: ['/api/cricket/players/search', searchQuery],
    queryFn: () => cricketDataService.searchPlayer(searchQuery),
    staleTime: 5 * 60 * 1000, // 5 minutes
    refetchOnWindowFocus: false,
    enabled: searchQuery !== "",
  });

  // Query for player details
  const playerDetailsQuery = useQuery({
    queryKey: ['/api/cricket/players', selectedPlayer],
    queryFn: () => cricketDataService.getPlayerDetails(selectedPlayer!),
    staleTime: 5 * 60 * 1000, // 5 minutes
    refetchOnWindowFocus: false,
    enabled: selectedPlayer !== null,
  });

  // Handle player selection
  const handlePlayerSelect = (playerId: string) => {
    setSelectedPlayer(playerId);
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-800 dark:text-white mb-2">Player Profiles</h1>
          <p className="text-gray-600 dark:text-gray-300">
            Search and view detailed cricket player statistics
          </p>
        </div>
        
        <form onSubmit={handleSearch} className="flex w-full md:w-auto">
          <div className="relative flex-grow">
            <Input
              type="text"
              placeholder="Search players..."
              className="w-full pr-10"
              value={searchInputValue}
              onChange={(e) => setSearchInputValue(e.target.value)}
            />
            <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          </div>
          <Button type="submit" className="ml-2">Search</Button>
        </form>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Search Results Panel */}
        <div className="md:col-span-1">
          <Card className="h-full">
            <CardHeader>
              <CardTitle className="flex items-center">
                <UserPlus className="mr-2 h-5 w-5" />
                Player Search
              </CardTitle>
            </CardHeader>
            <CardContent>
              {!searchQuery ? (
                <div className="text-center py-8">
                  <p className="text-gray-500">Enter a player name to search</p>
                </div>
              ) : playerSearchQuery.isPending ? (
                <SearchResultsSkeleton />
              ) : playerSearchQuery.isError ? (
                <div className="text-center py-8">
                  <p className="text-red-500 mb-4">Failed to search players. Please try again later.</p>
                  <Button 
                    onClick={() => playerSearchQuery.refetch()}
                    variant="outline"
                    size="sm"
                  >
                    <RefreshCw className="mr-2 h-4 w-4" />
                    Try Again
                  </Button>
                </div>
              ) : playerSearchQuery.data?.length === 0 ? (
                <div className="text-center py-8">
                  <p className="text-gray-500">No players found matching "{searchQuery}"</p>
                </div>
              ) : (
                <ScrollArea className="h-[600px] pr-4">
                  <div className="space-y-3">
                    {playerSearchQuery.data?.map((player) => (
                      <div 
                        key={player.id}
                        className={`p-3 rounded-lg cursor-pointer transition-colors ${
                          selectedPlayer === player.id 
                            ? 'bg-primary/10 border border-primary/30' 
                            : 'bg-gray-50 dark:bg-gray-800 hover:bg-gray-100 dark:hover:bg-gray-700'
                        }`}
                        onClick={() => handlePlayerSelect(player.id)}
                      >
                        <div className="flex items-center">
                          {player.playerImg ? (
                            <img 
                              src={player.playerImg} 
                              alt={player.name} 
                              className="w-10 h-10 rounded-full mr-3 object-cover"
                            />
                          ) : (
                            <div className="w-10 h-10 rounded-full mr-3 bg-gray-200 dark:bg-gray-700 flex items-center justify-center">
                              <User className="h-5 w-5 text-gray-500 dark:text-gray-400" />
                            </div>
                          )}
                          <div>
                            <p className="font-medium text-gray-800 dark:text-white">{player.name}</p>
                            <div className="flex items-center mt-1">
                              <Badge variant="outline" className="text-xs">
                                {player.country || "International"}
                              </Badge>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Player Details Panel */}
        <div className="md:col-span-2">
          <Card className="h-full">
            {!selectedPlayer ? (
              <div className="flex flex-col items-center justify-center h-full py-12 px-4 text-center">
                <User className="h-16 w-16 text-gray-300 dark:text-gray-600 mb-4" />
                <h3 className="text-xl font-medium text-gray-700 dark:text-gray-300 mb-2">No Player Selected</h3>
                <p className="text-gray-500 dark:text-gray-400 max-w-md">
                  Search for a player and select from the results to view their detailed statistics
                </p>
              </div>
            ) : playerDetailsQuery.isPending ? (
              <PlayerDetailsSkeleton />
            ) : playerDetailsQuery.isError ? (
              <div className="flex flex-col items-center justify-center h-full py-12 px-4 text-center">
                <p className="text-red-500 mb-4">Failed to load player details. Please try again later.</p>
                <Button 
                  onClick={() => playerDetailsQuery.refetch()}
                  variant="outline"
                >
                  <RefreshCw className="mr-2 h-4 w-4" />
                  Try Again
                </Button>
              </div>
            ) : (
              <PlayerDetails player={playerDetailsQuery.data} />
            )}
          </Card>
        </div>
      </div>
    </div>
  );
};

interface PlayerDetailsProps {
  player: PlayerInfo;
}

const PlayerDetails: React.FC<PlayerDetailsProps> = ({ player }) => {
  return (
    <>
      <CardHeader className="border-b">
        <div className="flex flex-col md:flex-row md:items-center">
          <div className="flex-shrink-0 mb-4 md:mb-0 md:mr-6">
            {player.playerImg ? (
              <img 
                src={player.playerImg} 
                alt={player.name} 
                className="w-24 h-24 rounded-full object-cover border-4 border-white dark:border-gray-800 shadow-lg"
              />
            ) : (
              <div className="w-24 h-24 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center border-4 border-white dark:border-gray-800 shadow-lg">
                <User className="h-12 w-12 text-gray-500 dark:text-gray-400" />
              </div>
            )}
          </div>
          
          <div>
            <CardTitle className="text-2xl mb-2">{player.name}</CardTitle>
            <div className="flex flex-wrap gap-2 mb-3">
              <Badge variant="secondary" className="flex items-center">
                <Trophy className="mr-1 h-3 w-3" />
                {player.country || "International"}
              </Badge>
              
              {player.battingStyle && (
                <Badge variant="outline" className="flex items-center">
                  <Activity className="mr-1 h-3 w-3" />
                  {player.battingStyle}
                </Badge>
              )}
              
              {player.bowlingStyle && (
                <Badge variant="outline" className="flex items-center">
                  <Award className="mr-1 h-3 w-3" />
                  {player.bowlingStyle}
                </Badge>
              )}
            </div>
            
            <div className="text-sm text-gray-500 dark:text-gray-400">
              {player.name} is a cricket player from {player.country || "International cricket"}.
              {player.battingStyle && player.bowlingStyle && ` Known for ${player.battingStyle.toLowerCase()} batting and ${player.bowlingStyle.toLowerCase()} bowling.`}
            </div>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="pt-6">
        <Tabs defaultValue="batting" className="w-full">
          <TabsList className="mb-6 w-full justify-start">
            <TabsTrigger value="batting" className="flex items-center">
              <Activity className="mr-2 h-4 w-4" />
              Batting
            </TabsTrigger>
            <TabsTrigger value="bowling" className="flex items-center">
              <Award className="mr-2 h-4 w-4" />
              Bowling
            </TabsTrigger>
            <TabsTrigger value="career" className="flex items-center">
              <BarChart3 className="mr-2 h-4 w-4" />
              Career
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="batting">
            <Accordion type="single" collapsible className="w-full">
              {player.stats?.batting && Object.keys(player.stats.batting).map((format) => (
                <AccordionItem value={`batting-${format}`} key={`batting-${format}`}>
                  <AccordionTrigger className="text-lg font-medium">
                    {format.toUpperCase()} Batting Statistics
                  </AccordionTrigger>
                  <AccordionContent>
                    <div className="overflow-x-auto">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Matches</TableHead>
                            <TableHead>Innings</TableHead>
                            <TableHead>Runs</TableHead>
                            <TableHead>Highest</TableHead>
                            <TableHead>Average</TableHead>
                            <TableHead>Strike Rate</TableHead>
                            <TableHead>100s</TableHead>
                            <TableHead>50s</TableHead>
                            <TableHead>4s</TableHead>
                            <TableHead>6s</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          <TableRow>
                            <TableCell>{player.stats.batting[format].matches}</TableCell>
                            <TableCell>{player.stats.batting[format].innings}</TableCell>
                            <TableCell className="font-medium">{player.stats.batting[format].runs}</TableCell>
                            <TableCell>{player.stats.batting[format].highest}</TableCell>
                            <TableCell>{player.stats.batting[format].average.toFixed(2)}</TableCell>
                            <TableCell>{player.stats.batting[format].strikeRate.toFixed(2)}</TableCell>
                            <TableCell>{player.stats.batting[format].hundreds}</TableCell>
                            <TableCell>{player.stats.batting[format].fifties}</TableCell>
                            <TableCell>{player.stats.batting[format].fours}</TableCell>
                            <TableCell>{player.stats.batting[format].sixes}</TableCell>
                          </TableRow>
                        </TableBody>
                      </Table>
                    </div>
                  </AccordionContent>
                </AccordionItem>
              ))}
              
              {(!player.stats?.batting || Object.keys(player.stats.batting).length === 0) && (
                <div className="text-center py-6">
                  <p className="text-gray-500">No batting statistics available</p>
                </div>
              )}
            </Accordion>
          </TabsContent>
          
          <TabsContent value="bowling">
            <Accordion type="single" collapsible className="w-full">
              {player.stats?.bowling && Object.keys(player.stats.bowling).map((format) => (
                <AccordionItem value={`bowling-${format}`} key={`bowling-${format}`}>
                  <AccordionTrigger className="text-lg font-medium">
                    {format.toUpperCase()} Bowling Statistics
                  </AccordionTrigger>
                  <AccordionContent>
                    <div className="overflow-x-auto">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Matches</TableHead>
                            <TableHead>Innings</TableHead>
                            <TableHead>Overs</TableHead>
                            <TableHead>Runs</TableHead>
                            <TableHead>Wickets</TableHead>
                            <TableHead>Economy</TableHead>
                            <TableHead>Average</TableHead>
                            <TableHead>Strike Rate</TableHead>
                            <TableHead>Best (Inning)</TableHead>
                            <TableHead>Best (Match)</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          <TableRow>
                            <TableCell>{player.stats.bowling[format].matches}</TableCell>
                            <TableCell>{player.stats.bowling[format].innings}</TableCell>
                            <TableCell>{player.stats.bowling[format].overs}</TableCell>
                            <TableCell>{player.stats.bowling[format].runs}</TableCell>
                            <TableCell className="font-medium">{player.stats.bowling[format].wickets}</TableCell>
                            <TableCell>{player.stats.bowling[format].economy.toFixed(2)}</TableCell>
                            <TableCell>{player.stats.bowling[format].average.toFixed(2)}</TableCell>
                            <TableCell>{player.stats.bowling[format].strikeRate.toFixed(2)}</TableCell>
                            <TableCell>{player.stats.bowling[format].bestInning}</TableCell>
                            <TableCell>{player.stats.bowling[format].bestMatch}</TableCell>
                          </TableRow>
                        </TableBody>
                      </Table>
                    </div>
                  </AccordionContent>
                </AccordionItem>
              ))}
              
              {(!player.stats?.bowling || Object.keys(player.stats.bowling).length === 0) && (
                <div className="text-center py-6">
                  <p className="text-gray-500">No bowling statistics available</p>
                </div>
              )}
            </Accordion>
          </TabsContent>
          
          <TabsContent value="career">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Batting Career Highlights</CardTitle>
                </CardHeader>
                <CardContent>
                  {player.stats?.batting && Object.keys(player.stats.batting).length > 0 ? (
                    <div className="space-y-4">
                      <div className="flex justify-between">
                        <span className="text-gray-600 dark:text-gray-400">Total Runs</span>
                        <span className="font-medium">
                          {Object.values(player.stats.batting).reduce((sum, stat) => sum + stat.runs, 0)}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600 dark:text-gray-400">Highest Score</span>
                        <span className="font-medium">
                          {Math.max(...Object.values(player.stats.batting).map(stat => stat.highest))}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600 dark:text-gray-400">Centuries</span>
                        <span className="font-medium">
                          {Object.values(player.stats.batting).reduce((sum, stat) => sum + stat.hundreds, 0)}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600 dark:text-gray-400">Half Centuries</span>
                        <span className="font-medium">
                          {Object.values(player.stats.batting).reduce((sum, stat) => sum + stat.fifties, 0)}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600 dark:text-gray-400">Sixes</span>
                        <span className="font-medium">
                          {Object.values(player.stats.batting).reduce((sum, stat) => sum + stat.sixes, 0)}
                        </span>
                      </div>
                    </div>
                  ) : (
                    <p className="text-gray-500 text-center">No batting data available</p>
                  )}
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Bowling Career Highlights</CardTitle>
                </CardHeader>
                <CardContent>
                  {player.stats?.bowling && Object.keys(player.stats.bowling).length > 0 ? (
                    <div className="space-y-4">
                      <div className="flex justify-between">
                        <span className="text-gray-600 dark:text-gray-400">Total Wickets</span>
                        <span className="font-medium">
                          {Object.values(player.stats.bowling).reduce((sum, stat) => sum + stat.wickets, 0)}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600 dark:text-gray-400">Best Bowling</span>
                        <span className="font-medium">
                          {Object.values(player.stats.bowling).map(stat => stat.bestInning).sort()[0]}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600 dark:text-gray-400">Average Economy</span>
                        <span className="font-medium">
                          {(Object.values(player.stats.bowling).reduce((sum, stat) => sum + stat.economy, 0) / 
                            Object.values(player.stats.bowling).length).toFixed(2)}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600 dark:text-gray-400">Total Overs</span>
                        <span className="font-medium">
                          {Object.values(player.stats.bowling).reduce((sum, stat) => sum + stat.overs, 0)}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600 dark:text-gray-400">Total Matches</span>
                        <span className="font-medium">
                          {Object.values(player.stats.bowling).reduce((sum, stat) => sum + stat.matches, 0)}
                        </span>
                      </div>
                    </div>
                  ) : (
                    <p className="text-gray-500 text-center">No bowling data available</p>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </>
  );
};

const SearchResultsSkeleton: React.FC = () => {
  return (
    <div className="space-y-3">
      {Array(5).fill(0).map((_, index) => (
        <div key={index} className="p-3 rounded-lg bg-gray-50 dark:bg-gray-800">
          <div className="flex items-center">
            <Skeleton className="w-10 h-10 rounded-full mr-3" />
            <div className="space-y-2">
              <Skeleton className="h-4 w-32" />
              <Skeleton className="h-3 w-20" />
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

const PlayerDetailsSkeleton: React.FC = () => {
  return (
    <>
      <CardHeader className="border-b">
        <div className="flex flex-col md:flex-row md:items-center">
          <Skeleton className="w-24 h-24 rounded-full mb-4 md:mb-0 md:mr-6" />
          <div className="space-y-3 flex-grow">
            <Skeleton className="h-8 w-48" />
            <div className="flex flex-wrap gap-2">
              <Skeleton className="h-5 w-20" />
              <Skeleton className="h-5 w-20" />
              <Skeleton className="h-5 w-20" />
            </div>
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-2/3" />
          </div>
        </div>
      </CardHeader>
      <CardContent className="pt-6">
        <div className="flex mb-6 gap-2">
          <Skeleton className="h-10 w-24" />
          <Skeleton className="h-10 w-24" />
          <Skeleton className="h-10 w-24" />
        </div>
        <div className="space-y-6">
          <Skeleton className="h-6 w-48" />
          <Skeleton className="h-64 w-full" />
        </div>
      </CardContent>
    </>
  );
};

export default Players;