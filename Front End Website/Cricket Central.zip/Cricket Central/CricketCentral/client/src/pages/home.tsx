import React from "react";
import HeroSection from "@/components/hero-section";
import LiveMatches from "@/components/live-matches";
import RecentMatches from "@/components/recent-matches";
import UpcomingMatches from "@/components/upcoming-matches";
import MatchPredictions from "@/components/match-predictions";
import FantasyCricket from "@/components/fantasy-cricket";
import PowerBIDashboard from "@/components/power-bi-dashboard";

const Home: React.FC = () => {
  return (
    <div>
      <HeroSection />
      
      <main className="container mx-auto px-4 py-8">
        <LiveMatches />
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column (2/3 width on large screens) */}
          <div className="lg:col-span-2 space-y-8">
            <RecentMatches />
            <PowerBIDashboard />
          </div>
          
          {/* Right Column (1/3 width on large screens) */}
          <div className="space-y-8">
            <UpcomingMatches />
            <MatchPredictions />
            <FantasyCricket />
          </div>
        </div>
      </main>
    </div>
  );
};

export default Home;
