import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Search } from "lucide-react";
import { Team } from "@shared/schema";

const Teams: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [sortBy, setSortBy] = useState("name");
  
  const { data: teams, isLoading, error } = useQuery<Team[]>({
    queryKey: ['/api/teams'],
  });
  
  // Filter teams based on search term
  const filteredTeams = React.useMemo(() => {
    if (!teams) return [];
    
    return teams.filter(team => 
      team.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      team.shortName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      team.countryCode?.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [teams, searchTerm]);
  
  // Sort teams based on sort criteria
  const sortedTeams = React.useMemo(() => {
    if (!filteredTeams) return [];
    
    return [...filteredTeams].sort((a, b) => {
      if (sortBy === "name") {
        return a.name.localeCompare(b.name);
      } else if (sortBy === "shortName") {
        return a.shortName.localeCompare(b.shortName);
      } else if (sortBy === "countryCode") {
        return (a.countryCode || "").localeCompare(b.countryCode || "");
      }
      return 0;
    });
  }, [filteredTeams, sortBy]);
  
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6 text-gray-800 dark:text-white">Cricket Teams</h1>
      
      <div className="mb-6 flex flex-col md:flex-row gap-4">
        <div className="relative flex-grow">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500 dark:text-gray-400" />
          <Input
            type="search"
            placeholder="Search teams..."
            className="pl-8"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className="w-full md:w-48">
          <Select
            value={sortBy}
            onValueChange={(value) => setSortBy(value)}
          >
            <SelectTrigger>
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="name">Team Name</SelectItem>
              <SelectItem value="shortName">Short Name</SelectItem>
              <SelectItem value="countryCode">Country Code</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Teams Directory</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-4">
              {Array(9).fill(0).map((_, index) => (
                <div key={index} className="flex items-center space-x-4">
                  <Skeleton className="h-12 w-12 rounded-full" />
                  <div className="space-y-2">
                    <Skeleton className="h-4 w-40" />
                    <Skeleton className="h-3 w-24" />
                  </div>
                </div>
              ))}
            </div>
          ) : error ? (
            <div className="text-center py-8 text-red-500">
              <p>Failed to load teams. Please try again later.</p>
            </div>
          ) : (
            <>
              {sortedTeams.length > 0 ? (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Flag</TableHead>
                      <TableHead>Team Name</TableHead>
                      <TableHead>Short Name</TableHead>
                      <TableHead>Country Code</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {sortedTeams.map((team) => (
                      <TableRow key={team.id}>
                        <TableCell>
                          {team.flagUrl ? (
                            <img 
                              src={team.flagUrl} 
                              alt={`${team.name} flag`} 
                              className="h-8 w-12 object-cover rounded border" 
                            />
                          ) : (
                            <div className="h-8 w-12 bg-gray-200 dark:bg-gray-700 rounded"></div>
                          )}
                        </TableCell>
                        <TableCell className="font-medium">{team.name}</TableCell>
                        <TableCell>{team.shortName}</TableCell>
                        <TableCell>{team.countryCode}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : (
                <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                  <p>No teams match your search criteria.</p>
                </div>
              )}
            </>
          )}
        </CardContent>
      </Card>
      
      <div className="mt-8">
        <Card>
          <CardHeader>
            <CardTitle>Team Rankings</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <h3 className="text-lg font-semibold mb-4 dark:text-white">Test Rankings</h3>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Rank</TableHead>
                      <TableHead>Team</TableHead>
                      <TableHead>Rating</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell>1</TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-2">
                          <img src="https://cdn.britannica.com/97/1597-004-05816F4E/Flag-India.jpg" alt="India" className="h-5 w-7 object-cover rounded" />
                          <span>India</span>
                        </div>
                      </TableCell>
                      <TableCell>120</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell>2</TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-2">
                          <img src="https://cdn.britannica.com/78/6078-004-77AF7322/Flag-Australia.jpg" alt="Australia" className="h-5 w-7 object-cover rounded" />
                          <span>Australia</span>
                        </div>
                      </TableCell>
                      <TableCell>118</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell>3</TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-2">
                          <img src="https://cdn.britannica.com/44/1644-004-F5429F14/Flag-England.jpg" alt="England" className="h-5 w-7 object-cover rounded" />
                          <span>England</span>
                        </div>
                      </TableCell>
                      <TableCell>117</TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>
              
              <div>
                <h3 className="text-lg font-semibold mb-4 dark:text-white">ODI Rankings</h3>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Rank</TableHead>
                      <TableHead>Team</TableHead>
                      <TableHead>Rating</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell>1</TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-2">
                          <img src="https://cdn.britannica.com/78/6078-004-77AF7322/Flag-Australia.jpg" alt="Australia" className="h-5 w-7 object-cover rounded" />
                          <span>Australia</span>
                        </div>
                      </TableCell>
                      <TableCell>125</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell>2</TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-2">
                          <img src="https://cdn.britannica.com/97/1597-004-05816F4E/Flag-India.jpg" alt="India" className="h-5 w-7 object-cover rounded" />
                          <span>India</span>
                        </div>
                      </TableCell>
                      <TableCell>121</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell>3</TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-2">
                          <img src="https://cdn.britannica.com/27/4227-004-32423B42/Flag-South-Africa.jpg" alt="South Africa" className="h-5 w-7 object-cover rounded" />
                          <span>South Africa</span>
                        </div>
                      </TableCell>
                      <TableCell>115</TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>
              
              <div>
                <h3 className="text-lg font-semibold mb-4 dark:text-white">T20 Rankings</h3>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Rank</TableHead>
                      <TableHead>Team</TableHead>
                      <TableHead>Rating</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell>1</TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-2">
                          <img src="https://cdn.britannica.com/97/1597-004-05816F4E/Flag-India.jpg" alt="India" className="h-5 w-7 object-cover rounded" />
                          <span>India</span>
                        </div>
                      </TableCell>
                      <TableCell>128</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell>2</TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-2">
                          <img src="https://cdn.britannica.com/44/1644-004-F5429F14/Flag-England.jpg" alt="England" className="h-5 w-7 object-cover rounded" />
                          <span>England</span>
                        </div>
                      </TableCell>
                      <TableCell>122</TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell>3</TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-2">
                          <img src="https://cdn.britannica.com/46/3346-004-D3BDE016/flag-symbolism-Pakistan-design-Islamic.jpg" alt="Pakistan" className="h-5 w-7 object-cover rounded" />
                          <span>Pakistan</span>
                        </div>
                      </TableCell>
                      <TableCell>120</TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Teams;
