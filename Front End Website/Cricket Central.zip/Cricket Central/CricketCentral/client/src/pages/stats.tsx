import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line
} from "recharts";
import { Loader2, Search, RefreshCw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { cricketStatsService, PlayerStats, TeamStats } from "../services/cricket-stats-api";

const Stats: React.FC = () => {
  const [matchType, setMatchType] = useState("t20");
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<PlayerStats[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const { toast } = useToast();

  // Query for top batsmen
  const {
    data: battingStats,
    isLoading: battingLoading,
    isError: battingError,
    error: battingErrorDetails,
    refetch: refetchBatting
  } = useQuery({
    queryKey: ['/api/cricket/stats/batting', matchType],
    queryFn: () => cricketStatsService.getTopBatsmen(matchType),
    staleTime: 5 * 60 * 1000, // 5 minutes
    refetchOnWindowFocus: false
  });

  // Query for top bowlers
  const {
    data: bowlingStats,
    isLoading: bowlingLoading,
    isError: bowlingError,
    error: bowlingErrorDetails,
    refetch: refetchBowling
  } = useQuery({
    queryKey: ['/api/cricket/stats/bowling', matchType],
    queryFn: () => cricketStatsService.getTopBowlers(matchType),
    staleTime: 5 * 60 * 1000, // 5 minutes
    refetchOnWindowFocus: false
  });

  // Query for team stats
  const {
    data: teamStats,
    isLoading: teamsLoading,
    isError: teamsError,
    error: teamsErrorDetails,
    refetch: refetchTeams
  } = useQuery({
    queryKey: ['/api/cricket/stats/teams', matchType],
    queryFn: () => cricketStatsService.getTeamStats(matchType),
    staleTime: 5 * 60 * 1000, // 5 minutes
    refetchOnWindowFocus: false
  });

  // Derived chart data for team win percentages
  const winPercentageData = teamStats 
    ? teamStats
        .map(team => ({
          name: team.name,
          winPercentage: team.winPercentage
        }))
        .sort((a, b) => b.winPercentage - a.winPercentage)
    : [];
  
  // Find the first team (usually India) for the pie chart
  const selectedTeam = teamStats?.[0] || null;
  
  // Pie chart data for match results if team is available
  const COLORS = ['#0e4c92', '#e53e3e', '#d69e2e', '#718096'];
  const matchResultsData = selectedTeam 
    ? [
        { name: 'Won', value: selectedTeam.won },
        { name: 'Lost', value: selectedTeam.lost },
        { name: 'Tied', value: selectedTeam.tied },
        { name: 'No Result', value: selectedTeam.noResult }
      ]
    : [];
  
  // Handle player search
  const handleSearch = async () => {
    if (!searchQuery.trim()) {
      toast({
        title: "Search Query Required",
        description: "Please enter a player name to search",
        variant: "destructive"
      });
      return;
    }
    
    setIsSearching(true);
    try {
      const results = await cricketStatsService.searchPlayerStats(searchQuery, matchType);
      setSearchResults(results);
      if (results.length === 0) {
        toast({
          title: "No Players Found",
          description: `No players matching "${searchQuery}" found in ${matchType.toUpperCase()} format`,
          variant: "destructive"
        });
      }
    } catch (error) {
      console.error("Error searching players:", error);
      toast({
        title: "Search Failed",
        description: error instanceof Error ? error.message : "Failed to search players. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsSearching(false);
    }
  };
  
  // Handle stats refresh for current format
  const handleRefreshAll = () => {
    refetchBatting();
    refetchBowling();
    refetchTeams();
    
    toast({
      title: "Refreshing Statistics",
      description: `Updating ${matchType.toUpperCase()} statistics data...`
    });
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6 text-gray-800 dark:text-white">Cricket Statistics</h1>
      
      {/* Performance Metrics Section */}
      <div className="mb-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold text-gray-800 dark:text-white">API Performance</h2>
          <Button 
            variant="outline" 
            onClick={handleRefreshAll}
            disabled={battingLoading || bowlingLoading || teamsLoading}
          >
            <RefreshCw className="mr-2 h-4 w-4" />
            Refresh Stats
          </Button>
        </div>
        <Card>
          <CardContent className="pt-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-gray-100 dark:bg-gray-800 p-4 rounded-lg">
                <h3 className="font-semibold mb-2">Average Response Time</h3>
                <p className="text-2xl font-bold">
                  {cricketStatsService.getAverageResponseTime()} ms
                </p>
              </div>
              <div className="bg-gray-100 dark:bg-gray-800 p-4 rounded-lg">
                <h3 className="font-semibold mb-2">API Success Rate</h3>
                <p className="text-2xl font-bold">
                  {cricketStatsService.metrics.length > 0 
                    ? `${Math.round((cricketStatsService.metrics.filter(m => m.success).length / cricketStatsService.metrics.length) * 100)}%`
                    : "N/A"}
                </p>
              </div>
              <div className="bg-gray-100 dark:bg-gray-800 p-4 rounded-lg">
                <h3 className="font-semibold mb-2">Total API Requests</h3>
                <p className="text-2xl font-bold">
                  {cricketStatsService.metrics.length}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Player Search Section */}
      <div className="mb-6">
        <Card>
          <CardHeader>
            <CardTitle>Player Search</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2 mb-4">
              <Input 
                placeholder="Search player by name..." 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
              />
              <Button onClick={handleSearch} disabled={isSearching}>
                {isSearching ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Searching...
                  </>
                ) : (
                  <>
                    <Search className="mr-2 h-4 w-4" />
                    Search
                  </>
                )}
              </Button>
            </div>
            
            {searchResults.length > 0 && (
              <div>
                <h3 className="text-lg font-semibold mb-2">Search Results</h3>
                <div className="max-h-96 overflow-y-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Player</TableHead>
                        <TableHead>Team</TableHead>
                        <TableHead>Type</TableHead>
                        <TableHead>Stats</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {searchResults.map((player, index) => (
                        <TableRow key={index}>
                          <TableCell className="font-medium">
                            <div className="flex items-center gap-2">
                              {player.imageUrl && (
                                <img 
                                  src={player.imageUrl} 
                                  alt={player.name} 
                                  className="w-8 h-8 rounded-full"
                                />
                              )}
                              {player.name}
                            </div>
                          </TableCell>
                          <TableCell>{player.team}</TableCell>
                          <TableCell>
                            {player.battingStats && player.bowlingStats ? 'All-rounder' :
                             player.battingStats ? 'Batsman' :
                             player.bowlingStats ? 'Bowler' : 'Unknown'}
                          </TableCell>
                          <TableCell>
                            {player.battingStats && (
                              <div className="text-xs">
                                <span className="font-semibold">Batting:</span> {player.battingStats.matches} matches, 
                                {player.battingStats.runs} runs, 
                                Avg: {player.battingStats.average}
                              </div>
                            )}
                            {player.bowlingStats && (
                              <div className="text-xs">
                                <span className="font-semibold">Bowling:</span> {player.bowlingStats.matches} matches, 
                                {player.bowlingStats.wickets} wickets, 
                                Econ: {player.bowlingStats.economy}
                              </div>
                            )}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
      
      <div className="mb-6 flex items-center justify-between">
        <Tabs defaultValue="batting" className="w-full">
          <div className="flex items-center justify-between mb-4">
            <TabsList>
              <TabsTrigger value="batting">Batting Stats</TabsTrigger>
              <TabsTrigger value="bowling">Bowling Stats</TabsTrigger>
              <TabsTrigger value="team">Team Stats</TabsTrigger>
            </TabsList>
            
            <div className="w-40">
              <Select
                value={matchType}
                onValueChange={(value) => setMatchType(value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Match Type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="t20">T20</SelectItem>
                  <SelectItem value="odi">ODI</SelectItem>
                  <SelectItem value="test">Test</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          {/* Batting Stats Tab */}
          <TabsContent value="batting">
            <Card>
              <CardHeader>
                <CardTitle>
                  Top Batsmen in {matchType.toUpperCase()}
                  {battingLoading && (
                    <Loader2 className="inline-block ml-2 h-4 w-4 animate-spin" />
                  )}
                </CardTitle>
              </CardHeader>
              <CardContent>
                {battingError ? (
                  <div className="text-center py-10 text-red-500">
                    <p className="text-xl font-semibold mb-2">Failed to load batting statistics</p>
                    <p className="text-sm">{battingErrorDetails instanceof Error ? battingErrorDetails.message : 'Unknown error'}</p>
                    <Button onClick={() => refetchBatting()} className="mt-4">
                      <RefreshCw className="mr-2 h-4 w-4" />
                      Retry
                    </Button>
                  </div>
                ) : battingLoading ? (
                  <div className="text-center py-16">
                    <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4" />
                    <p className="text-gray-500">Loading batting statistics...</p>
                  </div>
                ) : (
                  <>
                    {/* Table stays the same, but check for empty data */}
                    {battingStats && battingStats.length > 0 ? (
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Player</TableHead>
                            <TableHead>Team</TableHead>
                            <TableHead>Matches</TableHead>
                            <TableHead>Runs</TableHead>
                            <TableHead>Average</TableHead>
                            <TableHead>Strike Rate</TableHead>
                            <TableHead>50s</TableHead>
                            <TableHead>100s</TableHead>
                            <TableHead>Highest</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {battingStats.map((player: PlayerStats, index: number) => (
                            <TableRow key={index}>
                              <TableCell className="font-medium">
                                <div className="flex items-center gap-2">
                                  {player.imageUrl && (
                                    <img 
                                      src={player.imageUrl} 
                                      alt={player.name} 
                                      className="w-6 h-6 rounded-full"
                                    />
                                  )}
                                  {player.name}
                                </div>
                              </TableCell>
                              <TableCell>{player.team}</TableCell>
                              <TableCell>{player.battingStats?.matches || 0}</TableCell>
                              <TableCell>{player.battingStats?.runs || 0}</TableCell>
                              <TableCell>{player.battingStats?.average || 0}</TableCell>
                              <TableCell>{player.battingStats?.strikeRate || 0}</TableCell>
                              <TableCell>{player.battingStats?.fifties || 0}</TableCell>
                              <TableCell>{player.battingStats?.hundreds || 0}</TableCell>
                              <TableCell>{player.battingStats?.highestScore || 0}</TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    ) : (
                      <div className="text-center py-10 text-gray-500">
                        <p>No batting statistics available for {matchType.toUpperCase()}</p>
                      </div>
                    )}
                    
                    {/* Chart stays the same, but check for empty data */}
                    {battingStats && battingStats.length > 0 && (
                      <div className="mt-6 h-96">
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart
                            data={battingStats.map(player => ({
                              name: player.name,
                              runs: player.battingStats?.runs || 0,
                              average: player.battingStats?.average || 0
                            }))}
                            margin={{ top: 20, right: 30, left: 20, bottom: 70 }}
                          >
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="name" angle={-45} textAnchor="end" />
                            <YAxis />
                            <Tooltip />
                            <Legend />
                            <Bar dataKey="runs" fill="#0e4c92" name="Total Runs" />
                            <Bar dataKey="average" fill="#22c55e" name="Batting Average" />
                          </BarChart>
                        </ResponsiveContainer>
                      </div>
                    )}
                  </>
                )}
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* Bowling Stats Tab */}
          <TabsContent value="bowling">
            <Card>
              <CardHeader>
                <CardTitle>
                  Top Bowlers in {matchType.toUpperCase()}
                  {bowlingLoading && (
                    <Loader2 className="inline-block ml-2 h-4 w-4 animate-spin" />
                  )}
                </CardTitle>
              </CardHeader>
              <CardContent>
                {bowlingError ? (
                  <div className="text-center py-10 text-red-500">
                    <p className="text-xl font-semibold mb-2">Failed to load bowling statistics</p>
                    <p className="text-sm">{bowlingErrorDetails instanceof Error ? bowlingErrorDetails.message : 'Unknown error'}</p>
                    <Button onClick={() => refetchBowling()} className="mt-4">
                      <RefreshCw className="mr-2 h-4 w-4" />
                      Retry
                    </Button>
                  </div>
                ) : bowlingLoading ? (
                  <div className="text-center py-16">
                    <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4" />
                    <p className="text-gray-500">Loading bowling statistics...</p>
                  </div>
                ) : (
                  <>
                    {/* Table stays the same, but check for empty data */}
                    {bowlingStats && bowlingStats.length > 0 ? (
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Player</TableHead>
                            <TableHead>Team</TableHead>
                            <TableHead>Matches</TableHead>
                            <TableHead>Wickets</TableHead>
                            <TableHead>Average</TableHead>
                            <TableHead>Economy</TableHead>
                            <TableHead>Best Figures</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {bowlingStats.map((player: PlayerStats, index: number) => (
                            <TableRow key={index}>
                              <TableCell className="font-medium">
                                <div className="flex items-center gap-2">
                                  {player.imageUrl && (
                                    <img 
                                      src={player.imageUrl} 
                                      alt={player.name} 
                                      className="w-6 h-6 rounded-full"
                                    />
                                  )}
                                  {player.name}
                                </div>
                              </TableCell>
                              <TableCell>{player.team}</TableCell>
                              <TableCell>{player.bowlingStats?.matches || 0}</TableCell>
                              <TableCell>{player.bowlingStats?.wickets || 0}</TableCell>
                              <TableCell>{player.bowlingStats?.average || 0}</TableCell>
                              <TableCell>{player.bowlingStats?.economy || 0}</TableCell>
                              <TableCell>{player.bowlingStats?.bestFigures || '-'}</TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    ) : (
                      <div className="text-center py-10 text-gray-500">
                        <p>No bowling statistics available for {matchType.toUpperCase()}</p>
                      </div>
                    )}
                    
                    {/* Chart stays the same, but check for empty data */}
                    {bowlingStats && bowlingStats.length > 0 && (
                      <div className="mt-6 h-96">
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart
                            data={bowlingStats.map(player => ({
                              name: player.name,
                              wickets: player.bowlingStats?.wickets || 0,
                              economy: player.bowlingStats?.economy || 0
                            }))}
                            margin={{ top: 20, right: 30, left: 20, bottom: 70 }}
                          >
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="name" angle={-45} textAnchor="end" />
                            <YAxis />
                            <Tooltip />
                            <Legend />
                            <Bar dataKey="wickets" fill="#0e4c92" name="Wickets" />
                            <Bar dataKey="economy" fill="#f59e0b" name="Economy Rate" />
                          </BarChart>
                        </ResponsiveContainer>
                      </div>
                    )}
                  </>
                )}
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* Team Stats Tab */}
          <TabsContent value="team">
            <Card>
              <CardHeader>
                <CardTitle>
                  Team Performance in {matchType.toUpperCase()}
                  {teamsLoading && (
                    <Loader2 className="inline-block ml-2 h-4 w-4 animate-spin" />
                  )}
                </CardTitle>
              </CardHeader>
              <CardContent>
                {teamsError ? (
                  <div className="text-center py-10 text-red-500">
                    <p className="text-xl font-semibold mb-2">Failed to load team statistics</p>
                    <p className="text-sm">{teamsErrorDetails instanceof Error ? teamsErrorDetails.message : 'Unknown error'}</p>
                    <Button onClick={() => refetchTeams()} className="mt-4">
                      <RefreshCw className="mr-2 h-4 w-4" />
                      Retry
                    </Button>
                  </div>
                ) : teamsLoading ? (
                  <div className="text-center py-16">
                    <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4" />
                    <p className="text-gray-500">Loading team statistics...</p>
                  </div>
                ) : (
                  <>
                    {/* Table for team stats */}
                    {teamStats && teamStats.length > 0 ? (
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Team</TableHead>
                            <TableHead>Matches Won</TableHead>
                            <TableHead>Matches Lost</TableHead>
                            <TableHead>Tied</TableHead>
                            <TableHead>No Result</TableHead>
                            <TableHead>Win %</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {teamStats.map((team: TeamStats, index: number) => (
                            <TableRow key={index}>
                              <TableCell className="font-medium">
                                <div className="flex items-center gap-2">
                                  {team.imageUrl && (
                                    <img 
                                      src={team.imageUrl} 
                                      alt={team.name} 
                                      className="w-6 h-6"
                                    />
                                  )}
                                  {team.name}
                                </div>
                              </TableCell>
                              <TableCell>{team.won}</TableCell>
                              <TableCell>{team.lost}</TableCell>
                              <TableCell>{team.tied}</TableCell>
                              <TableCell>{team.noResult}</TableCell>
                              <TableCell>{team.winPercentage}%</TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    ) : (
                      <div className="text-center py-10 text-gray-500">
                        <p>No team statistics available for {matchType.toUpperCase()}</p>
                      </div>
                    )}
                    
                    {/* Charts for team stats */}
                    {teamStats && teamStats.length > 0 && (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
                        <div className="h-96">
                          <h3 className="text-lg font-semibold mb-4 text-center dark:text-white">Win Percentage by Team</h3>
                          <ResponsiveContainer width="100%" height="90%">
                            <BarChart
                              data={winPercentageData}
                              margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                            >
                              <CartesianGrid strokeDasharray="3 3" />
                              <XAxis dataKey="name" />
                              <YAxis domain={[0, 100]} />
                              <Tooltip />
                              <Bar dataKey="winPercentage" fill="#0e4c92" name="Win %" />
                            </BarChart>
                          </ResponsiveContainer>
                        </div>
                        
                        <div className="h-96">
                          <h3 className="text-lg font-semibold mb-4 text-center dark:text-white">
                            {selectedTeam ? `${selectedTeam.name}'s Match Results` : 'Match Results'}
                          </h3>
                          <ResponsiveContainer width="100%" height="90%">
                            <PieChart>
                              <Pie
                                data={matchResultsData}
                                cx="50%"
                                cy="50%"
                                labelLine={true}
                                label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                                outerRadius={100}
                                fill="#8884d8"
                                dataKey="value"
                              >
                                {matchResultsData.map((entry, index) => (
                                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                ))}
                              </Pie>
                              <Tooltip />
                            </PieChart>
                          </ResponsiveContainer>
                        </div>
                      </div>
                    )}
                  </>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default Stats;
