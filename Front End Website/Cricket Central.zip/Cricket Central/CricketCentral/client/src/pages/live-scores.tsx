import React from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { Match, Team } from "@shared/schema";

const LiveScores: React.FC = () => {
  const { data: liveMatches, isLoading: isLoadingLive } = useQuery<Match[]>({
    queryKey: ['/api/matches/live'],
  });
  
  const { data: recentMatches, isLoading: isLoadingRecent } = useQuery<Match[]>({
    queryKey: ['/api/matches/recent', 10], // Show more results on dedicated page
    queryFn: () => fetch('/api/matches/recent?limit=10').then(res => res.json())
  });
  
  const { data: upcomingMatches, isLoading: isLoadingUpcoming } = useQuery<Match[]>({
    queryKey: ['/api/matches/upcoming', 10], // Show more results on dedicated page
    queryFn: () => fetch('/api/matches/upcoming?limit=10').then(res => res.json())
  });
  
  const { data: teams, isLoading: isLoadingTeams } = useQuery<Team[]>({
    queryKey: ['/api/teams'],
  });
  
  // Find team by ID
  const getTeam = (teamId?: number) => {
    return teams?.find(team => team.id === teamId);
  };
  
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6 text-gray-800 dark:text-white">Cricket Scores</h1>
      
      <Tabs defaultValue="live" className="mb-8">
        <TabsList className="mb-4">
          <TabsTrigger value="live">Live Matches</TabsTrigger>
          <TabsTrigger value="recent">Recent Results</TabsTrigger>
          <TabsTrigger value="upcoming">Upcoming Matches</TabsTrigger>
        </TabsList>
        
        {/* Live Matches Tab */}
        <TabsContent value="live">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {isLoadingLive || isLoadingTeams ? (
              // Loading skeletons
              Array(2).fill(0).map((_, index) => (
                <Card key={index} className="border-l-4 border-red-500">
                  <CardContent className="p-4">
                    <div className="flex justify-between items-center mb-3">
                      <Skeleton className="h-6 w-16 rounded-full" />
                      <Skeleton className="h-4 w-24" />
                    </div>
                    <div className="space-y-4 mb-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <Skeleton className="h-8 w-8 rounded-full" />
                          <Skeleton className="h-5 w-24" />
                        </div>
                        <Skeleton className="h-6 w-16" />
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <Skeleton className="h-8 w-8 rounded-full" />
                          <Skeleton className="h-5 w-24" />
                        </div>
                        <Skeleton className="h-6 w-16" />
                      </div>
                    </div>
                    <Skeleton className="h-4 w-full mb-3" />
                    <Skeleton className="h-2 w-full mb-3" />
                    <div className="flex justify-between">
                      <Skeleton className="h-3 w-16" />
                      <Skeleton className="h-3 w-28" />
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : liveMatches && liveMatches.length > 0 ? (
              liveMatches.map((match) => {
                const team1 = getTeam(match.team1Id);
                const team2 = getTeam(match.team2Id);
                const additionalInfo = match.additionalInfo as any || {};
                
                return (
                  <Card key={match.id} className="border-l-4 border-red-500 hover:shadow-lg transition-shadow">
                    <CardContent className="p-4">
                      <div className="flex justify-between items-center mb-3">
                        <span className="bg-red-500 text-white text-xs px-2 py-1 rounded-full animate-pulse">LIVE</span>
                        <span className="text-xs text-gray-500 dark:text-gray-400">{match.seriesName}</span>
                      </div>
                      
                      {/* Teams */}
                      <div className="space-y-4 mb-4">
                        {/* Team 1 */}
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            {team1?.flagUrl ? (
                              <img 
                                src={team1.flagUrl} 
                                alt={team1.name} 
                                className="w-8 h-8 rounded-full object-cover border" 
                              />
                            ) : (
                              <div className="w-8 h-8 rounded-full bg-gray-200 dark:bg-gray-700"></div>
                            )}
                            <span className="font-semibold dark:text-white">{team1?.name}</span>
                          </div>
                          <div className="font-mono font-bold text-lg dark:text-white">{match.team1Score}</div>
                        </div>
                        
                        {/* Team 2 */}
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            {team2?.flagUrl ? (
                              <img 
                                src={team2.flagUrl} 
                                alt={team2.name} 
                                className="w-8 h-8 rounded-full object-cover border" 
                              />
                            ) : (
                              <div className="w-8 h-8 rounded-full bg-gray-200 dark:bg-gray-700"></div>
                            )}
                            <span className="font-semibold dark:text-white">{team2?.name}</span>
                          </div>
                          <div className="font-mono font-bold text-lg dark:text-white">{match.team2Score}</div>
                        </div>
                      </div>
                      
                      {/* Match Status */}
                      <div className="text-sm text-gray-600 dark:text-gray-300 mb-3">
                        {match.matchType === 'Test' 
                          ? `Day ${additionalInfo.day}: ${team1?.name} lead by ${additionalInfo.lead} runs`
                          : `${team2?.name} need ${additionalInfo.requiredRuns} runs from ${additionalInfo.requiredBalls} balls`
                        }
                      </div>
                      
                      {/* Progress Bar */}
                      <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-1.5 mb-3">
                        <div 
                          className="bg-red-500 h-1.5 rounded-full" 
                          style={{ 
                            width: match.matchType === 'T20' 
                              ? `${(parseFloat(match.team2Overs || '0') / 20) * 100}%` 
                              : match.matchType === 'ODI' 
                                ? `${(parseFloat(match.team2Overs || '0') / 50) * 100}%`
                                : '60%' // Default for Test
                          }}
                        ></div>
                      </div>
                      
                      {/* Bottom Info */}
                      <div className="flex justify-between items-center text-xs text-gray-500 dark:text-gray-400">
                        <span>{match.team2Overs} overs</span>
                        <span>{match.venue}</span>
                      </div>
                    </CardContent>
                  </Card>
                );
              })
            ) : (
              <div className="col-span-full flex items-center justify-center py-10">
                <p className="text-gray-500 dark:text-gray-400">No live matches at the moment</p>
              </div>
            )}
          </div>
        </TabsContent>
        
        {/* Recent Results Tab */}
        <TabsContent value="recent">
          <Card>
            <CardHeader>
              <CardTitle>Recent Match Results</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              {isLoadingRecent || isLoadingTeams ? (
                // Loading skeletons
                <div className="divide-y divide-gray-100 dark:divide-gray-700">
                  {Array(5).fill(0).map((_, index) => (
                    <div key={index} className="p-4">
                      <div className="flex justify-between items-center mb-2">
                        <Skeleton className="h-4 w-32" />
                        <Skeleton className="h-5 w-24 rounded-full" />
                      </div>
                      <div className="space-y-3 mb-2">
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center space-x-3">
                            <Skeleton className="h-6 w-6 rounded-full" />
                            <Skeleton className="h-5 w-24" />
                            <Skeleton className="h-4 w-16" />
                          </div>
                          <Skeleton className="h-6 w-16 rounded" />
                        </div>
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center space-x-3">
                            <Skeleton className="h-6 w-6 rounded-full" />
                            <Skeleton className="h-5 w-24" />
                            <Skeleton className="h-4 w-16" />
                          </div>
                        </div>
                      </div>
                      <Skeleton className="h-4 w-48" />
                    </div>
                  ))}
                </div>
              ) : recentMatches && recentMatches.length > 0 ? (
                <div className="divide-y divide-gray-100 dark:divide-gray-700">
                  {recentMatches.map((match) => {
                    const team1 = getTeam(match.team1Id);
                    const team2 = getTeam(match.team2Id);
                    const winningTeam = getTeam(match.winningTeamId);
                    const matchDate = new Date(match.date);
                    const dateFormatted = matchDate.toLocaleDateString();
                    
                    return (
                      <div key={match.id} className="p-4 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-xs text-gray-500 dark:text-gray-400">
                            {match.matchType} - {dateFormatted}
                          </span>
                          <span className="bg-green-500 text-white text-xs px-2 py-0.5 rounded-full">COMPLETED</span>
                        </div>
                        
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center space-x-3">
                            {team1?.flagUrl ? (
                              <img 
                                src={team1.flagUrl} 
                                alt={team1.name} 
                                className="w-6 h-6 rounded-full object-cover border" 
                              />
                            ) : (
                              <div className="w-6 h-6 rounded-full bg-gray-200 dark:bg-gray-700"></div>
                            )}
                            <span className="font-medium dark:text-white">{team1?.name}</span>
                            <span className="text-sm font-mono">{match.team1Score}</span>
                          </div>
                          {match.winningTeamId === match.team1Id && (
                            <div className="text-xs font-semibold px-2 py-1 bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100 rounded">WINNER</div>
                          )}
                        </div>
                        
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center space-x-3">
                            {team2?.flagUrl ? (
                              <img 
                                src={team2.flagUrl} 
                                alt={team2.name} 
                                className="w-6 h-6 rounded-full object-cover border" 
                              />
                            ) : (
                              <div className="w-6 h-6 rounded-full bg-gray-200 dark:bg-gray-700"></div>
                            )}
                            <span className="font-medium dark:text-white">{team2?.name}</span>
                            <span className="text-sm font-mono">{match.team2Score}</span>
                          </div>
                          {match.winningTeamId === match.team2Id && (
                            <div className="text-xs font-semibold px-2 py-1 bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100 rounded">WINNER</div>
                          )}
                        </div>
                        
                        <div className="text-sm text-gray-600 dark:text-gray-300">
                          {match.result}
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="p-8 text-center">
                  <p className="text-gray-500 dark:text-gray-400">No recent matches to display</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Upcoming Matches Tab */}
        <TabsContent value="upcoming">
          <Card>
            <CardHeader>
              <CardTitle>Upcoming Matches Schedule</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              {isLoadingUpcoming || isLoadingTeams ? (
                // Loading skeletons
                <div className="divide-y divide-gray-100 dark:divide-gray-700">
                  {Array(5).fill(0).map((_, index) => (
                    <div key={index} className="p-4">
                      <div className="flex justify-between items-center mb-3">
                        <Skeleton className="h-4 w-24" />
                        <Skeleton className="h-5 w-20 rounded-full" />
                      </div>
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center space-x-2">
                          <Skeleton className="h-6 w-6 rounded-full" />
                          <Skeleton className="h-5 w-20" />
                        </div>
                        <Skeleton className="h-4 w-6" />
                        <div className="flex items-center space-x-2">
                          <Skeleton className="h-5 w-20" />
                          <Skeleton className="h-6 w-6 rounded-full" />
                        </div>
                      </div>
                      <div className="flex justify-between">
                        <Skeleton className="h-4 w-24" />
                        <Skeleton className="h-4 w-32" />
                      </div>
                    </div>
                  ))}
                </div>
              ) : upcomingMatches && upcomingMatches.length > 0 ? (
                <div className="divide-y divide-gray-100 dark:divide-gray-700">
                  {upcomingMatches.map((match) => {
                    const team1 = getTeam(match.team1Id);
                    const team2 = getTeam(match.team2Id);
                    const matchDate = new Date(match.date);
                    const dateFormatted = matchDate.toLocaleDateString();
                    const additionalInfo = match.additionalInfo as any || {};
                    
                    // Calculate days until match
                    const now = new Date();
                    const diffTime = matchDate.getTime() - now.getTime();
                    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                    
                    let daysUntil;
                    if (diffDays === 0) daysUntil = 'TODAY';
                    else if (diffDays === 1) daysUntil = 'TOMORROW';
                    else daysUntil = `IN ${diffDays} DAYS`;
                    
                    return (
                      <div key={match.id} className="p-4 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
                        <div className="flex justify-between items-center mb-3">
                          <span className="text-xs text-gray-500 dark:text-gray-400">{match.seriesName}</span>
                          <span className="bg-blue-500 text-white text-xs px-2 py-0.5 rounded-full">{daysUntil}</span>
                        </div>
                        
                        <div className="flex items-center justify-between mb-4">
                          <div className="flex items-center space-x-2">
                            {team1?.flagUrl ? (
                              <img 
                                src={team1.flagUrl} 
                                alt={team1.name} 
                                className="w-6 h-6 rounded-full object-cover border" 
                              />
                            ) : (
                              <div className="w-6 h-6 rounded-full bg-gray-200 dark:bg-gray-700"></div>
                            )}
                            <span className="font-medium dark:text-white">{team1?.name}</span>
                          </div>
                          <div className="text-xs text-gray-500">vs</div>
                          <div className="flex items-center space-x-2">
                            <span className="font-medium dark:text-white">{team2?.name}</span>
                            {team2?.flagUrl ? (
                              <img 
                                src={team2.flagUrl} 
                                alt={team2.name} 
                                className="w-6 h-6 rounded-full object-cover border" 
                              />
                            ) : (
                              <div className="w-6 h-6 rounded-full bg-gray-200 dark:bg-gray-700"></div>
                            )}
                          </div>
                        </div>
                        
                        <div className="flex justify-between text-xs text-gray-500 dark:text-gray-400">
                          <span>
                            <svg xmlns="http://www.w3.org/2000/svg" className="inline-block h-3 w-3 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                              <circle cx="12" cy="12" r="10" />
                              <polyline points="12 6 12 12 16 14" />
                            </svg>
                            {additionalInfo.startTime || dateFormatted}
                          </span>
                          <span>
                            <svg xmlns="http://www.w3.org/2000/svg" className="inline-block h-3 w-3 mr-1" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                              <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" />
                              <circle cx="12" cy="10" r="3" />
                            </svg>
                            {match.venue}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="p-8 text-center">
                  <p className="text-gray-500 dark:text-gray-400">No upcoming matches to display</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default LiveScores;
