import React, { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { CalendarIcon, SearchIcon, ChevronRightIcon, ExternalLinkIcon, RefreshCwIcon } from "lucide-react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { newsService, type NewsArticle } from "@/services/news-api";
import { formatDistanceToNow } from "date-fns";

const News: React.FC = () => {
  const [page, setPage] = useState(1);
  const [searchQuery, setSearchQuery] = useState("");
  const [activeTab, setActiveTab] = useState("latest");
  const [searchInputValue, setSearchInputValue] = useState("");

  // Function to format date in a user-friendly way
  const formatPublishedDate = (dateString: string) => {
    try {
      return formatDistanceToNow(new Date(dateString), { addSuffix: true });
    } catch (error) {
      return dateString;
    }
  };

  // Function to handle search form submission
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setSearchQuery(searchInputValue);
    setActiveTab("search");
    setPage(1);
  };

  // Query for latest news
  const latestNewsQuery = useQuery({
    queryKey: ['/api/news', page],
    queryFn: () => newsService.getLatestNews(page),
    staleTime: 5 * 60 * 1000, // 5 minutes
    refetchOnWindowFocus: false,
  });

  // Query for search results (only executed when searchQuery is not empty)
  const searchNewsQuery = useQuery({
    queryKey: ['/api/news/search', searchQuery, page],
    queryFn: () => newsService.searchNews(searchQuery, page),
    staleTime: 5 * 60 * 1000, // 5 minutes
    refetchOnWindowFocus: false,
    enabled: searchQuery !== "",
  });

  // Helper to get the current query based on active tab
  const getCurrentQuery = () => {
    return activeTab === "latest" ? latestNewsQuery : searchNewsQuery;
  };

  // Helper to get articles based on active tab
  const getArticles = (): NewsArticle[] => {
    const query = getCurrentQuery();
    if (!query.data) return [];
    return query.data.articles || [];
  };

  // Handler for pagination
  const handleNextPage = () => {
    setPage(prevPage => prevPage + 1);
  };

  const handlePrevPage = () => {
    if (page > 1) {
      setPage(prevPage => prevPage - 1);
    }
  };

  // Clear search and go back to latest news
  const clearSearch = () => {
    setSearchQuery("");
    setSearchInputValue("");
    setActiveTab("latest");
    setPage(1);
  };

  // Handle tab change
  const handleTabChange = (value: string) => {
    setActiveTab(value);
    // If switching to search tab but no search query exists, don't change
    if (value === "search" && searchQuery === "") {
      return;
    }
  };

  const getTopStory = (): NewsArticle | null => {
    const articles = getArticles();
    return articles.length > 0 ? articles[0] : null;
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-800 dark:text-white mb-2">Cricket News</h1>
          <p className="text-gray-600 dark:text-gray-300">
            Stay updated with the latest cricket news from around the world
          </p>
        </div>
        
        <form onSubmit={handleSearch} className="flex w-full md:w-auto">
          <div className="relative flex-grow">
            <Input
              type="text"
              placeholder="Search news..."
              className="w-full pr-10"
              value={searchInputValue}
              onChange={(e) => setSearchInputValue(e.target.value)}
            />
            <SearchIcon className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          </div>
          <Button type="submit" className="ml-2">Search</Button>
        </form>
      </div>

      <Tabs value={activeTab} onValueChange={handleTabChange} className="mb-8">
        <TabsList>
          <TabsTrigger value="latest">Latest News</TabsTrigger>
          {searchQuery && (
            <TabsTrigger value="search">
              Search Results: "{searchQuery}"
              <Button 
                variant="ghost" 
                className="h-5 w-5 p-0 ml-2" 
                onClick={(e) => {
                  e.stopPropagation();
                  clearSearch();
                }}
              >
                ×
              </Button>
            </TabsTrigger>
          )}
        </TabsList>

        <TabsContent value="latest">
          {latestNewsQuery.isPending ? (
            <NewsLoading />
          ) : latestNewsQuery.isError ? (
            <div className="text-center py-8">
              <p className="text-red-500 mb-4">Failed to load news. Please try again later.</p>
              <Button 
                onClick={() => latestNewsQuery.refetch()}
                variant="outline"
              >
                <RefreshCwIcon className="mr-2 h-4 w-4" />
                Try Again
              </Button>
            </div>
          ) : (
            <NewsList 
              articles={getArticles()} 
              formatPublishedDate={formatPublishedDate}
              page={page}
              onNextPage={handleNextPage}
              onPrevPage={handlePrevPage}
              hasMore={getArticles().length === 10}
              topStory={getTopStory()}
            />
          )}
        </TabsContent>

        <TabsContent value="search">
          {!searchQuery ? (
            <div className="text-center py-8">
              <p className="text-gray-500">Please enter a search term</p>
            </div>
          ) : searchNewsQuery.isPending ? (
            <NewsLoading />
          ) : searchNewsQuery.isError ? (
            <div className="text-center py-8">
              <p className="text-red-500 mb-4">Failed to load search results. Please try again later.</p>
              <Button 
                onClick={() => searchNewsQuery.refetch()}
                variant="outline"
              >
                <RefreshCwIcon className="mr-2 h-4 w-4" />
                Try Again
              </Button>
            </div>
          ) : searchNewsQuery.data?.articles?.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-gray-500 mb-4">No results found for "{searchQuery}"</p>
              <Button onClick={clearSearch}>Back to Latest News</Button>
            </div>
          ) : (
            <NewsList 
              articles={getArticles()}
              formatPublishedDate={formatPublishedDate}
              page={page}
              onNextPage={handleNextPage}
              onPrevPage={handlePrevPage}
              hasMore={getArticles().length === 10}
              isSearchResult
              searchQuery={searchQuery}
              topStory={getTopStory()}
            />
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
};

interface NewsListProps {
  articles: NewsArticle[];
  formatPublishedDate: (dateString: string) => string;
  page: number;
  onNextPage: () => void;
  onPrevPage: () => void;
  hasMore: boolean;
  isSearchResult?: boolean;
  searchQuery?: string;
  topStory: NewsArticle | null;
}

const NewsList: React.FC<NewsListProps> = ({
  articles,
  formatPublishedDate,
  page,
  onNextPage,
  onPrevPage,
  hasMore,
  isSearchResult = false,
  searchQuery = "",
  topStory
}) => {
  // Skip first article if we have a top story
  const remainingArticles = topStory ? articles.slice(1) : articles;

  return (
    <div>
      {/* Display total results for search */}
      {isSearchResult && (
        <div className="mb-6">
          <h2 className="text-xl font-semibold mb-2">
            Search Results for "{searchQuery}"
          </h2>
          <p className="text-gray-600 dark:text-gray-400">
            Found {articles.length} {articles.length === 1 ? 'article' : 'articles'}
          </p>
        </div>
      )}

      {/* Top Story Section */}
      {topStory && (
        <div className="mb-10">
          <h2 className="text-xl font-semibold mb-4">Top Story</h2>
          <Card className="overflow-hidden">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-0">
              {topStory.urlToImage ? (
                <div className="h-64 md:h-full overflow-hidden bg-gray-100 dark:bg-gray-800">
                  <img 
                    src={topStory.urlToImage} 
                    alt={topStory.title} 
                    className="w-full h-full object-cover"
                  />
                </div>
              ) : (
                <div className="h-64 md:h-full flex items-center justify-center bg-gray-100 dark:bg-gray-800">
                  <p className="text-gray-500 dark:text-gray-400">No image available</p>
                </div>
              )}
              <div className="p-6">
                <CardHeader className="p-0 mb-4">
                  <div className="flex items-center mb-2">
                    <Badge>{topStory.source.name || "News"}</Badge>
                    <span className="ml-2 text-sm text-gray-500 dark:text-gray-400 flex items-center">
                      <CalendarIcon className="h-3 w-3 mr-1" />
                      {formatPublishedDate(topStory.publishedAt)}
                    </span>
                  </div>
                  <CardTitle className="text-2xl font-bold">{topStory.title}</CardTitle>
                </CardHeader>
                <CardContent className="p-0 mb-4">
                  <p className="text-gray-600 dark:text-gray-300">
                    {topStory.description || "Click to read the full article"}
                  </p>
                </CardContent>
                <CardFooter className="p-0 pt-4 flex justify-end">
                  <a 
                    href={topStory.url} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="flex items-center text-primary hover:underline"
                  >
                    Read Full Story
                    <ExternalLinkIcon className="ml-1 h-4 w-4" />
                  </a>
                </CardFooter>
              </div>
            </div>
          </Card>
        </div>
      )}

      {/* More Stories Section */}
      <div className="mb-10">
        <h2 className="text-xl font-semibold mb-4">More Stories</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {remainingArticles.map((article, index) => (
            <Card key={index} className="overflow-hidden flex flex-col h-full">
              {article.urlToImage ? (
                <div className="h-48 overflow-hidden bg-gray-100 dark:bg-gray-800">
                  <img 
                    src={article.urlToImage} 
                    alt={article.title} 
                    className="w-full h-full object-cover"
                  />
                </div>
              ) : (
                <div className="h-48 flex items-center justify-center bg-gray-100 dark:bg-gray-800">
                  <p className="text-gray-500 dark:text-gray-400">No image available</p>
                </div>
              )}
              <CardHeader className="p-4 pb-2">
                <div className="flex items-center mb-2">
                  <Badge variant="outline">{article.source.name || "News"}</Badge>
                  <span className="ml-2 text-xs text-gray-500 dark:text-gray-400 flex items-center">
                    <CalendarIcon className="h-3 w-3 mr-1" />
                    {formatPublishedDate(article.publishedAt)}
                  </span>
                </div>
                <CardTitle className="text-lg">{article.title}</CardTitle>
              </CardHeader>
              <CardContent className="p-4 pt-0 flex-grow">
                <CardDescription className="text-sm line-clamp-3">
                  {article.description || "Click to read the full article"}
                </CardDescription>
              </CardContent>
              <CardFooter className="p-4 pt-0 flex justify-end">
                <a 
                  href={article.url} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="flex items-center text-primary hover:underline text-sm"
                >
                  Read More
                  <ChevronRightIcon className="ml-1 h-4 w-4" />
                </a>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>

      {/* Pagination */}
      <div className="flex justify-between items-center">
        <Button 
          onClick={onPrevPage} 
          disabled={page === 1}
          variant="outline"
        >
          Previous
        </Button>
        <span className="text-sm text-gray-500 dark:text-gray-400">
          Page {page}
        </span>
        <Button 
          onClick={onNextPage} 
          disabled={!hasMore}
          variant="outline"
        >
          Next
        </Button>
      </div>
    </div>
  );
};

const NewsLoading: React.FC = () => {
  return (
    <div>
      {/* Top Story Loading Skeleton */}
      <div className="mb-10">
        <h2 className="text-xl font-semibold mb-4">Top Story</h2>
        <Card className="overflow-hidden">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-0">
            <Skeleton className="h-64 md:h-full w-full" />
            <div className="p-6">
              <div className="flex items-center mb-2">
                <Skeleton className="h-5 w-24" />
                <Skeleton className="h-4 w-32 ml-2" />
              </div>
              <Skeleton className="h-8 w-full mb-2" />
              <Skeleton className="h-8 w-3/4 mb-6" />
              <Skeleton className="h-4 w-full mb-2" />
              <Skeleton className="h-4 w-full mb-2" />
              <Skeleton className="h-4 w-2/3 mb-6" />
              <div className="flex justify-end">
                <Skeleton className="h-6 w-32" />
              </div>
            </div>
          </div>
        </Card>
      </div>

      {/* More Stories Loading Skeletons */}
      <div className="mb-10">
        <h2 className="text-xl font-semibold mb-4">More Stories</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {Array(6).fill(0).map((_, index) => (
            <Card key={index} className="overflow-hidden">
              <Skeleton className="h-48 w-full" />
              <div className="p-4">
                <div className="flex items-center mb-2">
                  <Skeleton className="h-4 w-20" />
                  <Skeleton className="h-3 w-24 ml-2" />
                </div>
                <Skeleton className="h-6 w-full mb-2" />
                <Skeleton className="h-6 w-3/4 mb-4" />
                <Skeleton className="h-4 w-full mb-1" />
                <Skeleton className="h-4 w-full mb-1" />
                <Skeleton className="h-4 w-2/3 mb-4" />
                <div className="flex justify-end">
                  <Skeleton className="h-4 w-24" />
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
};

export default News;