import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Grid2X2, BarChart3, PieChart, LineChart } from "lucide-react";
import PowerBIDashboard from "@/components/power-bi-dashboard";

const Dashboard: React.FC = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6 text-gray-800 dark:text-white">Cricket Analytics Dashboard</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
        <Card>
          <CardContent className="p-6 flex flex-col items-center justify-center">
            <div className="text-4xl font-bold text-primary mb-2">76%</div>
            <p className="text-sm text-gray-500 dark:text-gray-400 text-center">
              Win prediction accuracy
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6 flex flex-col items-center justify-center">
            <div className="text-4xl font-bold text-primary mb-2">500+</div>
            <p className="text-sm text-gray-500 dark:text-gray-400 text-center">
              Players analyzed
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6 flex flex-col items-center justify-center">
            <div className="text-4xl font-bold text-primary mb-2">85K+</div>
            <p className="text-sm text-gray-500 dark:text-gray-400 text-center">
              Data points
            </p>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6 flex flex-col items-center justify-center">
            <div className="text-4xl font-bold text-primary mb-2">12K+</div>
            <p className="text-sm text-gray-500 dark:text-gray-400 text-center">
              Matches analyzed
            </p>
          </CardContent>
        </Card>
      </div>
      
      <Tabs defaultValue="overview">
        <div className="flex justify-between items-center mb-6">
          <TabsList className="overflow-auto max-w-full">
            <TabsTrigger value="overview">
              <Grid2X2 className="h-4 w-4 mr-2" />
              Overview
            </TabsTrigger>
          </TabsList>
        </div>
        
        <TabsContent value="overview" className="space-y-6">
          {/* Main PowerBI Dashboard with larger height */}
          <PowerBIDashboard fullWidth={true} height="700px" showStats={false} />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Dashboard;
