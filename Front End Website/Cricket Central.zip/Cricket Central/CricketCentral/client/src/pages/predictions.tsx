import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle,
  CardDescription
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Skeleton } from "@/components/ui/skeleton";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { Match, Team, Prediction } from "@shared/schema";

const Predictions: React.FC = () => {
  const [location] = useLocation();
  const queryParams = new URLSearchParams(location.split('?')[1] || '');
  const matchId = queryParams.get('matchId');
  
  const { data: upcomingMatches, isLoading: isLoadingMatches } = useQuery<Match[]>({
    queryKey: ['/api/matches/upcoming', 10],
    queryFn: () => fetch('/api/matches/upcoming?limit=10').then(res => res.json())
  });
  
  const { data: teams, isLoading: isLoadingTeams } = useQuery<Team[]>({
    queryKey: ['/api/teams'],
  });
  
  const [selectedTab, setSelectedTab] = useState(matchId ? 'match' : 't20');
  const [selectedMatchId, setSelectedMatchId] = useState<string | null>(matchId);
  
  // IPL Victory Oracle State
  const [iplPrediction, setIplPrediction] = useState<any>(null);
  const [isLoadingIplPrediction, setIsLoadingIplPrediction] = useState(false);
  
  // Find team by ID
  const getTeam = (teamId?: number) => {
    return teams?.find(team => team.id === teamId);
  };
  
  // Fetch prediction if match is selected
  const { data: prediction, isLoading: isLoadingPrediction } = useQuery<Prediction>({
    queryKey: [`/api/predictions/${selectedMatchId}`],
    enabled: !!selectedMatchId,
  });
  
  // Match prediction form schema
  const formSchema = z.object({
    matchId: z.string().min(1, {
      message: "Please select a match.",
    }),
  });
  
  // T20 score prediction form schema
  const t20FormSchema = z.object({
    team: z.string().min(1, {
      message: "Please select a team.",
    }),
    venue: z.string().min(1, {
      message: "Please select a venue.",
    }),
    opposition: z.string().min(1, {
      message: "Please select an opposition team.",
    }),
    wicketsLost: z.coerce.number().min(0).max(10),
    currentOver: z.coerce.number().min(0).max(20),
    currentScore: z.coerce.number().min(0),
    pitchCondition: z.string(),
    battingStrength: z.coerce.number().min(1).max(10),
  });
  
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      matchId: selectedMatchId || "",
    },
  });
  
  const t20Form = useForm<z.infer<typeof t20FormSchema>>({
    resolver: zodResolver(t20FormSchema),
    defaultValues: {
      team: "",
      venue: "",
      opposition: "",
      wicketsLost: 0,
      currentOver: 0,
      currentScore: 0,
      pitchCondition: "normal",
      battingStrength: 5,
    },
  });

  // Submit handler for match prediction
  function onSubmit(values: z.infer<typeof formSchema>) {
    setSelectedMatchId(values.matchId);
  }
  
  // Submit handler for T20 score prediction
  const [t20Prediction, setT20Prediction] = useState<{min: number, max: number} | null>(null);
  const [isCalculatingT20, setIsCalculatingT20] = useState(false);
  
  function onT20Submit(values: z.infer<typeof t20FormSchema>) {
    // In a real app, this would call a backend API for the prediction
    setIsCalculatingT20(true);
    
    // Simulate API call with timeout
    setTimeout(() => {
      // Simple algorithm for demo purposes
      const baseScore = values.currentScore;
      const remainingOvers = 20 - values.currentOver;
      const wicketsRemaining = 10 - values.wicketsLost;
      
      // Calculate run rate based on various factors
      let projectedRunRate = 8; // Base run rate
      
      // Adjust for pitch conditions
      if (values.pitchCondition === "batting") projectedRunRate += 2;
      if (values.pitchCondition === "bowling") projectedRunRate -= 2;
      
      // Adjust for batting strength
      projectedRunRate += (values.battingStrength - 5) * 0.5;
      
      // Adjust for wickets lost
      projectedRunRate *= (1 - (values.wicketsLost * 0.08));
      
      // Calculate projected score range
      const projectedScore = baseScore + Math.round(projectedRunRate * remainingOvers);
      
      // Add some variance for min/max
      const minScore = Math.max(baseScore, projectedScore - 15);
      const maxScore = projectedScore + 15;
      
      setT20Prediction({ min: minScore, max: maxScore });
      setIsCalculatingT20(false);
    }, 1500);
  }
  
  // Fantasy cricket suggestions
  const { data: fantasyPlayers, isLoading: isLoadingFantasy } = useQuery<any[]>({
    queryKey: ['/api/fantasy/players'],
  });
  
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6 text-gray-800 dark:text-white">Cricket Predictions</h1>
      
      <Tabs value={selectedTab} onValueChange={setSelectedTab}>
        <TabsList className="mb-8">
          <TabsTrigger value="match">Match Predictions</TabsTrigger>
          <TabsTrigger value="t20">T20 Score Predictor</TabsTrigger>
          <TabsTrigger value="ipl">IPL Victory Oracle</TabsTrigger>
          <TabsTrigger value="fantasy">Fantasy Cricket Suggestions</TabsTrigger>
        </TabsList>
        
        {/* Match Prediction Tab */}
        <TabsContent value="match">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="md:col-span-1">
              <CardHeader>
                <CardTitle>Select Match</CardTitle>
                <CardDescription>
                  Choose an upcoming match to view prediction
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                    <FormField
                      control={form.control}
                      name="matchId"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Upcoming Match</FormLabel>
                          <Select 
                            onValueChange={field.onChange} 
                            defaultValue={field.value}
                            disabled={isLoadingMatches}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select a match" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {upcomingMatches?.map((match) => (
                                <SelectItem key={match.id} value={match.id.toString()}>
                                  {getTeam(match.team1Id)?.name} vs {getTeam(match.team2Id)?.name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <Button type="submit" className="w-full">View Prediction</Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
            
            <Card className="md:col-span-2">
              <CardHeader>
                <CardTitle>Match Prediction</CardTitle>
              </CardHeader>
              <CardContent>
                {selectedMatchId ? (
                  isLoadingPrediction ? (
                    <div className="space-y-4">
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center space-x-4">
                          <Skeleton className="h-12 w-12 rounded-full" />
                          <Skeleton className="h-6 w-32" />
                        </div>
                        <Skeleton className="h-4 w-12" />
                        <div className="flex items-center space-x-4">
                          <Skeleton className="h-6 w-32" />
                          <Skeleton className="h-12 w-12 rounded-full" />
                        </div>
                      </div>
                      <Skeleton className="h-10 w-full rounded-full" />
                      <div className="flex justify-between">
                        <Skeleton className="h-4 w-40" />
                        <Skeleton className="h-4 w-28" />
                      </div>
                      <div className="grid grid-cols-2 gap-4 mt-6">
                        <Skeleton className="h-24 w-full rounded" />
                        <Skeleton className="h-24 w-full rounded" />
                      </div>
                    </div>
                  ) : prediction ? (
                    <div>
                      {upcomingMatches && selectedMatchId && (
                        (() => {
                          const match = upcomingMatches.find(m => m.id.toString() === selectedMatchId);
                          if (!match) return <p>Match not found</p>;
                          
                          const team1 = getTeam(match.team1Id);
                          const team2 = getTeam(match.team2Id);
                          
                          return (
                            <>
                              <div className="flex items-center justify-between mb-6">
                                <div className="flex items-center space-x-3">
                                  {team1?.flagUrl ? (
                                    <img 
                                      src={team1.flagUrl} 
                                      alt={team1.name} 
                                      className="w-12 h-12 rounded-full object-cover border" 
                                    />
                                  ) : (
                                    <div className="w-12 h-12 rounded-full bg-gray-200 dark:bg-gray-700"></div>
                                  )}
                                  <span className="font-semibold text-lg dark:text-white">{team1?.name}</span>
                                </div>
                                <div className="text-sm text-gray-500">vs</div>
                                <div className="flex items-center space-x-3">
                                  <span className="font-semibold text-lg dark:text-white">{team2?.name}</span>
                                  {team2?.flagUrl ? (
                                    <img 
                                      src={team2.flagUrl} 
                                      alt={team2.name} 
                                      className="w-12 h-12 rounded-full object-cover border" 
                                    />
                                  ) : (
                                    <div className="w-12 h-12 rounded-full bg-gray-200 dark:bg-gray-700"></div>
                                  )}
                                </div>
                              </div>
                              
                              {/* Prediction Chart */}
                              <div className="flex items-center h-12 bg-gray-100 dark:bg-gray-700 rounded-full overflow-hidden mb-4">
                                <div 
                                  className="h-full bg-primary text-sm text-white flex items-center justify-center font-medium"
                                  style={{ width: `${prediction.team1WinProbability}%` }}
                                >
                                  {prediction.team1WinProbability}%
                                </div>
                                <div 
                                  className="h-full bg-amber-500 text-sm text-white flex items-center justify-center font-medium"
                                  style={{ width: `${prediction.team2WinProbability}%` }}
                                >
                                  {prediction.team2WinProbability}%
                                </div>
                              </div>
                              
                              <div className="flex justify-between text-sm text-gray-600 dark:text-gray-300 mb-6">
                                <span>
                                  {prediction.team1WinProbability > prediction.team2WinProbability
                                    ? `${team1?.name} favored to win`
                                    : prediction.team1WinProbability < prediction.team2WinProbability
                                      ? `${team2?.name} favored to win`
                                      : 'Even contest expected'}
                                </span>
                                <span>Confidence: {prediction.confidence}</span>
                              </div>
                              
                              <div className="grid grid-cols-2 gap-4 mt-4">
                                <Card>
                                  <CardContent className="p-4">
                                    <h3 className="font-semibold mb-2 dark:text-white text-sm">Projected Score:</h3>
                                    <p className="text-gray-700 dark:text-gray-300">{prediction.predictedScore}</p>
                                    
                                    <h3 className="font-semibold mt-4 mb-2 dark:text-white text-sm">Key Players:</h3>
                                    <ul className="list-disc pl-5 text-sm text-gray-700 dark:text-gray-300">
                                      {Array.isArray(prediction.keyPlayers) && prediction.keyPlayers.map((player, idx) => (
                                        <li key={idx}>{player}</li>
                                      ))}
                                    </ul>
                                  </CardContent>
                                </Card>
                                
                                <Card>
                                  <CardContent className="p-4">
                                    <h3 className="font-semibold mb-2 dark:text-white text-sm">Match Factors:</h3>
                                    <div className="space-y-2">
                                      <div className="flex justify-between text-sm">
                                        <span className="text-gray-500 dark:text-gray-400">Venue:</span>
                                        <span className="font-medium dark:text-white">{match.venue}</span>
                                      </div>
                                      <div className="flex justify-between text-sm">
                                        <span className="text-gray-500 dark:text-gray-400">Format:</span>
                                        <span className="font-medium dark:text-white">{match.matchType}</span>
                                      </div>
                                      <div className="flex justify-between text-sm">
                                        <span className="text-gray-500 dark:text-gray-400">Series:</span>
                                        <span className="font-medium dark:text-white">{match.seriesName}</span>
                                      </div>
                                    </div>
                                  </CardContent>
                                </Card>
                              </div>
                            </>
                          );
                        })()
                      )}
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <p className="text-gray-500 dark:text-gray-400">No prediction available for this match.</p>
                    </div>
                  )
                ) : (
                  <div className="text-center py-8">
                    <p className="text-gray-500 dark:text-gray-400">Select a match to view prediction.</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        {/* T20 Score Predictor Tab */}
        <TabsContent value="t20">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="md:col-span-2">
              <CardHeader>
                <CardTitle>T20 Score Predictor</CardTitle>
                <CardDescription>
                  Predict the final score based on current match situation
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...t20Form}>
                  <form onSubmit={t20Form.handleSubmit(onT20Submit)} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FormField
                        control={t20Form.control}
                        name="team"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Batting Team</FormLabel>
                            <Select 
                              onValueChange={field.onChange} 
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select team" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {teams?.map((team) => (
                                  <SelectItem key={team.id} value={team.id.toString()}>
                                    {team.name}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={t20Form.control}
                        name="opposition"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Bowling Team</FormLabel>
                            <Select 
                              onValueChange={field.onChange} 
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select opposition" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {teams?.map((team) => (
                                  <SelectItem key={team.id} value={team.id.toString()}>
                                    {team.name}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={t20Form.control}
                        name="venue"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Venue</FormLabel>
                            <Select 
                              onValueChange={field.onChange} 
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select venue" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="eden_gardens">Eden Gardens, Kolkata</SelectItem>
                                <SelectItem value="wankhede">Wankhede Stadium, Mumbai</SelectItem>
                                <SelectItem value="chinnaswamy">M. Chinnaswamy Stadium, Bangalore</SelectItem>
                                <SelectItem value="chepauk">M.A. Chidambaram Stadium, Chennai</SelectItem>
                                <SelectItem value="delhi">Arun Jaitley Stadium, Delhi</SelectItem>
                                <SelectItem value="hyderabad">Rajiv Gandhi Stadium, Hyderabad</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={t20Form.control}
                        name="pitchCondition"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Pitch Condition</FormLabel>
                            <Select 
                              onValueChange={field.onChange} 
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select pitch condition" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="batting">Batting Friendly</SelectItem>
                                <SelectItem value="normal">Balanced</SelectItem>
                                <SelectItem value="bowling">Bowling Friendly</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={t20Form.control}
                        name="currentScore"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Current Score</FormLabel>
                            <FormControl>
                              <Input type="number" min={0} {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={t20Form.control}
                        name="wicketsLost"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Wickets Lost</FormLabel>
                            <FormControl>
                              <Input type="number" min={0} max={10} {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={t20Form.control}
                        name="currentOver"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Current Over</FormLabel>
                            <FormControl>
                              <Input type="number" min={0} max={20} step={0.1} {...field} />
                            </FormControl>
                            <FormDescription>
                              Enter overs completed (e.g. 10.5 for 10.5 overs)
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={t20Form.control}
                        name="battingStrength"
                        render={({ field: { value, onChange } }) => (
                          <FormItem>
                            <FormLabel>Batting Strength (1-10)</FormLabel>
                            <FormControl>
                              <div className="pt-2">
                                <Slider
                                  defaultValue={[value]}
                                  min={1}
                                  max={10}
                                  step={1}
                                  onValueChange={(vals) => onChange(vals[0])}
                                />
                              </div>
                            </FormControl>
                            <FormDescription>
                              {value} - {value < 4 ? 'Weak' : value < 7 ? 'Average' : 'Strong'} batting lineup
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <Button type="submit" className="w-full" disabled={isCalculatingT20}>
                      {isCalculatingT20 ? 'Calculating...' : 'Predict Final Score'}
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
            
            <Card className="md:col-span-1">
              <CardHeader>
                <CardTitle>Prediction Result</CardTitle>
              </CardHeader>
              <CardContent>
                {isCalculatingT20 ? (
                  <div className="space-y-4 py-8">
                    <Skeleton className="h-8 w-full" />
                    <Skeleton className="h-16 w-full" />
                    <Skeleton className="h-4 w-3/4 mx-auto" />
                  </div>
                ) : t20Prediction ? (
                  <div className="text-center py-8">
                    <h3 className="text-lg font-medium mb-2 dark:text-white">Projected Final Score</h3>
                    <div className="text-4xl font-bold text-primary mb-4">
                      {t20Prediction.min} - {t20Prediction.max}
                    </div>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      Based on current match situation and conditions
                    </p>
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <p className="text-gray-500 dark:text-gray-400">
                      Fill in the match details to get a score prediction.
                    </p>
                  </div>
                )}
                
                <div className="mt-6 border-t pt-6 dark:border-gray-700">
                  <h3 className="font-semibold mb-4 dark:text-white">How it works:</h3>
                  <ul className="space-y-2 text-sm text-gray-600 dark:text-gray-300">
                    <li>• Analysis of historical match data</li>
                    <li>• Venue performance metrics</li>
                    <li>• Team batting/bowling strengths</li>
                    <li>• Current match situation</li>
                    <li>• Pitch and weather conditions</li>
                    <li>• Machine learning prediction model</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        {/* Fantasy Cricket Tab */}
        <TabsContent value="fantasy">
          <Card>
            <CardHeader>
              <CardTitle>Fantasy Cricket Suggestions</CardTitle>
              <CardDescription>
                Recommended players for your fantasy cricket team based on form and upcoming matches
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isLoadingFantasy ? (
                <div className="space-y-8">
                  <Skeleton className="h-8 w-64 mx-auto" />
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {Array(9).fill(0).map((_, idx) => (
                      <div key={idx} className="space-y-3">
                        <Skeleton className="h-40 w-full rounded-lg" />
                        <Skeleton className="h-6 w-3/4 mx-auto" />
                        <Skeleton className="h-4 w-1/2 mx-auto" />
                      </div>
                    ))}
                  </div>
                </div>
              ) : fantasyPlayers && fantasyPlayers.length > 0 ? (
                <div>
                  <h3 className="text-xl font-semibold text-center mb-6 dark:text-white">Top Players By Category</h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    <div>
                      <h4 className="text-lg font-medium text-center mb-4 dark:text-white">Top Batsmen</h4>
                      <div className="space-y-4">
                        <Card>
                          <CardContent className="p-4 flex items-center space-x-4">
                            <div className="h-16 w-16 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center overflow-hidden">
                              <img src="https://resources.pulse.icc-cricket.com/players/284/164.png" alt="Virat Kohli" className="h-full w-full object-cover" />
                            </div>
                            <div>
                              <h5 className="font-semibold dark:text-white">Virat Kohli</h5>
                              <p className="text-sm text-gray-500 dark:text-gray-400">India</p>
                              <div className="flex items-center mt-1">
                                <span className="text-xs px-2 py-0.5 bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100 rounded">TOP PICK</span>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                        
                        <Card>
                          <CardContent className="p-4 flex items-center space-x-4">
                            <div className="h-16 w-16 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center overflow-hidden">
                              <img src="https://resources.pulse.icc-cricket.com/players/284/2734.png" alt="Babar Azam" className="h-full w-full object-cover" />
                            </div>
                            <div>
                              <h5 className="font-semibold dark:text-white">Babar Azam</h5>
                              <p className="text-sm text-gray-500 dark:text-gray-400">Pakistan</p>
                              <div className="flex items-center mt-1">
                                <span className="text-xs px-2 py-0.5 bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-100 rounded">CONSISTENT</span>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                        
                        <Card>
                          <CardContent className="p-4 flex items-center space-x-4">
                            <div className="h-16 w-16 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center overflow-hidden">
                              <img src="https://resources.pulse.icc-cricket.com/players/284/2972.png" alt="Jos Buttler" className="h-full w-full object-cover" />
                            </div>
                            <div>
                              <h5 className="font-semibold dark:text-white">Jos Buttler</h5>
                              <p className="text-sm text-gray-500 dark:text-gray-400">England</p>
                              <div className="flex items-center mt-1">
                                <span className="text-xs px-2 py-0.5 bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-100 rounded">VALUE PICK</span>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      </div>
                    </div>
                    
                    <div>
                      <h4 className="text-lg font-medium text-center mb-4 dark:text-white">Top Bowlers</h4>
                      <div className="space-y-4">
                        <Card>
                          <CardContent className="p-4 flex items-center space-x-4">
                            <div className="h-16 w-16 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center overflow-hidden">
                              <img src="https://resources.pulse.icc-cricket.com/players/284/3667.png" alt="Jasprit Bumrah" className="h-full w-full object-cover" />
                            </div>
                            <div>
                              <h5 className="font-semibold dark:text-white">Jasprit Bumrah</h5>
                              <p className="text-sm text-gray-500 dark:text-gray-400">India</p>
                              <div className="flex items-center mt-1">
                                <span className="text-xs px-2 py-0.5 bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100 rounded">TOP PICK</span>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                        
                        <Card>
                          <CardContent className="p-4 flex items-center space-x-4">
                            <div className="h-16 w-16 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center overflow-hidden">
                              <img src="https://resources.pulse.icc-cricket.com/players/284/5802.png" alt="Shaheen Afridi" className="h-full w-full object-cover" />
                            </div>
                            <div>
                              <h5 className="font-semibold dark:text-white">Shaheen Afridi</h5>
                              <p className="text-sm text-gray-500 dark:text-gray-400">Pakistan</p>
                              <div className="flex items-center mt-1">
                                <span className="text-xs px-2 py-0.5 bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-100 rounded">HOT FORM</span>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                        
                        <Card>
                          <CardContent className="p-4 flex items-center space-x-4">
                            <div className="h-16 w-16 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center overflow-hidden">
                              <img src="https://resources.pulse.icc-cricket.com/players/284/4330.png" alt="Rashid Khan" className="h-full w-full object-cover" />
                            </div>
                            <div>
                              <h5 className="font-semibold dark:text-white">Rashid Khan</h5>
                              <p className="text-sm text-gray-500 dark:text-gray-400">Afghanistan</p>
                              <div className="flex items-center mt-1">
                                <span className="text-xs px-2 py-0.5 bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-100 rounded">MUST HAVE</span>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      </div>
                    </div>
                    
                    <div>
                      <h4 className="text-lg font-medium text-center mb-4 dark:text-white">Top All-Rounders</h4>
                      <div className="space-y-4">
                        <Card>
                          <CardContent className="p-4 flex items-center space-x-4">
                            <div className="h-16 w-16 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center overflow-hidden">
                              <img src="https://resources.pulse.icc-cricket.com/players/284/347.png" alt="Ben Stokes" className="h-full w-full object-cover" />
                            </div>
                            <div>
                              <h5 className="font-semibold dark:text-white">Ben Stokes</h5>
                              <p className="text-sm text-gray-500 dark:text-gray-400">England</p>
                              <div className="flex items-center mt-1">
                                <span className="text-xs px-2 py-0.5 bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100 rounded">TOP PICK</span>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                        
                        <Card>
                          <CardContent className="p-4 flex items-center space-x-4">
                            <div className="h-16 w-16 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center overflow-hidden">
                              <img src="https://resources.pulse.icc-cricket.com/players/284/2756.png" alt="Hardik Pandya" className="h-full w-full object-cover" />
                            </div>
                            <div>
                              <h5 className="font-semibold dark:text-white">Hardik Pandya</h5>
                              <p className="text-sm text-gray-500 dark:text-gray-400">India</p>
                              <div className="flex items-center mt-1">
                                <span className="text-xs px-2 py-0.5 bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-100 rounded">VALUE PICK</span>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                        
                        <Card>
                          <CardContent className="p-4 flex items-center space-x-4">
                            <div className="h-16 w-16 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center overflow-hidden">
                              <img src="https://resources.pulse.icc-cricket.com/players/284/6339.png" alt="Wanindu Hasaranga" className="h-full w-full object-cover" />
                            </div>
                            <div>
                              <h5 className="font-semibold dark:text-white">Wanindu Hasaranga</h5>
                              <p className="text-sm text-gray-500 dark:text-gray-400">Sri Lanka</p>
                              <div className="flex items-center mt-1">
                                <span className="text-xs px-2 py-0.5 bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-100 rounded">HOT FORM</span>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      </div>
                    </div>
                  </div>
                  
                  <div className="mt-10 text-center">
                    <Button className="bg-primary hover:bg-primary/90">
                      Create Your Fantasy Team
                    </Button>
                    <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">
                      Our AI will optimize your team based on upcoming matches
                    </p>
                  </div>
                </div>
              ) : (
                <div className="text-center py-8">
                  <p className="text-gray-500 dark:text-gray-400">
                    Fantasy cricket suggestions are currently unavailable.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Predictions;
