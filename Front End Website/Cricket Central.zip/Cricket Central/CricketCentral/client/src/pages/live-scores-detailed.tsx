import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { 
  AlertCircle, 
  Calendar, 
  Clock, 
  MapPin, 
  Users, 
  Trophy, 
  RefreshCw, 
  ChevronRight, 
  ChevronDown, 
  Filter,
  X
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { 
  type LiveMatch, 
  type MatchInfo, 
  cricketDataService,
  dateUtils,
  CricketApiError 
} from "@/services/cricket-data-api";

const LiveScores: React.FC = () => {
  const [activeTab, setActiveTab] = useState<"live" | "upcoming" | "recent">("live");
  const [selectedMatch, setSelectedMatch] = useState<string | null>(null);
  const [filterValue, setFilterValue] = useState<string>("all");

  // Queries for different match types
  const liveMatchesQuery = useQuery<LiveMatch[]>({
    queryKey: ['/api/cricket/matches/live'],
    queryFn: () => cricketDataService.getLiveMatches(),
    staleTime: 30 * 1000, // 30 seconds - data is considered fresh for 30 seconds
    refetchInterval: 30 * 1000, // Refetch every 30 seconds for live match updates
    refetchOnWindowFocus: true,
    retry: 3,
    retryDelay: attemptIndex => Math.min(1000 * 2 ** attemptIndex, 30000),
  });

  const upcomingMatchesQuery = useQuery<MatchInfo[]>({
    queryKey: ['/api/cricket/matches/upcoming'],
    queryFn: () => cricketDataService.getUpcomingMatches(),
    staleTime: 5 * 60 * 1000, // 5 minutes
    refetchInterval: 10 * 60 * 1000, // 10 minutes
    enabled: activeTab === "upcoming",
    retry: 3,
    retryDelay: attemptIndex => Math.min(1000 * 2 ** attemptIndex, 30000),
  });

  const recentMatchesQuery = useQuery<MatchInfo[]>({
    queryKey: ['/api/cricket/matches/recent'],
    queryFn: () => cricketDataService.getRecentMatches(),
    staleTime: 10 * 60 * 1000, // 10 minutes
    refetchInterval: 30 * 60 * 1000, // 30 minutes
    enabled: activeTab === "recent",
    retry: 3,
    retryDelay: attemptIndex => Math.min(1000 * 2 ** attemptIndex, 30000),
  });

  // Match details query for the selected match
  const matchDetailsQuery = useQuery<LiveMatch>({
    queryKey: ['/api/cricket/matches', selectedMatch],
    queryFn: () => cricketDataService.getMatchDetails(selectedMatch!),
    staleTime: 30 * 1000, // 30 seconds - for live match details
    refetchInterval: selectedMatch && liveMatchesQuery.data?.some(match => match.id === selectedMatch) 
      ? 30 * 1000 // Refetch every 30 seconds if it's a live match
      : undefined, // Don't auto-refetch for non-live matches
    enabled: selectedMatch !== null,
    retry: 3,
    retryDelay: attemptIndex => Math.min(1000 * 2 ** attemptIndex, 30000),
  });

  // Get current active query based on tab
  const getCurrentQuery = () => {
    switch (activeTab) {
      case "live":
        return liveMatchesQuery;
      case "upcoming":
        return upcomingMatchesQuery;
      case "recent":
        return recentMatchesQuery;
      default:
        return liveMatchesQuery;
    }
  };

  // Get filtered matches
  const getFilteredMatches = () => {
    const query = getCurrentQuery();
    if (!query.data) return [];
    
    if (filterValue === "all") return query.data;
    
    return query.data.filter((match: LiveMatch | MatchInfo) => {
      return (
        match.matchType?.toLowerCase() === filterValue.toLowerCase() ||
        (match.name && match.name.toLowerCase().includes(filterValue.toLowerCase()))
      );
    });
  };

  // Check if there's match data
  const hasMatches = () => {
    const query = getCurrentQuery();
    return query.data && query.data.length > 0;
  };

  // Handle match click
  const handleMatchClick = (matchId: string) => {
    setSelectedMatch(matchId);
  };

  // Handle tab change
  const handleTabChange = (value: string) => {
    setActiveTab(value as "live" | "upcoming" | "recent");
    setSelectedMatch(null);
  };

  // Format match date
  const formatMatchDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: 'short', 
      day: 'numeric' 
    });
  };

  // Format match time
  const formatMatchTime = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleTimeString('en-US', { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-800 dark:text-white mb-2">Cricket Matches</h1>
          <p className="text-gray-600 dark:text-gray-300">
            Live scores, upcoming fixtures, and recent results
          </p>
        </div>
        
        <div className="flex gap-2">
          <Select value={filterValue} onValueChange={setFilterValue}>
            <SelectTrigger className="w-[180px]">
              <div className="flex items-center">
                <Filter className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Filter By Format" />
              </div>
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Formats</SelectItem>
              <SelectItem value="t20">T20</SelectItem>
              <SelectItem value="odi">ODI</SelectItem>
              <SelectItem value="test">Test</SelectItem>
              <SelectItem value="t20i">T20I</SelectItem>
              <SelectItem value="odai">ODAI</SelectItem>
            </SelectContent>
          </Select>
          
          <Button 
            variant="outline" 
            onClick={() => getCurrentQuery().refetch()}
            disabled={getCurrentQuery().isFetching}
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${getCurrentQuery().isFetching ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Match List Panel */}
        <div className="lg:col-span-1">
          <Card className="h-full">
            <CardHeader className="pb-2">
              <Tabs defaultValue="live" value={activeTab} onValueChange={handleTabChange} className="w-full">
                <TabsList className="grid grid-cols-3 mb-4">
                  <TabsTrigger value="live" className="relative">
                    Live
                    {liveMatchesQuery.data && liveMatchesQuery.data.length > 0 && (
                      <Badge className="absolute -top-2 -right-2 h-5 w-5 p-0 flex items-center justify-center">
                        {liveMatchesQuery.data.length}
                      </Badge>
                    )}
                  </TabsTrigger>
                  <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
                  <TabsTrigger value="recent">Recent</TabsTrigger>
                </TabsList>
                
                <TabsContent value="live" className="m-0">
                  <CardTitle className="flex items-center text-lg">
                    <AlertCircle className="text-red-500 dark:text-red-400 h-5 w-5 mr-2 animate-pulse" />
                    Live Matches
                  </CardTitle>
                  <CardDescription>
                    Matches currently in progress
                  </CardDescription>
                </TabsContent>
                
                <TabsContent value="upcoming" className="m-0">
                  <CardTitle className="flex items-center text-lg">
                    <Calendar className="text-blue-500 dark:text-blue-400 h-5 w-5 mr-2" />
                    Upcoming Fixtures
                  </CardTitle>
                  <CardDescription>
                    Schedule of upcoming cricket matches
                  </CardDescription>
                </TabsContent>
                
                <TabsContent value="recent" className="m-0">
                  <CardTitle className="flex items-center text-lg">
                    <Trophy className="text-amber-500 dark:text-amber-400 h-5 w-5 mr-2" />
                    Recent Results
                  </CardTitle>
                  <CardDescription>
                    Recently completed matches and results
                  </CardDescription>
                </TabsContent>
              </Tabs>
            </CardHeader>
            
            <CardContent>
              {getCurrentQuery().isPending ? (
                <MatchListSkeleton />
              ) : getCurrentQuery().isError ? (
                <div className="text-center py-8">
                  <p className="text-red-500 mb-4">Failed to load matches. Please try again later.</p>
                  <Button 
                    onClick={() => getCurrentQuery().refetch()}
                    variant="outline"
                  >
                    <RefreshCw className="mr-2 h-4 w-4" />
                    Try Again
                  </Button>
                </div>
              ) : !hasMatches() ? (
                <div className="text-center py-8">
                  <p className="text-gray-500">
                    {activeTab === "live" 
                      ? "No live matches at the moment" 
                      : activeTab === "upcoming" 
                      ? "No upcoming matches found" 
                      : "No recent match results available"}
                  </p>
                </div>
              ) : (
                <ScrollArea className="h-[600px] pr-4">
                  <div className="space-y-3">
                    {getFilteredMatches().length === 0 ? (
                      <div className="text-center py-8">
                        <p className="text-gray-500">No matches match your filter criteria</p>
                        <Button variant="ghost" onClick={() => setFilterValue("all")} className="mt-2">
                          <X className="mr-2 h-4 w-4" />
                          Clear Filter
                        </Button>
                      </div>
                    ) : (
                      getFilteredMatches().map((match: LiveMatch | MatchInfo) => (
                        <div 
                          key={match.id}
                          className={`p-4 rounded-lg cursor-pointer transition-colors ${
                            selectedMatch === match.id 
                              ? 'bg-primary/10 border border-primary/30' 
                              : 'bg-gray-50 dark:bg-gray-800 hover:bg-gray-100 dark:hover:bg-gray-700'
                          }`}
                          onClick={() => handleMatchClick(match.id)}
                        >
                          <div className="flex justify-between items-start mb-3">
                            <Badge variant={activeTab === "live" ? "destructive" : activeTab === "upcoming" ? "secondary" : "outline"}>
                              {match.matchType || "Match"}
                            </Badge>
                            <span className="text-xs text-gray-500 dark:text-gray-400">
                              {formatMatchDate(match.dateTimeGMT)}
                            </span>
                          </div>
                          
                          <h3 className="font-medium text-gray-800 dark:text-white mb-3 line-clamp-2">
                            {match.name}
                          </h3>
                          
                          <div className="flex items-center justify-between">
                            <div className="flex items-center text-sm text-gray-600 dark:text-gray-300">
                              <Clock className="h-3 w-3 mr-1" />
                              <span>{formatMatchTime(match.dateTimeGMT)}</span>
                            </div>
                            
                            <div className="flex items-center text-sm">
                              <MapPin className="h-3 w-3 mr-1 text-gray-500 dark:text-gray-400" />
                              <span className="text-gray-600 dark:text-gray-300">{match.venue}</span>
                            </div>
                          </div>
                          
                          {'score' in match && activeTab === "live" && (
                            <div className="mt-3 pt-3 border-t border-gray-200 dark:border-gray-700">
                              {match.score?.map((scoreItem, index) => (
                                <div key={index} className="flex justify-between items-center mb-1 last:mb-0">
                                  <span className="font-medium">
                                    {scoreItem.inning.split('Inning')[0]}
                                  </span>
                                  <span className="text-gray-800 dark:text-white">
                                    {scoreItem.r}-{scoreItem.w} ({scoreItem.o})
                                  </span>
                                </div>
                              ))}
                            </div>
                          )}
                          
                          {activeTab === "live" && (
                            <div className="mt-3 text-sm text-primary dark:text-primary-foreground font-medium">
                              {'status' in match && match.status}
                            </div>
                          )}
                        </div>
                      ))
                    )}
                  </div>
                </ScrollArea>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Match Details Panel */}
        <div className="lg:col-span-2">
          <Card className="h-full">
            {!selectedMatch ? (
              <div className="flex flex-col items-center justify-center h-full py-12 px-4 text-center">
                <Users className="h-16 w-16 text-gray-300 dark:text-gray-600 mb-4" />
                <h3 className="text-xl font-medium text-gray-700 dark:text-gray-300 mb-2">No Match Selected</h3>
                <p className="text-gray-500 dark:text-gray-400 max-w-md">
                  Select a match from the list to view detailed information
                </p>
              </div>
            ) : matchDetailsQuery.isPending ? (
              <MatchDetailsSkeleton />
            ) : matchDetailsQuery.isError ? (
              <div className="flex flex-col items-center justify-center h-full py-12 px-4 text-center">
                <p className="text-red-500 mb-4">Failed to load match details. Please try again later.</p>
                <Button 
                  onClick={() => matchDetailsQuery.refetch()}
                  variant="outline"
                >
                  <RefreshCw className="mr-2 h-4 w-4" />
                  Try Again
                </Button>
              </div>
            ) : (
              <MatchDetails match={matchDetailsQuery.data} />
            )}
          </Card>
        </div>
      </div>
    </div>
  );
};

interface MatchDetailsProps {
  match: LiveMatch;
}

const MatchDetails: React.FC<MatchDetailsProps> = ({ match }) => {
  // Use the dateUtils helper to determine if a match is live
  const isLiveMatch = () => {
    return dateUtils.isMatchLive(match);
  };
  
  // Function to get match status class with more accurate states
  const getStatusClass = () => {
    if (dateUtils.isMatchLive(match)) {
      return "text-red-500 dark:text-red-400 animate-pulse";
    } else if (match.matchEnded) {
      return "text-green-500 dark:text-green-400";
    } else {
      return "text-blue-500 dark:text-blue-400";
    }
  };
  
  // Calculate match progress using our utility
  const matchProgress = dateUtils.calculateMatchProgress(match);

  return (
    <>
      <CardHeader className="border-b">
        <div className="flex items-center justify-between">
          <div>
            <Badge variant="outline" className="mb-2">
              {match.matchType || "Match"}
            </Badge>
            <CardTitle className="text-xl">{match.name}</CardTitle>
            <CardDescription>
              {match.venue} • {new Date(match.dateTimeGMT).toLocaleDateString('en-US', { 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
              })}
            </CardDescription>
          </div>
          <div className={`font-medium ${getStatusClass()}`}>
            {isLiveMatch() 
              ? "LIVE" 
              : match.matchEnded 
              ? "COMPLETED" 
              : "UPCOMING"}
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="pt-6">
        {isLiveMatch() && (
          <>
            {/* Match Progress Bar */}
            <div className="mb-6">
              <div className="flex justify-between items-center mb-2">
                <h3 className="text-lg font-semibold">Match Progress</h3>
                <span className="text-sm text-gray-500 dark:text-gray-400">{matchProgress}%</span>
              </div>
              <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                <div 
                  className="bg-primary h-2 rounded-full transition-all duration-300" 
                  style={{ width: `${matchProgress}%` }}
                ></div>
              </div>
            </div>
          </>
        )}
        
        {isLiveMatch() && match.score && (
          <div className="mb-8">
            <h3 className="text-lg font-semibold mb-4">Live Scorecard</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {match.teamInfo?.map((team, index) => {
                // Find score for this team
                const teamScores = match.score?.filter(s => 
                  s.inning.includes(team.name) || s.inning.includes(team.shortname)
                );
                
                return (
                  <Card key={index} className="overflow-hidden">
                    <CardHeader className="p-4 bg-gray-50 dark:bg-gray-800 flex flex-row items-center space-y-0">
                      {team.img && (
                        <img 
                          src={team.img} 
                          alt={team.name} 
                          className="w-8 h-8 mr-3 object-contain"
                        />
                      )}
                      <CardTitle className="text-base">{team.name}</CardTitle>
                    </CardHeader>
                    <CardContent className="p-4">
                      {teamScores && teamScores.length > 0 ? (
                        teamScores.map((score, idx) => (
                          <div key={idx} className="mb-2 last:mb-0">
                            <div className="text-2xl font-bold mb-1">
                              {score.r}-{score.w} <span className="text-sm font-normal">({score.o} overs)</span>
                            </div>
                            <div className="text-sm text-gray-500">
                              {score.inning}
                            </div>
                          </div>
                        ))
                      ) : (
                        <div className="text-gray-500">No score available</div>
                      )}
                    </CardContent>
                  </Card>
                );
              })}
            </div>
            
            <div className="mt-4 p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
              <p className="font-medium text-gray-800 dark:text-white">
                {match.status}
              </p>
            </div>
          </div>
        )}
        
        <div className="mb-6">
          <h3 className="text-lg font-semibold mb-4">Teams</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {match.teamInfo?.map((team, index) => (
              <div 
                key={index}
                className="flex items-center p-4 bg-gray-50 dark:bg-gray-800 rounded-lg"
              >
                {team.img ? (
                  <img 
                    src={team.img} 
                    alt={team.name} 
                    className="w-12 h-12 mr-4 object-contain"
                  />
                ) : (
                  <div className="w-12 h-12 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center mr-4">
                    <Users className="h-6 w-6 text-gray-500 dark:text-gray-400" />
                  </div>
                )}
                <div>
                  <h4 className="font-medium text-gray-800 dark:text-white">
                    {team.name}
                  </h4>
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    {team.shortname}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
        
        {match.matchEnded && match.score && (
          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="match-result">
              <AccordionTrigger className="text-lg font-medium">
                Match Result
              </AccordionTrigger>
              <AccordionContent>
                <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
                  <h4 className="font-medium text-lg mb-4">Final Scores</h4>
                  
                  {match.score?.map((score, index) => (
                    <div 
                      key={index}
                      className="mb-3 last:mb-0 pb-3 last:pb-0 border-b last:border-0 border-gray-200 dark:border-gray-700"
                    >
                      <div className="flex justify-between items-center mb-1">
                        <span className="font-medium">{score.inning}</span>
                        <span className="text-lg font-bold">
                          {score.r}-{score.w} ({score.o} overs)
                        </span>
                      </div>
                    </div>
                  ))}
                  
                  <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700">
                    <p className="font-medium text-primary dark:text-primary-foreground">
                      {match.status}
                    </p>
                  </div>
                </div>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        )}
        
        <div className="mt-6">
          <h3 className="text-lg font-semibold mb-4">Match Information</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
              <h4 className="text-sm text-gray-500 dark:text-gray-400 mb-1">Series</h4>
              <p className="font-medium">{match.seriesId || "International Cricket"}</p>
            </div>
            <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
              <h4 className="text-sm text-gray-500 dark:text-gray-400 mb-1">Format</h4>
              <p className="font-medium">{match.matchType || "Cricket Match"}</p>
            </div>
            <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
              <h4 className="text-sm text-gray-500 dark:text-gray-400 mb-1">Venue</h4>
              <p className="font-medium">{match.venue}</p>
            </div>
            <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
              <h4 className="text-sm text-gray-500 dark:text-gray-400 mb-1">Date & Time</h4>
              <p className="font-medium">
                {new Date(match.dateTimeGMT).toLocaleDateString('en-US', { 
                  year: 'numeric', 
                  month: 'long', 
                  day: 'numeric',
                  hour: '2-digit',
                  minute: '2-digit'
                })}
              </p>
            </div>
          </div>
        </div>
      </CardContent>
    </>
  );
};

const MatchListSkeleton: React.FC = () => {
  return (
    <div className="space-y-3">
      {Array(5).fill(0).map((_, index) => (
        <div key={index} className="p-4 rounded-lg bg-gray-50 dark:bg-gray-800">
          <div className="flex justify-between items-start mb-3">
            <Skeleton className="h-5 w-16" />
            <Skeleton className="h-4 w-24" />
          </div>
          <Skeleton className="h-5 w-full mb-3" />
          <Skeleton className="h-5 w-3/4 mb-3" />
          <div className="flex justify-between">
            <Skeleton className="h-4 w-20" />
            <Skeleton className="h-4 w-24" />
          </div>
        </div>
      ))}
    </div>
  );
};

const MatchDetailsSkeleton: React.FC = () => {
  return (
    <>
      <CardHeader className="border-b">
        <div className="flex justify-between">
          <div>
            <Skeleton className="h-5 w-20 mb-2" />
            <Skeleton className="h-7 w-72 mb-2" />
            <Skeleton className="h-4 w-48" />
          </div>
          <Skeleton className="h-6 w-24" />
        </div>
      </CardHeader>
      <CardContent className="pt-6">
        <Skeleton className="h-6 w-48 mb-4" />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
          <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg">
            <div className="flex items-center mb-3">
              <Skeleton className="h-8 w-8 rounded-full mr-3" />
              <Skeleton className="h-5 w-32" />
            </div>
            <Skeleton className="h-8 w-32 mb-2" />
            <Skeleton className="h-4 w-full" />
          </div>
          <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg">
            <div className="flex items-center mb-3">
              <Skeleton className="h-8 w-8 rounded-full mr-3" />
              <Skeleton className="h-5 w-32" />
            </div>
            <Skeleton className="h-8 w-32 mb-2" />
            <Skeleton className="h-4 w-full" />
          </div>
        </div>
        
        <Skeleton className="h-6 w-48 mb-4" />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Skeleton className="h-24" />
          <Skeleton className="h-24" />
        </div>
      </CardContent>
    </>
  );
};

export default LiveScores;