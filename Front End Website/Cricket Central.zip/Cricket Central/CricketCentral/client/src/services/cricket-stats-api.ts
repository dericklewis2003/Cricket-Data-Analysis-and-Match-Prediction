// Cricket Stats API Service
import { CricketApiError } from "./cricket-data-api";

// Player Statistics Types
export interface BattingStats {
  matches: number;
  innings: number;
  runs: number;
  average: number;
  strikeRate: number;
  fifties: number;
  hundreds: number;
  highestScore: number | string;
  fours?: number;
  sixes?: number;
}

export interface BowlingStats {
  matches: number;
  innings: number;
  wickets: number;
  average: number;
  economy: number;
  bestFigures: string;
  fourWickets?: number;
  fiveWickets?: number;
}

export interface PlayerStats {
  id: string;
  name: string;
  team: string;
  teamId?: string;
  imageUrl?: string;
  battingStats?: BattingStats;
  bowlingStats?: BowlingStats;
}

export interface TeamStats {
  id: string;
  name: string;
  matches: number;
  won: number;
  lost: number;
  tied: number;
  noResult: number;
  winPercentage: number;
  imageUrl?: string;
}

// Performance monitoring
export interface PerformanceMetrics {
  endpoint: string;
  startTime: number;
  endTime: number;
  duration: number;
  success: boolean;
}

// Stats API Service with error handling, retries, and performance monitoring
export const cricketStatsService = {
  // Performance metrics collector
  metrics: [] as PerformanceMetrics[],
  
  /**
   * Log performance metrics
   */
  logPerformance(endpoint: string, startTime: number, endTime: number, success: boolean) {
    const metrics: PerformanceMetrics = {
      endpoint,
      startTime,
      endTime,
      duration: endTime - startTime,
      success
    };
    
    this.metrics.push(metrics);
    console.debug(`API Performance: ${endpoint} - ${metrics.duration}ms - ${success ? 'Success' : 'Failed'}`);
    
    // Keep only last 50 metrics to avoid memory issues
    if (this.metrics.length > 50) {
      this.metrics = this.metrics.slice(-50);
    }
    
    return metrics;
  },
  
  /**
   * Get average response time for endpoint
   */
  getAverageResponseTime(endpoint?: string): number {
    const relevantMetrics = endpoint 
      ? this.metrics.filter(m => m.endpoint.includes(endpoint) && m.success)
      : this.metrics.filter(m => m.success);
      
    if (relevantMetrics.length === 0) return 0;
    
    const totalDuration = relevantMetrics.reduce((sum, metric) => sum + metric.duration, 0);
    return Math.round(totalDuration / relevantMetrics.length);
  },
  
  /**
   * Fetch with retry and performance logging
   */
  async fetchWithRetryAndMetrics<T>(
    url: string,
    options?: RequestInit,
    maxRetries = 2
  ): Promise<T> {
    let retries = 0;
    const startTime = performance.now();
    let endTime: number;
    
    while (retries <= maxRetries) {
      try {
        const res = await fetch(url, options);
        
        if (!res.ok) {
          const errorMsg = `Failed to fetch from ${url}: ${res.status} ${res.statusText}`;
          
          if ([429, 500, 502, 503, 504].includes(res.status) && retries < maxRetries) {
            retries++;
            await new Promise(resolve => setTimeout(resolve, 1000 * retries));
            continue;
          }
          
          endTime = performance.now();
          this.logPerformance(url, startTime, endTime, false);
          
          throw new CricketApiError(
            errorMsg,
            res.status,
            url
          );
        }
        
        const data = await res.json();
        endTime = performance.now();
        this.logPerformance(url, startTime, endTime, true);
        
        return data as T;
      } catch (error) {
        if (retries >= maxRetries) {
          endTime = performance.now();
          this.logPerformance(url, startTime, endTime, false);
          console.error(`Error fetching from ${url}:`, error);
          throw error;
        }
        retries++;
        await new Promise(resolve => setTimeout(resolve, 1000 * retries));
      }
    }
    
    endTime = performance.now();
    this.logPerformance(url, startTime, endTime, false);
    throw new Error(`Failed to fetch data from ${url} after multiple attempts`);
  },
  
  /**
   * Get top batsmen stats by format (T20, ODI, Test)
   */
  async getTopBatsmen(format: string = 't20', limit: number = 10): Promise<PlayerStats[]> {
    return this.fetchWithRetryAndMetrics<PlayerStats[]>(
      `/api/cricket/stats/batting?format=${format.toLowerCase()}&limit=${limit}`
    );
  },
  
  /**
   * Get top bowlers stats by format (T20, ODI, Test)
   */
  async getTopBowlers(format: string = 't20', limit: number = 10): Promise<PlayerStats[]> {
    return this.fetchWithRetryAndMetrics<PlayerStats[]>(
      `/api/cricket/stats/bowling?format=${format.toLowerCase()}&limit=${limit}`
    );
  },
  
  /**
   * Get team performance stats by format
   */
  async getTeamStats(format: string = 't20'): Promise<TeamStats[]> {
    return this.fetchWithRetryAndMetrics<TeamStats[]>(
      `/api/cricket/stats/teams?format=${format.toLowerCase()}`
    );
  },
  
  /**
   * Search for player stats by name
   */
  async searchPlayerStats(name: string, format: string = 't20'): Promise<PlayerStats[]> {
    if (!name || name.trim() === '') {
      return [];
    }
    
    return this.fetchWithRetryAndMetrics<PlayerStats[]>(
      `/api/cricket/stats/search?name=${encodeURIComponent(name)}&format=${format.toLowerCase()}`
    );
  },
  
  /**
   * Get detailed stats for specific player by ID
   */
  async getPlayerDetailedStats(playerId: string, format: string = 't20'): Promise<PlayerStats> {
    return this.fetchWithRetryAndMetrics<PlayerStats>(
      `/api/cricket/stats/player/${playerId}?format=${format.toLowerCase()}`
    );
  }
};