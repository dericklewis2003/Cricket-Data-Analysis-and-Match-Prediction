// Cricket API Response Types with improved type safety
export interface LiveMatch {
  id: string;
  name: string;
  matchType: string;
  status: string;
  venue: string;
  date: string;
  dateTimeGMT: string;
  teams: string[];
  teamInfo: TeamInfo[];
  score: Score[];
  seriesId: string;
  fantasyEnabled: boolean;
  bbbEnabled: boolean;
  hasPoints: boolean;
  matchStarted: boolean;
  matchEnded: boolean;
}

interface TeamInfo {
  name: string;
  shortname: string;
  img: string;
}

interface Score {
  r: number;
  w: number;
  o: number;
  inning: string;
}

export interface MatchInfo {
  id: string;
  name: string;
  status: string;
  matchType: string;
  venue: string;
  date: string;
  dateTimeGMT: string;
  teams: string[];
}

export interface PlayerInfo {
  id: string;
  name: string;
  country: string;
  playerImg: string;
  battingStyle: string;
  bowlingStyle: string;
  stats: PlayerStats;
}

interface PlayerStats {
  batting: {
    [format: string]: {
      matches: number;
      innings: number;
      runs: number;
      balls: number;
      highest: number;
      notOuts: number;
      average: number;
      strikeRate: number;
      hundreds: number;
      fifties: number;
      fours: number;
      sixes: number;
    };
  };
  bowling: {
    [format: string]: {
      matches: number;
      innings: number;
      balls: number;
      overs: number;
      runs: number;
      wickets: number;
      economy: number;
      average: number;
      strikeRate: number;
      bestInning: string;
      bestMatch: string;
    };
  };
}

// API Error Class for better error handling
export class CricketApiError extends Error {
  status: number;
  endpoint: string;
  
  constructor(message: string, status: number, endpoint: string) {
    super(message);
    this.name = 'CricketApiError';
    this.status = status;
    this.endpoint = endpoint;
  }
}

// Date formatting utilities
export const dateUtils = {
  /**
   * Format date to readable format
   */
  formatMatchDate: (dateString: string): string => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: 'short', 
      day: 'numeric' 
    });
  },
  
  /**
   * Format time to readable format
   */
  formatMatchTime: (dateString: string): string => {
    const date = new Date(dateString);
    return date.toLocaleTimeString('en-US', { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  },
  
  /**
   * Get days until match
   */
  getDaysUntil: (dateString: string): string => {
    const now = new Date();
    now.setHours(0, 0, 0, 0); // Reset time component for accurate day comparison
    
    const matchDate = new Date(dateString);
    matchDate.setHours(0, 0, 0, 0);
    
    const diffTime = matchDate.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) return 'TODAY';
    if (diffDays === 1) return 'TOMORROW';
    if (diffDays < 0) return 'COMPLETED';
    return `IN ${diffDays} DAYS`;
  },
  
  /**
   * Check if a match is live based on its status and timestamps
   */
  isMatchLive: (match: LiveMatch): boolean => {
    return match.matchStarted && !match.matchEnded;
  },
  
  /**
   * Calculate match progress percentage
   */
  calculateMatchProgress: (match: LiveMatch): number => {
    if (!match.score || match.score.length === 0) return 0;
    
    // Find the highest over count
    const maxOvers = match.score.reduce((max, score) => Math.max(max, score.o || 0), 0);
    
    const matchType = match.matchType.toLowerCase();
    let totalOvers = 50; // Default for ODI
    
    if (matchType.includes('t20')) {
      totalOvers = 20;
    } else if (matchType.includes('test')) {
      // For Test matches, use a different approach
      return match.matchStarted ? (match.matchEnded ? 100 : 50) : 0;
    }
    
    return Math.min(100, Math.round((maxOvers / totalOvers) * 100));
  }
};

// Main Cricket Data Service with improved error handling
export const cricketDataService = {
  /**
   * Get current live matches with retry logic
   */
  getLiveMatches: async (maxRetries = 2): Promise<LiveMatch[]> => {
    let retries = 0;
    
    while (retries <= maxRetries) {
      try {
        const res = await fetch('/api/cricket/matches/live');
        
        if (!res.ok) {
          const errorMsg = `Failed to fetch live matches: ${res.status} ${res.statusText}`;
          
          if ([429, 500, 502, 503, 504].includes(res.status) && retries < maxRetries) {
            // Retry for rate limiting or server errors
            retries++;
            await new Promise(resolve => setTimeout(resolve, 1000 * retries));
            continue;
          }
          
          throw new CricketApiError(
            errorMsg,
            res.status,
            '/api/cricket/matches/live'
          );
        }
        
        const data = await res.json();
        
        // Validate data structure
        if (!Array.isArray(data)) {
          throw new CricketApiError(
            'Invalid data format: expected an array of matches',
            200,
            '/api/cricket/matches/live'
          );
        }
        
        return data;
      } catch (error) {
        if (retries >= maxRetries) {
          console.error('Error fetching live matches:', error);
          throw error;
        }
        retries++;
        await new Promise(resolve => setTimeout(resolve, 1000 * retries));
      }
    }
    
    // This should not be reached due to the throw in the catch block
    throw new Error('Failed to fetch live matches after multiple attempts');
  },

  /**
   * Get upcoming matches (fixtures) with retry logic
   */
  getUpcomingMatches: async (maxRetries = 2): Promise<MatchInfo[]> => {
    let retries = 0;
    
    while (retries <= maxRetries) {
      try {
        const res = await fetch('/api/cricket/matches/upcoming');
        
        if (!res.ok) {
          const errorMsg = `Failed to fetch upcoming matches: ${res.status} ${res.statusText}`;
          
          if ([429, 500, 502, 503, 504].includes(res.status) && retries < maxRetries) {
            retries++;
            await new Promise(resolve => setTimeout(resolve, 1000 * retries));
            continue;
          }
          
          throw new CricketApiError(
            errorMsg,
            res.status,
            '/api/cricket/matches/upcoming'
          );
        }
        
        const data = await res.json();
        
        // Validate data structure
        if (!Array.isArray(data)) {
          throw new CricketApiError(
            'Invalid data format: expected an array of matches',
            200,
            '/api/cricket/matches/upcoming'
          );
        }
        
        return data;
      } catch (error) {
        if (retries >= maxRetries) {
          console.error('Error fetching upcoming matches:', error);
          throw error;
        }
        retries++;
        await new Promise(resolve => setTimeout(resolve, 1000 * retries));
      }
    }
    
    throw new Error('Failed to fetch upcoming matches after multiple attempts');
  },

  /**
   * Get recent match results with retry logic
   */
  getRecentMatches: async (maxRetries = 2): Promise<MatchInfo[]> => {
    let retries = 0;
    
    while (retries <= maxRetries) {
      try {
        const res = await fetch('/api/cricket/matches/recent');
        
        if (!res.ok) {
          const errorMsg = `Failed to fetch recent matches: ${res.status} ${res.statusText}`;
          
          if ([429, 500, 502, 503, 504].includes(res.status) && retries < maxRetries) {
            retries++;
            await new Promise(resolve => setTimeout(resolve, 1000 * retries));
            continue;
          }
          
          throw new CricketApiError(
            errorMsg,
            res.status,
            '/api/cricket/matches/recent'
          );
        }
        
        const data = await res.json();
        
        // Validate data structure
        if (!Array.isArray(data)) {
          throw new CricketApiError(
            'Invalid data format: expected an array of matches',
            200,
            '/api/cricket/matches/recent'
          );
        }
        
        return data;
      } catch (error) {
        if (retries >= maxRetries) {
          console.error('Error fetching recent matches:', error);
          throw error;
        }
        retries++;
        await new Promise(resolve => setTimeout(resolve, 1000 * retries));
      }
    }
    
    throw new Error('Failed to fetch recent matches after multiple attempts');
  },

  /**
   * Search for player by name with retry logic
   */
  searchPlayer: async (name: string, maxRetries = 2): Promise<PlayerInfo[]> => {
    if (!name.trim()) {
      return [];
    }
    
    let retries = 0;
    
    while (retries <= maxRetries) {
      try {
        const res = await fetch(`/api/cricket/players/search?name=${encodeURIComponent(name)}`);
        
        if (!res.ok) {
          const errorMsg = `Failed to search player: ${res.status} ${res.statusText}`;
          
          if ([429, 500, 502, 503, 504].includes(res.status) && retries < maxRetries) {
            retries++;
            await new Promise(resolve => setTimeout(resolve, 1000 * retries));
            continue;
          }
          
          throw new CricketApiError(
            errorMsg,
            res.status,
            `/api/cricket/players/search?name=${name}`
          );
        }
        
        return await res.json();
      } catch (error) {
        if (retries >= maxRetries) {
          console.error('Error searching player:', error);
          throw error;
        }
        retries++;
        await new Promise(resolve => setTimeout(resolve, 1000 * retries));
      }
    }
    
    throw new Error('Failed to search player after multiple attempts');
  },

  /**
   * Get player details by ID with retry logic
   */
  getPlayerDetails: async (id: string, maxRetries = 2): Promise<PlayerInfo> => {
    if (!id) {
      throw new Error('Player ID is required');
    }
    
    let retries = 0;
    
    while (retries <= maxRetries) {
      try {
        const res = await fetch(`/api/cricket/players/${id}`);
        
        if (!res.ok) {
          const errorMsg = `Failed to fetch player details: ${res.status} ${res.statusText}`;
          
          if ([429, 500, 502, 503, 504].includes(res.status) && retries < maxRetries) {
            retries++;
            await new Promise(resolve => setTimeout(resolve, 1000 * retries));
            continue;
          }
          
          throw new CricketApiError(
            errorMsg,
            res.status,
            `/api/cricket/players/${id}`
          );
        }
        
        return await res.json();
      } catch (error) {
        if (retries >= maxRetries) {
          console.error('Error fetching player details:', error);
          throw error;
        }
        retries++;
        await new Promise(resolve => setTimeout(resolve, 1000 * retries));
      }
    }
    
    throw new Error('Failed to fetch player details after multiple attempts');
  },

  /**
   * Get match details by ID with retry logic
   */
  getMatchDetails: async (id: string, maxRetries = 2): Promise<LiveMatch> => {
    if (!id) {
      throw new Error('Match ID is required');
    }
    
    let retries = 0;
    
    while (retries <= maxRetries) {
      try {
        const res = await fetch(`/api/cricket/matches/${id}`);
        
        if (!res.ok) {
          const errorMsg = `Failed to fetch match details: ${res.status} ${res.statusText}`;
          
          if ([429, 500, 502, 503, 504].includes(res.status) && retries < maxRetries) {
            retries++;
            await new Promise(resolve => setTimeout(resolve, 1000 * retries));
            continue;
          }
          
          throw new CricketApiError(
            errorMsg,
            res.status,
            `/api/cricket/matches/${id}`
          );
        }
        
        return await res.json();
      } catch (error) {
        if (retries >= maxRetries) {
          console.error('Error fetching match details:', error);
          throw error;
        }
        retries++;
        await new Promise(resolve => setTimeout(resolve, 1000 * retries));
      }
    }
    
    throw new Error('Failed to fetch match details after multiple attempts');
  }
};