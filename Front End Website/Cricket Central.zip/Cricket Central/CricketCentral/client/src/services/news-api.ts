import { apiRequest } from '@/lib/queryClient';

interface NewsArticle {
  source: {
    id: string | null;
    name: string;
  };
  author: string | null;
  title: string;
  description: string | null;
  url: string;
  urlToImage: string | null;
  publishedAt: string;
  content: string | null;
}

interface NewsResponse {
  status: string;
  totalResults: number;
  articles: NewsArticle[];
}

export type { NewsArticle, NewsResponse };

export const newsService = {
  /**
   * Get the latest cricket news
   * @param page Page number
   * @param pageSize Number of news per page
   */
  getLatestNews: async (page: number = 1, pageSize: number = 10): Promise<NewsResponse> => {
    try {
      const res = await fetch(`/api/news?page=${page}&pageSize=${pageSize}`);
      
      if (!res.ok) {
        throw new Error(`Failed to fetch news: ${res.status} ${res.statusText}`);
      }
      
      return await res.json();
    } catch (error) {
      console.error('Error fetching cricket news:', error);
      throw error;
    }
  },

  /**
   * Search for cricket news by keyword
   * @param query Search query
   * @param page Page number
   * @param pageSize Number of news per page
   */
  searchNews: async (query: string, page: number = 1, pageSize: number = 10): Promise<NewsResponse> => {
    try {
      const res = await fetch(`/api/news/search?q=${encodeURIComponent(query)}&page=${page}&pageSize=${pageSize}`);
      
      if (!res.ok) {
        throw new Error(`Failed to search news: ${res.status} ${res.statusText}`);
      }
      
      return await res.json();
    } catch (error) {
      console.error('Error searching cricket news:', error);
      throw error;
    }
  }
};