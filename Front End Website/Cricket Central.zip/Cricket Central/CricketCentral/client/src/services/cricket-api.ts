import { Match, Team, Prediction, FantasyPlayer } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

// Base URL for API requests
const API_BASE_URL = "/api";

// Team related API calls
export const teamService = {
  getAllTeams: async (): Promise<Team[]> => {
    const response = await fetch(`${API_BASE_URL}/teams`);
    if (!response.ok) {
      throw new Error(`Failed to fetch teams: ${response.status}`);
    }
    return response.json();
  },
  
  getTeamById: async (id: number): Promise<Team> => {
    const response = await fetch(`${API_BASE_URL}/teams/${id}`);
    if (!response.ok) {
      throw new Error(`Failed to fetch team: ${response.status}`);
    }
    return response.json();
  }
};

// Match related API calls
export const matchService = {
  getAllMatches: async (): Promise<Match[]> => {
    const response = await fetch(`${API_BASE_URL}/matches`);
    if (!response.ok) {
      throw new Error(`Failed to fetch matches: ${response.status}`);
    }
    return response.json();
  },
  
  getLiveMatches: async (): Promise<Match[]> => {
    const response = await fetch(`${API_BASE_URL}/matches/live`);
    if (!response.ok) {
      throw new Error(`Failed to fetch live matches: ${response.status}`);
    }
    return response.json();
  },
  
  getRecentMatches: async (limit: number = 5): Promise<Match[]> => {
    const response = await fetch(`${API_BASE_URL}/matches/recent?limit=${limit}`);
    if (!response.ok) {
      throw new Error(`Failed to fetch recent matches: ${response.status}`);
    }
    return response.json();
  },
  
  getUpcomingMatches: async (limit: number = 5): Promise<Match[]> => {
    const response = await fetch(`${API_BASE_URL}/matches/upcoming?limit=${limit}`);
    if (!response.ok) {
      throw new Error(`Failed to fetch upcoming matches: ${response.status}`);
    }
    return response.json();
  },
  
  getMatchById: async (id: number): Promise<Match> => {
    const response = await fetch(`${API_BASE_URL}/matches/${id}`);
    if (!response.ok) {
      throw new Error(`Failed to fetch match: ${response.status}`);
    }
    return response.json();
  },
  
  updateMatch: async (id: number, matchData: Partial<Match>): Promise<Match> => {
    const response = await apiRequest('PUT', `${API_BASE_URL}/matches/${id}`, matchData);
    return response.json();
  }
};

// Prediction related API calls
export const predictionService = {
  getPredictionByMatchId: async (matchId: number): Promise<Prediction> => {
    const response = await fetch(`${API_BASE_URL}/predictions/${matchId}`);
    if (!response.ok) {
      if (response.status === 404) {
        throw new Error("No prediction available for this match");
      }
      throw new Error(`Failed to fetch prediction: ${response.status}`);
    }
    return response.json();
  },
  
  getPredictions: async (): Promise<Prediction[]> => {
    const response = await fetch(`${API_BASE_URL}/predictions`);
    if (!response.ok) {
      throw new Error(`Failed to fetch predictions: ${response.status}`);
    }
    return response.json();
  },
  
  createPrediction: async (predictionData: Omit<Prediction, 'id'>): Promise<Prediction> => {
    const response = await apiRequest('POST', `${API_BASE_URL}/predictions`, predictionData);
    return response.json();
  }
};

// Fantasy cricket related API calls
export const fantasyService = {
  getTopFantasyPlayers: async (limit: number = 3): Promise<FantasyPlayer[]> => {
    const response = await fetch(`${API_BASE_URL}/fantasy/players?limit=${limit}`);
    if (!response.ok) {
      throw new Error(`Failed to fetch fantasy players: ${response.status}`);
    }
    return response.json();
  },
  
  getFantasyPlayerById: async (id: number): Promise<FantasyPlayer> => {
    const response = await fetch(`${API_BASE_URL}/fantasy/players/${id}`);
    if (!response.ok) {
      throw new Error(`Failed to fetch fantasy player: ${response.status}`);
    }
    return response.json();
  }
};
