import React from "react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { BarChartIcon } from "lucide-react";
import { Match, Team } from "@shared/schema";

const MatchPredictions: React.FC = () => {
  const { data: matches, isLoading: isLoadingMatches } = useQuery<Match[]>({
    queryKey: ['/api/matches/upcoming'],
    select: data => data?.filter(match => match.id === 7 || match.id === 9)
  });
  
  const { data: teams, isLoading: isLoadingTeams } = useQuery<Team[]>({
    queryKey: ['/api/teams'],
  });
  
  const isLoading = isLoadingMatches || isLoadingTeams;
  
  // Find team by ID
  const getTeam = (teamId?: number) => {
    return teams?.find(team => team.id === teamId);
  };
  
  // Fetch predictions for a match
  const { data: prediction1 } = useQuery<any>({
    queryKey: ['/api/predictions/7'],
    enabled: !isLoading && !!matches && matches.some(m => m.id === 7)
  });
  
  const { data: prediction2 } = useQuery<any>({
    queryKey: ['/api/predictions/9'],
    enabled: !isLoading && !!matches && matches.some(m => m.id === 9)
  });
  
  return (
    <Card className="overflow-hidden">
      <CardHeader className="border-b border-gray-100 dark:border-gray-700">
        <CardTitle className="text-xl font-bold font-sans text-gray-800 dark:text-white flex items-center">
          <BarChartIcon className="mr-3 text-amber-500 h-5 w-5" />
          Match Predictions
        </CardTitle>
      </CardHeader>
      
      {isLoading ? (
        <div className="p-4 space-y-4">
          <div className="space-y-3">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-2">
                <Skeleton className="h-6 w-6 rounded-full" />
                <Skeleton className="h-5 w-20" />
              </div>
              <Skeleton className="h-4 w-6" />
              <div className="flex items-center space-x-2">
                <Skeleton className="h-5 w-20" />
                <Skeleton className="h-6 w-6 rounded-full" />
              </div>
            </div>
            <Skeleton className="h-8 w-full rounded-full" />
            <div className="flex justify-between">
              <Skeleton className="h-4 w-40" />
              <Skeleton className="h-4 w-24" />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <Skeleton className="h-20 w-full rounded" />
              <Skeleton className="h-20 w-full rounded" />
            </div>
          </div>
        </div>
      ) : matches && teams ? (
        <>
          {/* First prediction */}
          {matches[0] && prediction1 && (
            <div className="p-4 border-b border-gray-100 dark:border-gray-700">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-2">
                  {getTeam(matches[0].team1Id)?.flagUrl ? (
                    <img 
                      src={getTeam(matches[0].team1Id)?.flagUrl} 
                      alt={getTeam(matches[0].team1Id)?.name} 
                      className="w-6 h-6 rounded-full object-cover border" 
                    />
                  ) : (
                    <div className="w-6 h-6 rounded-full bg-gray-200 dark:bg-gray-700"></div>
                  )}
                  <span className="font-medium dark:text-white">{getTeam(matches[0].team1Id)?.name}</span>
                </div>
                <div className="text-xs text-gray-500">vs</div>
                <div className="flex items-center space-x-2">
                  <span className="font-medium dark:text-white">{getTeam(matches[0].team2Id)?.name}</span>
                  {getTeam(matches[0].team2Id)?.flagUrl ? (
                    <img 
                      src={getTeam(matches[0].team2Id)?.flagUrl} 
                      alt={getTeam(matches[0].team2Id)?.name} 
                      className="w-6 h-6 rounded-full object-cover border" 
                    />
                  ) : (
                    <div className="w-6 h-6 rounded-full bg-gray-200 dark:bg-gray-700"></div>
                  )}
                </div>
              </div>
              
              {/* Prediction Chart */}
              <div className="flex items-center h-8 bg-gray-100 dark:bg-gray-700 rounded-full overflow-hidden mb-3">
                <div 
                  className="h-full bg-primary text-xs text-white flex items-center justify-center"
                  style={{ width: `${prediction1.team1WinProbability}%` }}
                >
                  {prediction1.team1WinProbability}%
                </div>
                <div 
                  className="h-full bg-amber-500 text-xs text-white flex items-center justify-center"
                  style={{ width: `${prediction1.team2WinProbability}%` }}
                >
                  {prediction1.team2WinProbability}%
                </div>
              </div>
              
              <div className="flex justify-between text-xs text-gray-600 dark:text-gray-300 mb-4">
                <span>{getTeam(matches[0].team1Id)?.name} favored to win</span>
                <span>Confidence: {prediction1.confidence}</span>
              </div>
              
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="bg-gray-50 dark:bg-gray-700 p-2 rounded">
                  <span className="text-gray-500 dark:text-gray-400">Projected Score:</span>
                  <div className="font-semibold dark:text-white mt-1">{prediction1.predictedScore}</div>
                </div>
                <div className="bg-gray-50 dark:bg-gray-700 p-2 rounded">
                  <span className="text-gray-500 dark:text-gray-400">Key Player:</span>
                  <div className="font-semibold dark:text-white mt-1">{prediction1.keyPlayers && prediction1.keyPlayers[0]}</div>
                </div>
              </div>
            </div>
          )}
          
          {/* Second prediction */}
          {matches[1] && prediction2 && (
            <div className="p-4">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-2">
                  {getTeam(matches[1].team1Id)?.flagUrl ? (
                    <img 
                      src={getTeam(matches[1].team1Id)?.flagUrl} 
                      alt={getTeam(matches[1].team1Id)?.name} 
                      className="w-6 h-6 rounded-full object-cover border" 
                    />
                  ) : (
                    <div className="w-6 h-6 rounded-full bg-gray-200 dark:bg-gray-700"></div>
                  )}
                  <span className="font-medium dark:text-white">{getTeam(matches[1].team1Id)?.name}</span>
                </div>
                <div className="text-xs text-gray-500">vs</div>
                <div className="flex items-center space-x-2">
                  <span className="font-medium dark:text-white">{getTeam(matches[1].team2Id)?.name}</span>
                  {getTeam(matches[1].team2Id)?.flagUrl ? (
                    <img 
                      src={getTeam(matches[1].team2Id)?.flagUrl} 
                      alt={getTeam(matches[1].team2Id)?.name} 
                      className="w-6 h-6 rounded-full object-cover border" 
                    />
                  ) : (
                    <div className="w-6 h-6 rounded-full bg-gray-200 dark:bg-gray-700"></div>
                  )}
                </div>
              </div>
              
              {/* Prediction Chart */}
              <div className="flex items-center h-8 bg-gray-100 dark:bg-gray-700 rounded-full overflow-hidden mb-3">
                <div 
                  className="h-full bg-primary text-xs text-white flex items-center justify-center"
                  style={{ width: `${prediction2.team1WinProbability}%` }}
                >
                  {prediction2.team1WinProbability}%
                </div>
                <div 
                  className="h-full bg-amber-500 text-xs text-white flex items-center justify-center"
                  style={{ width: `${prediction2.team2WinProbability}%` }}
                >
                  {prediction2.team2WinProbability}%
                </div>
              </div>
              
              <div className="flex justify-between text-xs text-gray-600 dark:text-gray-300 mb-4">
                <span>Tight contest expected</span>
                <span>Confidence: {prediction2.confidence}</span>
              </div>
              
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="bg-gray-50 dark:bg-gray-700 p-2 rounded">
                  <span className="text-gray-500 dark:text-gray-400">Match Type:</span>
                  <div className="font-semibold dark:text-white mt-1">{matches[1].matchType}</div>
                </div>
                <div className="bg-gray-50 dark:bg-gray-700 p-2 rounded">
                  <span className="text-gray-500 dark:text-gray-400">Key Factor:</span>
                  <div className="font-semibold dark:text-white mt-1">Pitch conditions</div>
                </div>
              </div>
            </div>
          )}
          
          <div className="p-4 text-center">
            <Link href="/predictions" className="inline-block bg-amber-500 hover:bg-amber-600 text-white text-sm font-medium py-2 px-4 rounded transition">
              View All Predictions
            </Link>
          </div>
        </>
      ) : (
        <div className="p-8 text-center">
          <p className="text-gray-500 dark:text-gray-400">No match predictions available</p>
        </div>
      )}
    </Card>
  );
};

export default MatchPredictions;
