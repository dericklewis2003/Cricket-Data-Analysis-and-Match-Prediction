import React from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { CircleIcon } from "lucide-react";

const HeroSection: React.FC = () => {
  return (
    <section className="relative bg-gradient-to-r from-[#0e4c92] to-[#0a3972] text-white py-8 md:py-16">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl">
          <h1 className="text-3xl md:text-5xl font-bold font-sans mb-4 animate-fade-in">
            Live Cricket Updates
          </h1>
          <p className="text-lg md:text-xl mb-6 text-gray-100">
            Stay updated with live scores, match predictions, and cricket analytics
          </p>
          <div className="flex flex-wrap gap-3">
            <Link href="#live-matches">
              <Button 
                className="bg-green-500 hover:bg-green-600 text-white font-bold py-2 px-6 rounded-full transition transform hover:scale-105"
              >
                Live Matches
              </Button>
            </Link>
            <Link href="/predictions">
              <Button 
                variant="outline" 
                className="bg-white text-primary hover:bg-gray-100 font-bold py-2 px-6 rounded-full transition transform hover:scale-105"
              >
                Match Predictions
              </Button>
            </Link>
          </div>
        </div>
      </div>
      
      {/* Decorative Elements */}
      <div className="hidden md:block absolute right-10 bottom-0 opacity-10">
        <CircleIcon className="h-40 w-40" />
      </div>
    </section>
  );
};

export default HeroSection;
