import React from "react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { TrophyIcon } from "lucide-react";
import { FantasyPlayer, Team } from "@shared/schema";

const FantasyCricket: React.FC = () => {
  const { data: players, isLoading: isLoadingPlayers } = useQuery<FantasyPlayer[]>({
    queryKey: ['/api/fantasy/players'],
  });
  
  const { data: teams, isLoading: isLoadingTeams } = useQuery<Team[]>({
    queryKey: ['/api/teams'],
  });
  
  const isLoading = isLoadingPlayers || isLoadingTeams;
  
  // Find team by ID
  const getTeam = (teamId?: number) => {
    return teams?.find(team => team.id === teamId);
  };
  
  return (
    <Card className="overflow-hidden">
      <CardHeader className="border-b border-gray-100 dark:border-gray-700">
        <CardTitle className="text-xl font-bold font-sans text-gray-800 dark:text-white flex items-center">
          <TrophyIcon className="mr-3 text-yellow-500 h-5 w-5" />
          Fantasy Cricket Picks
        </CardTitle>
      </CardHeader>
      
      <CardContent className="p-4">
        <p className="text-sm text-gray-600 dark:text-gray-300 mb-4">
          Top player picks for upcoming matches based on form and conditions
        </p>
        
        {isLoading ? (
          // Loading skeletons for players
          <div className="space-y-3 mb-4">
            {Array(3).fill(0).map((_, index) => (
              <div key={index} className="flex items-center space-x-3 p-2 rounded bg-gray-50 dark:bg-gray-700">
                <Skeleton className="w-10 h-10 rounded-full" />
                <div>
                  <Skeleton className="h-5 w-24 mb-1" />
                  <Skeleton className="h-3 w-28" />
                </div>
                <div className="ml-auto">
                  <Skeleton className="h-6 w-16 rounded" />
                </div>
              </div>
            ))}
          </div>
        ) : players && players.length > 0 ? (
          <div className="space-y-3 mb-4">
            {players.map((player) => {
              const team = getTeam(player.teamId);
              
              return (
                <div key={player.id} className="flex items-center space-x-3 p-2 rounded bg-gray-50 dark:bg-gray-700">
                  {player.imageUrl ? (
                    <img 
                      src={player.imageUrl} 
                      alt={player.name} 
                      className="w-10 h-10 rounded-full object-cover" 
                    />
                  ) : (
                    <div className="w-10 h-10 rounded-full bg-gray-200 dark:bg-gray-600 flex items-center justify-center">
                      <span className="text-gray-500 dark:text-gray-300 text-sm">
                        {player.name.charAt(0)}
                      </span>
                    </div>
                  )}
                  <div>
                    <div className="font-medium dark:text-white">{player.name}</div>
                    <div className="text-xs text-gray-500 dark:text-gray-400">
                      {player.role} • {team?.name}
                    </div>
                  </div>
                  <div className="ml-auto flex items-center">
                    <span 
                      className={`
                        text-xs font-semibold px-2 py-1 rounded
                        ${player.form === 'TOP PICK' 
                          ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100' 
                          : player.form === 'HOT FORM'
                            ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-100'
                            : 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-100'
                        }
                      `}
                    >
                      {player.form}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-6">
            <p className="text-gray-500 dark:text-gray-400">No fantasy players available</p>
          </div>
        )}
        
        <div className="text-center">
          <Link href="/predictions" className="text-primary dark:text-green-500 hover:underline text-sm font-medium">
            Build Your Fantasy Team
          </Link>
        </div>
      </CardContent>
    </Card>
  );
};

export default FantasyCricket;
