import React from "react";
import { Link } from "wouter";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { FacebookIcon, TwitterIcon, InstagramIcon, YoutubeIcon } from "lucide-react";

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-100 dark:bg-gray-800 pt-12 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <div className="text-primary dark:text-white">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M5.46257 4.43262C7.21556 2.91688 9.5007 2 12 2C17.5228 2 22 6.47715 22 12C22 14.1361 21.3302 16.1158 20.1892 17.7406L17 12H20C20 7.58172 16.4183 4 12 4C9.84982 4 7.89777 4.84827 6.46023 6.22842L5.46257 4.43262ZM3.07172 6.43665C2.38782 8.09308 2 9.99764 2 12C2 14.4999 2.87484 16.7691 4.34275 18.5006L6 14L4 14C4 11.4559 5.10005 9.18332 6.86401 7.63308L3.07172 6.43665ZM18.6823 19.5276C16.9309 21.0339 14.5929 22 12 22C9.32286 22 6.91414 21.0065 5.14368 19.4073L8.66733 17.4987C9.66995 18.1369 10.8528 18.5 12.1273 18.5C14.7917 18.5 17.0493 16.7789 17.6857 14.3199L18.6823 19.5276Z" />
                </svg>
              </div>
              <h3 className="text-xl font-bold font-sans text-primary dark:text-white">
                Cricket<span className="text-green-500">360</span>
              </h3>
            </div>
            <p className="text-sm text-gray-600 dark:text-gray-300 mb-4">
              Your ultimate cricket companion with live scores, predictions, and analytics.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-primary dark:hover:text-white transition" aria-label="Twitter">
                <TwitterIcon className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-primary dark:hover:text-white transition" aria-label="Facebook">
                <FacebookIcon className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-primary dark:hover:text-white transition" aria-label="Instagram">
                <InstagramIcon className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-primary dark:hover:text-white transition" aria-label="YouTube">
                <YoutubeIcon className="h-5 w-5" />
              </a>
            </div>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold mb-4 dark:text-white">Quick Links</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/" className="text-gray-600 dark:text-gray-300 hover:text-primary dark:hover:text-white transition">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/live-scores" className="text-gray-600 dark:text-gray-300 hover:text-primary dark:hover:text-white transition">
                  Live Scores
                </Link>
              </li>
              <li>
                <Link href="/teams" className="text-gray-600 dark:text-gray-300 hover:text-primary dark:hover:text-white transition">
                  Match Schedule
                </Link>
              </li>
              <li>
                <Link href="/stats" className="text-gray-600 dark:text-gray-300 hover:text-primary dark:hover:text-white transition">
                  Statistics
                </Link>
              </li>
              <li>
                <Link href="/teams" className="text-gray-600 dark:text-gray-300 hover:text-primary dark:hover:text-white transition">
                  Teams
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold mb-4 dark:text-white">Features</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/predictions" className="text-gray-600 dark:text-gray-300 hover:text-primary dark:hover:text-white transition">
                  Match Predictions
                </Link>
              </li>
              <li>
                <Link href="/dashboard" className="text-gray-600 dark:text-gray-300 hover:text-primary dark:hover:text-white transition">
                  Power BI Dashboard
                </Link>
              </li>
              <li>
                <Link href="/predictions" className="text-gray-600 dark:text-gray-300 hover:text-primary dark:hover:text-white transition">
                  T20 Score Predictor
                </Link>
              </li>
              <li>
                <Link href="/predictions" className="text-gray-600 dark:text-gray-300 hover:text-primary dark:hover:text-white transition">
                  Fantasy Cricket
                </Link>
              </li>
              <li>
                <Link href="/stats" className="text-gray-600 dark:text-gray-300 hover:text-primary dark:hover:text-white transition">
                  Player Rankings
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-lg font-semibold mb-4 dark:text-white">Stay Updated</h4>
            <p className="text-sm text-gray-600 dark:text-gray-300 mb-4">
              Subscribe to our newsletter for the latest cricket updates.
            </p>
            <form className="space-y-2">
              <Input
                type="email"
                placeholder="Your email address"
                className="w-full"
              />
              <Button 
                type="submit" 
                className="w-full bg-primary hover:bg-primary/90 text-white"
              >
                Subscribe
              </Button>
            </form>
          </div>
        </div>
        
        <div className="pt-8 border-t border-gray-200 dark:border-gray-700 text-center text-sm text-gray-500 dark:text-gray-400">
          <p>&copy; {new Date().getFullYear()} Cricket360. All rights reserved.</p>
          <div className="flex justify-center space-x-6 mt-3">
            <a href="#" className="hover:text-primary dark:hover:text-white transition">Privacy Policy</a>
            <a href="#" className="hover:text-primary dark:hover:text-white transition">Terms of Service</a>
            <a href="#" className="hover:text-primary dark:hover:text-white transition">Contact Us</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
