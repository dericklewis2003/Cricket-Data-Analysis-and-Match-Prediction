import React from "react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { CalendarIcon, ClockIcon, MapPinIcon, AlertCircle } from "lucide-react";
import { 
  cricketDataService, 
  dateUtils,
  type MatchInfo, 
  CricketApiError 
} from "@/services/cricket-data-api";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

const UpcomingMatches: React.FC = () => {
  const { 
    data: upcomingMatches, 
    isLoading,
    isError,
    error 
  } = useQuery<MatchInfo[]>({
    queryKey: ['/api/cricket/matches/upcoming'],
    queryFn: () => cricketDataService.getUpcomingMatches(),
    staleTime: 5 * 60 * 1000, // 5 minutes
    refetchInterval: 30 * 60 * 1000, // 30 minutes
    retry: 3,
    retryDelay: attemptIndex => Math.min(1000 * 2 ** attemptIndex, 30000),
  });
  
  return (
    <Card className="overflow-hidden">
      <CardHeader className="border-b border-gray-100 dark:border-gray-700">
        <CardTitle className="text-xl font-bold font-sans text-gray-800 dark:text-white flex items-center">
          <CalendarIcon className="mr-3 text-blue-500 h-5 w-5" />
          Upcoming Matches
        </CardTitle>
      </CardHeader>
      
      {/* Error State */}
      {isError && (
        <Alert variant="destructive" className="m-4">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error loading upcoming matches</AlertTitle>
          <AlertDescription>
            {error instanceof CricketApiError
              ? `${error.message} (${error.endpoint})`
              : 'Failed to load upcoming match data. Please try again later.'}
          </AlertDescription>
        </Alert>
      )}
      
      {isLoading ? (
        // Loading skeletons
        <div className="divide-y divide-gray-100 dark:divide-gray-700">
          {Array(4).fill(0).map((_, index) => (
            <div key={index} className="p-4">
              <div className="flex justify-between items-center mb-3">
                <Skeleton className="h-4 w-24" />
                <Skeleton className="h-5 w-20 rounded-full" />
              </div>
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-2">
                  <Skeleton className="h-6 w-6 rounded-full" />
                  <Skeleton className="h-5 w-20" />
                </div>
                <Skeleton className="h-4 w-6" />
                <div className="flex items-center space-x-2">
                  <Skeleton className="h-5 w-20" />
                  <Skeleton className="h-6 w-6 rounded-full" />
                </div>
              </div>
              <div className="flex justify-between">
                <Skeleton className="h-4 w-24" />
                <Skeleton className="h-4 w-32" />
              </div>
            </div>
          ))}
        </div>
      ) : upcomingMatches && upcomingMatches.length > 0 ? (
        <div className="divide-y divide-gray-100 dark:divide-gray-700">
          {upcomingMatches
            .filter(match => dateUtils.getDaysUntil(match.dateTimeGMT) !== 'COMPLETED')
            .slice(0, 4)
            .map((match) => {
              const daysUntil = dateUtils.getDaysUntil(match.dateTimeGMT);
              
              return (
                <div key={match.id} className="p-4 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
                  <div className="flex justify-between items-center mb-3">
                    <span className="text-xs text-gray-500 dark:text-gray-400">{match.matchType}</span>
                    <span className="bg-blue-500 text-white text-xs px-2 py-0.5 rounded-full">{daysUntil}</span>
                  </div>
                  
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center space-x-2">
                      <div className="w-6 h-6 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center text-xs">
                        {match.teams[0]?.charAt(0)}
                      </div>
                      <span className="font-medium dark:text-white">{match.teams[0]}</span>
                    </div>
                    <div className="text-xs text-gray-500">vs</div>
                    <div className="flex items-center space-x-2">
                      <span className="font-medium dark:text-white">{match.teams[1]}</span>
                      <div className="w-6 h-6 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center text-xs">
                        {match.teams[1]?.charAt(0)}
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex justify-between text-xs text-gray-500 dark:text-gray-400">
                    <span>
                      <ClockIcon className="inline-block h-3 w-3 mr-1" />
                      {dateUtils.formatMatchTime(match.dateTimeGMT)}
                    </span>
                    <span className="truncate max-w-[50%]" title={match.venue}>
                      <MapPinIcon className="inline-block h-3 w-3 mr-1" />
                      {match.venue}
                    </span>
                  </div>
                </div>
              );
            })}
          
          <div className="p-4 text-center">
            <Link href="/live-cricket" className="text-primary dark:text-green-500 hover:underline text-sm font-medium">
              View Full Schedule
            </Link>
          </div>
        </div>
      ) : (
        <div className="p-8 text-center">
          <p className="text-gray-500 dark:text-gray-400">No upcoming matches to display</p>
        </div>
      )}
    </Card>
  );
};

export default UpcomingMatches;
