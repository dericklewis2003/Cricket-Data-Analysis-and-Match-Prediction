import React, { useEffect, useState } from "react";
import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LineChartIcon } from "lucide-react";
import { Button } from "@/components/ui/button";

interface PowerBIDashboardProps {
  fullWidth?: boolean;
  height?: string;
  showStats?: boolean;
}

const PowerBIDashboard: React.FC<PowerBIDashboardProps> = ({ 
  fullWidth = false, 
  height = "400px",
  showStats = true
}) => {
  const [isLoading, setIsLoading] = useState(true);
  const [windowWidth, setWindowWidth] = useState<number | null>(null);
  
  // Handle responsive sizing
  useEffect(() => {
    const handleResize = () => {
      setWindowWidth(window.innerWidth);
    };
    
    // Set initial size
    handleResize();
    
    // Add event listener
    window.addEventListener('resize', handleResize);
    
    // Cleanup
    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);
  
  // Handle iframe loading
  const handleIframeLoad = () => {
    setIsLoading(false);
  };
  
  // Adjust iframe height for different devices
  const getResponsiveHeight = () => {
    if (!windowWidth) return height;
    
    if (windowWidth < 640) { // Mobile
      return fullWidth ? "300px" : "250px";
    } else if (windowWidth < 1024) { // Tablet
      return fullWidth ? "400px" : "350px";
    } else { // Desktop
      return fullWidth ? height : "400px";
    }
  };
  
  return (
    <Card className={`overflow-hidden ${fullWidth ? 'w-full' : ''}`}>
      <CardHeader className="border-b border-gray-100 dark:border-gray-700">
        <CardTitle className="text-xl font-bold font-sans text-gray-800 dark:text-white flex items-center">
          <LineChartIcon className="mr-3 text-primary h-5 w-5" />
          T20 Analytics Dashboard
        </CardTitle>
      </CardHeader>
      
      <CardContent className="p-6 space-y-4">
        <p className="text-gray-600 dark:text-gray-300 mb-4">
          Explore cricket statistics and insights through our interactive Power BI dashboard.
        </p>
        
        {/* Power BI Iframe with loading state */}
        <div className="w-full rounded-lg overflow-hidden relative">
          {isLoading && (
            <div className="absolute inset-0 flex items-center justify-center bg-gray-100 dark:bg-gray-700 z-10">
              <div className="text-center p-6">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
                <p className="text-gray-500 dark:text-gray-400">Loading dashboard...</p>
              </div>
            </div>
          )}
          
          <div className="w-full" style={{ height: getResponsiveHeight() }}>
            <iframe 
              title="T20 Analytics Dashboard" 
              width="100%" 
              height="100%" 
              src="https://app.powerbi.com/reportEmbed?reportId=7c9a3672-b348-4a4e-8d5c-8a367fce0000&autoAuth=true&ctid=88f39ece-f108-49cf-97b6-f4ae2d89ba76" 
              frameBorder="0" 
              allowFullScreen={true}
              style={{ 
                border: 'none', 
                borderRadius: '0.5rem',
                boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)'
              }}
              onLoad={handleIframeLoad}
            />
          </div>
        </div>
        
        {showStats && (
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 mt-6">
            <div className="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg text-center">
              <div className="text-2xl font-bold text-primary dark:text-green-500 mb-1">76%</div>
              <div className="text-xs text-gray-500 dark:text-gray-400">Win prediction accuracy</div>
            </div>
            <div className="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg text-center">
              <div className="text-2xl font-bold text-primary dark:text-green-500 mb-1">500+</div>
              <div className="text-xs text-gray-500 dark:text-gray-400">Players analyzed</div>
            </div>
            <div className="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg text-center">
              <div className="text-2xl font-bold text-primary dark:text-green-500 mb-1">85K+</div>
              <div className="text-xs text-gray-500 dark:text-gray-400">Data points</div>
            </div>
          </div>
        )}
        
        {/* Link to full dashboard page if not already on it */}
        {!fullWidth && (
          <div className="text-center mt-4">
            <Link href="/dashboard">
              <Button className="bg-primary hover:bg-primary/90 text-white font-medium">
                Open Full Dashboard
              </Button>
            </Link>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default PowerBIDashboard;
