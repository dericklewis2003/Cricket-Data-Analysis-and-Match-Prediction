import React from "react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { FlagIcon } from "lucide-react";
import { Match, Team } from "@shared/schema";

const RecentMatches: React.FC = () => {
  const { data: recentMatches, isLoading: isLoadingMatches } = useQuery<Match[]>({
    queryKey: ['/api/matches/recent'],
  });
  
  const { data: teams, isLoading: isLoadingTeams } = useQuery<Team[]>({
    queryKey: ['/api/teams'],
  });
  
  const isLoading = isLoadingMatches || isLoadingTeams;
  
  // Find team by ID
  const getTeam = (teamId?: number) => {
    return teams?.find(team => team.id === teamId);
  };
  
  return (
    <Card className="overflow-hidden">
      <CardHeader className="border-b border-gray-100 dark:border-gray-700">
        <CardTitle className="text-xl font-bold font-sans text-gray-800 dark:text-white flex items-center">
          <FlagIcon className="mr-3 text-green-500 h-5 w-5" />
          Recent Match Results
        </CardTitle>
      </CardHeader>
      
      {isLoading ? (
        // Loading skeletons
        Array(3).fill(0).map((_, index) => (
          <div key={index} className="p-4 border-b border-gray-100 dark:border-gray-700">
            <div className="flex justify-between items-center mb-2">
              <Skeleton className="h-4 w-32" />
              <Skeleton className="h-5 w-24 rounded-full" />
            </div>
            <div className="space-y-3 mb-2">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center space-x-3">
                  <Skeleton className="h-6 w-6 rounded-full" />
                  <Skeleton className="h-5 w-24" />
                  <Skeleton className="h-4 w-16" />
                </div>
                <Skeleton className="h-6 w-16 rounded" />
              </div>
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center space-x-3">
                  <Skeleton className="h-6 w-6 rounded-full" />
                  <Skeleton className="h-5 w-24" />
                  <Skeleton className="h-4 w-16" />
                </div>
              </div>
            </div>
            <Skeleton className="h-4 w-48" />
          </div>
        ))
      ) : recentMatches && recentMatches.length > 0 ? (
        <>
          {recentMatches.map((match) => {
            const team1 = getTeam(match.team1Id);
            const team2 = getTeam(match.team2Id);
            const winningTeam = getTeam(match.winningTeamId);
            const matchDate = new Date(match.date);
            const daysAgo = Math.floor((Date.now() - matchDate.getTime()) / (1000 * 60 * 60 * 24));
            const dateDisplay = daysAgo === 0 ? 'Today' : daysAgo === 1 ? 'Yesterday' : `${daysAgo} days ago`;
            
            return (
              <div key={match.id} className="p-4 border-b border-gray-100 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-xs text-gray-500 dark:text-gray-400">{match.matchType} - {dateDisplay}</span>
                  <span className="bg-green-500 text-white text-xs px-2 py-0.5 rounded-full">COMPLETED</span>
                </div>
                
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center space-x-3">
                    {team1?.flagUrl ? (
                      <img 
                        src={team1.flagUrl} 
                        alt={team1.name} 
                        className="w-6 h-6 rounded-full object-cover border" 
                      />
                    ) : (
                      <div className="w-6 h-6 rounded-full bg-gray-200 dark:bg-gray-700"></div>
                    )}
                    <span className="font-medium dark:text-white">{team1?.name}</span>
                    <span className="text-sm font-mono">{match.team1Score}</span>
                  </div>
                  {match.winningTeamId === match.team1Id && (
                    <div className="text-xs font-semibold px-2 py-1 bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100 rounded">WINNER</div>
                  )}
                </div>
                
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center space-x-3">
                    {team2?.flagUrl ? (
                      <img 
                        src={team2.flagUrl} 
                        alt={team2.name} 
                        className="w-6 h-6 rounded-full object-cover border" 
                      />
                    ) : (
                      <div className="w-6 h-6 rounded-full bg-gray-200 dark:bg-gray-700"></div>
                    )}
                    <span className="font-medium dark:text-white">{team2?.name}</span>
                    <span className="text-sm font-mono">{match.team2Score}</span>
                  </div>
                  {match.winningTeamId === match.team2Id && (
                    <div className="text-xs font-semibold px-2 py-1 bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100 rounded">WINNER</div>
                  )}
                </div>
                
                <div className="text-sm text-gray-600 dark:text-gray-300">
                  {match.result}
                </div>
              </div>
            );
          })}
          
          <div className="p-4 text-center">
            <Link href="/live-scores" className="text-primary dark:text-green-500 hover:underline text-sm font-medium">
              View All Results
            </Link>
          </div>
        </>
      ) : (
        <div className="p-8 text-center">
          <p className="text-gray-500 dark:text-gray-400">No recent matches to display</p>
        </div>
      )}
    </Card>
  );
};

export default RecentMatches;
