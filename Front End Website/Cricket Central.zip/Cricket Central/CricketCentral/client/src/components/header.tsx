import React, { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { MoonIcon, SunIcon, MenuIcon, SearchIcon, XIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

const Header: React.FC = () => {
  const [theme, setTheme] = useState<"light" | "dark">("light");
  
  // Check for system preference and localStorage on component mount
  useEffect(() => {
    const savedTheme = localStorage.getItem("theme") as "light" | "dark" | null;
    const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
    
    const initialTheme = savedTheme || (prefersDark ? "dark" : "light");
    setTheme(initialTheme);
    
    // Apply theme class to document
    applyTheme(initialTheme);
  }, []);
  
  // Apply theme to HTML element
  const applyTheme = (currentTheme: "light" | "dark") => {
    const htmlElement = document.documentElement;
    
    if (currentTheme === "dark") {
      htmlElement.classList.add("dark");
      htmlElement.classList.remove("light");
    } else {
      htmlElement.classList.remove("dark");
      htmlElement.classList.add("light");
    }
  };
  
  // Toggle theme function
  const toggleTheme = () => {
    const newTheme = theme === "light" ? "dark" : "light";
    setTheme(newTheme);
    localStorage.setItem("theme", newTheme);
    applyTheme(newTheme);
  };
  
  const [location] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchBarOpen, setSearchBarOpen] = useState(false);

  const isActive = (path: string) => location === path;

  return (
    <header className="bg-white shadow-md dark:bg-gray-800 sticky top-0 z-50 transition-all duration-200">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between py-4">
          {/* Logo */}
          <Link href="/" className="flex items-center space-x-2">
            <div className="text-primary dark:text-white">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" viewBox="0 0 24 24" fill="currentColor">
                <path d="M5.46257 4.43262C7.21556 2.91688 9.5007 2 12 2C17.5228 2 22 6.47715 22 12C22 14.1361 21.3302 16.1158 20.1892 17.7406L17 12H20C20 7.58172 16.4183 4 12 4C9.84982 4 7.89777 4.84827 6.46023 6.22842L5.46257 4.43262ZM3.07172 6.43665C2.38782 8.09308 2 9.99764 2 12C2 14.4999 2.87484 16.7691 4.34275 18.5006L6 14L4 14C4 11.4559 5.10005 9.18332 6.86401 7.63308L3.07172 6.43665ZM18.6823 19.5276C16.9309 21.0339 14.5929 22 12 22C9.32286 22 6.91414 21.0065 5.14368 19.4073L8.66733 17.4987C9.66995 18.1369 10.8528 18.5 12.1273 18.5C14.7917 18.5 17.0493 16.7789 17.6857 14.3199L18.6823 19.5276Z" />
              </svg>
            </div>
            <div>
              <h1 className="text-2xl font-bold font-sans text-primary dark:text-white">
                Cricket<span className="text-green-500">360</span>
              </h1>
              <p className="text-xs text-gray-500 dark:text-gray-400">Live Scores & Analysis</p>
            </div>
          </Link>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-6">
            <Link href="/" className={`font-medium transition ${isActive('/') ? 'text-primary dark:text-white' : 'text-gray-600 dark:text-gray-300 hover:text-green-500 dark:hover:text-green-500'}`}>
              Home
            </Link>
            <Link href="/live-cricket" className={`font-medium transition ${isActive('/live-cricket') ? 'text-primary dark:text-white' : 'text-gray-600 dark:text-gray-300 hover:text-green-500 dark:hover:text-green-500'}`}>
              Live Scores
            </Link>
            <Link href="/teams" className={`font-medium transition ${isActive('/teams') ? 'text-primary dark:text-white' : 'text-gray-600 dark:text-gray-300 hover:text-green-500 dark:hover:text-green-500'}`}>
              Teams
            </Link>
            <Link href="/news" className={`font-medium transition ${isActive('/news') ? 'text-primary dark:text-white' : 'text-gray-600 dark:text-gray-300 hover:text-green-500 dark:hover:text-green-500'}`}>
              News
            </Link>
            <Link href="/dashboard" className={`font-medium transition ${isActive('/dashboard') ? 'text-primary dark:text-white' : 'text-gray-600 dark:text-gray-300 hover:text-green-500 dark:hover:text-green-500'}`}>
              Analytics
            </Link>
            <Link href="/predictions" className={`font-medium transition ${isActive('/predictions') ? 'text-primary dark:text-white' : 'text-gray-600 dark:text-gray-300 hover:text-green-500 dark:hover:text-green-500'}`}>
              Predictions
            </Link>
          </nav>
          
          <div className="flex items-center space-x-4">
            {/* Search Icon */}
            <button 
              className="text-gray-600 dark:text-gray-300 hover:text-primary transition"
              onClick={() => setSearchBarOpen(!searchBarOpen)}
              aria-label="Toggle search"
            >
              <SearchIcon className="h-5 w-5" />
            </button>
            
            {/* Theme Toggle */}
            <button 
              className="text-gray-600 dark:text-gray-300 hover:text-primary transition"
              onClick={toggleTheme}
              aria-label="Toggle theme"
            >
              {theme === 'dark' ? <SunIcon className="h-5 w-5" /> : <MoonIcon className="h-5 w-5" />}
            </button>
            
            {/* Mobile Menu Toggle */}
            <button 
              className="text-gray-600 dark:text-gray-300 md:hidden hover:text-primary transition"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              aria-label="Toggle menu"
            >
              <MenuIcon className="h-5 w-5" />
            </button>
          </div>
        </div>
      </div>
      
      {/* Mobile Navigation Menu */}
      {mobileMenuOpen && (
        <div className="px-4 py-2 bg-white dark:bg-gray-800 shadow-inner md:hidden">
          <nav className="flex flex-col space-y-4 py-4">
            <Link href="/" className={`font-medium px-2 py-1 transition ${isActive('/') ? 'text-primary dark:text-white' : 'text-gray-600 dark:text-gray-300 hover:text-green-500 dark:hover:text-green-500'}`}>
              Home
            </Link>
            <Link href="/live-cricket" className={`font-medium px-2 py-1 transition ${isActive('/live-cricket') ? 'text-primary dark:text-white' : 'text-gray-600 dark:text-gray-300 hover:text-green-500 dark:hover:text-green-500'}`}>
              Live Scores
            </Link>
            <Link href="/teams" className={`font-medium px-2 py-1 transition ${isActive('/teams') ? 'text-primary dark:text-white' : 'text-gray-600 dark:text-gray-300 hover:text-green-500 dark:hover:text-green-500'}`}>
              Teams
            </Link>
            <Link href="/news" className={`font-medium px-2 py-1 transition ${isActive('/news') ? 'text-primary dark:text-white' : 'text-gray-600 dark:text-gray-300 hover:text-green-500 dark:hover:text-green-500'}`}>
              News
            </Link>
            <Link href="/dashboard" className={`font-medium px-2 py-1 transition ${isActive('/dashboard') ? 'text-primary dark:text-white' : 'text-gray-600 dark:text-gray-300 hover:text-green-500 dark:hover:text-green-500'}`}>
              Analytics
            </Link>
            <Link href="/predictions" className={`font-medium px-2 py-1 transition ${isActive('/predictions') ? 'text-primary dark:text-white' : 'text-gray-600 dark:text-gray-300 hover:text-green-500 dark:hover:text-green-500'}`}>
              Predictions
            </Link>
          </nav>
        </div>
      )}
      
      {/* Search Bar (Hidden by default) */}
      {searchBarOpen && (
        <div className="px-4 py-4 bg-white dark:bg-gray-800 shadow-inner">
          <div className="relative max-w-2xl mx-auto">
            <Input
              type="text"
              placeholder="Search matches, teams or players..."
              className="w-full pl-10 pr-8 rounded-full"
            />
            <SearchIcon className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
            <button 
              className="absolute right-3 top-3 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200"
              onClick={() => setSearchBarOpen(false)}
              aria-label="Close search"
            >
              <XIcon className="h-4 w-4" />
            </button>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;
