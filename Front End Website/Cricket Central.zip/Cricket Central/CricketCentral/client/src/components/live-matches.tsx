import React from "react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  cricketDataService, 
  dateUtils, 
  type LiveMatch, 
  CricketApiError 
} from "@/services/cricket-data-api";
import { AlertCircle } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

const LiveMatches: React.FC = () => {
  const { 
    data: liveMatches, 
    isLoading, 
    isError, 
    error 
  } = useQuery<LiveMatch[]>({
    queryKey: ['/api/cricket/matches/live'],
    queryFn: () => cricketDataService.getLiveMatches(),
    staleTime: 30 * 1000, // 30 seconds - data is considered fresh for 30 seconds
    refetchInterval: 30 * 1000, // Refetch every 30 seconds for live match updates
    retry: 3, // Retry 3 times on failure
    retryDelay: attemptIndex => Math.min(1000 * 2 ** attemptIndex, 30000), // Exponential backoff
  });
  
  // Helper function to get team info
  const getTeamInfo = (match: LiveMatch, teamName: string) => {
    if (!match.teamInfo) return null;
    
    return match.teamInfo.find(team => 
      team.name === teamName || 
      match.teams.includes(team.name) ||
      (team.shortname && teamName.includes(team.shortname))
    );
  };
  
  // Helper function to get team score
  const getTeamScore = (match: LiveMatch, teamName: string) => {
    if (!match.score || match.score.length === 0) return null;
    
    // Try to find exact match first
    let scoreEntry = match.score.find(score => 
      score.inning.includes(teamName)
    );
    
    // If not found, try with team short name
    if (!scoreEntry) {
      const teamInfo = getTeamInfo(match, teamName);
      if (teamInfo?.shortname) {
        scoreEntry = match.score.find(score => 
          score.inning.includes(teamInfo.shortname)
        );
      }
    }
    
    return scoreEntry;
  };
  
  return (
    <section id="live-matches" className="mb-12">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold font-sans text-gray-800 dark:text-white">
          <span className="inline-block w-2 h-2 bg-red-500 rounded-full animate-pulse mr-2"></span>
          Live Matches
        </h2>
        <Link href="/live-cricket" className="text-primary dark:text-green-500 hover:underline text-sm font-medium">
          View All
        </Link>
      </div>
      
      {/* Error State */}
      {isError && (
        <Alert variant="destructive" className="mb-4">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error loading live matches</AlertTitle>
          <AlertDescription>
            {error instanceof CricketApiError
              ? `${error.message} (${error.endpoint})`
              : 'Failed to load live match data. Please try again later.'}
          </AlertDescription>
        </Alert>
      )}
      
      {/* Live Matches Wrapper */}
      <div className="overflow-x-auto hide-scrollbar pb-4">
        <div className="flex space-x-4 min-w-max">
          {isLoading ? (
            // Loading skeletons
            Array(3).fill(0).map((_, index) => (
              <Card key={index} className="w-80 border-l-4 border-red-500">
                <CardContent className="p-4">
                  <div className="flex justify-between items-center mb-3">
                    <Skeleton className="h-6 w-16 rounded-full" />
                    <Skeleton className="h-4 w-24" />
                  </div>
                  <div className="space-y-4 mb-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <Skeleton className="h-8 w-8 rounded-full" />
                        <Skeleton className="h-5 w-24" />
                      </div>
                      <Skeleton className="h-6 w-16" />
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <Skeleton className="h-8 w-8 rounded-full" />
                        <Skeleton className="h-5 w-24" />
                      </div>
                      <Skeleton className="h-6 w-16" />
                    </div>
                  </div>
                  <Skeleton className="h-4 w-full mb-3" />
                  <Skeleton className="h-2 w-full mb-3" />
                  <div className="flex justify-between">
                    <Skeleton className="h-3 w-16" />
                    <Skeleton className="h-3 w-28" />
                  </div>
                </CardContent>
              </Card>
            ))
          ) : liveMatches && liveMatches.length > 0 ? (
            liveMatches.map((match) => {
              // Only show matches that have actually started and not ended
              if (!dateUtils.isMatchLive(match)) return null;
              
              const team1 = match.teams[0];
              const team2 = match.teams[1];
              const team1Info = getTeamInfo(match, team1);
              const team2Info = getTeamInfo(match, team2);
              const team1Score = getTeamScore(match, team1);
              const team2Score = getTeamScore(match, team2);
              
              // Calculate match progress using the utility function
              const matchProgress = dateUtils.calculateMatchProgress(match);
              
              return (
                <Link key={match.id} href={`/live-cricket/${match.id}`}>
                  <Card className="w-80 border-l-4 border-red-500 hover:shadow-lg transition-shadow cursor-pointer">
                    <CardContent className="p-4">
                      <div className="flex justify-between items-center mb-3">
                        <span className="bg-red-500 text-white text-xs px-2 py-1 rounded-full animate-pulse">LIVE</span>
                        <span className="text-xs text-gray-500 dark:text-gray-400">{match.matchType}</span>
                      </div>
                      
                      {/* Teams */}
                      <div className="space-y-4 mb-4">
                        {/* Team 1 */}
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            {team1Info?.img ? (
                              <img 
                                src={team1Info.img} 
                                alt={team1} 
                                className="w-8 h-8 rounded-full object-cover border" 
                              />
                            ) : (
                              <div className="w-8 h-8 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center text-xs">
                                {team1.charAt(0)}
                              </div>
                            )}
                            <span className="font-semibold dark:text-white">{team1}</span>
                          </div>
                          <div className="font-mono font-bold text-lg dark:text-white">
                            {team1Score ? `${team1Score.r}/${team1Score.w}` : '-'}
                          </div>
                        </div>
                        
                        {/* Team 2 */}
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            {team2Info?.img ? (
                              <img 
                                src={team2Info.img} 
                                alt={team2} 
                                className="w-8 h-8 rounded-full object-cover border" 
                              />
                            ) : (
                              <div className="w-8 h-8 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center text-xs">
                                {team2.charAt(0)}
                              </div>
                            )}
                            <span className="font-semibold dark:text-white">{team2}</span>
                          </div>
                          <div className="font-mono font-bold text-lg dark:text-white">
                            {team2Score ? `${team2Score.r}/${team2Score.w}` : '-'}
                          </div>
                        </div>
                      </div>
                      
                      {/* Match Status */}
                      <div className="text-sm text-gray-600 dark:text-gray-300 mb-3 line-clamp-2">
                        {match.status}
                      </div>
                      
                      {/* Progress Bar - using the utility function for accurate calculation */}
                      <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-1.5 mb-3">
                        <div 
                          className="bg-red-500 h-1.5 rounded-full transition-all duration-300" 
                          style={{ width: `${matchProgress}%` }}
                        ></div>
                      </div>
                      
                      {/* Bottom Info */}
                      <div className="flex justify-between items-center text-xs text-gray-500 dark:text-gray-400">
                        <span>
                          {team1Score?.o 
                            ? `${Math.floor(team1Score.o)}.${Math.round((team1Score.o % 1) * 6)} overs` 
                            : dateUtils.formatMatchTime(match.dateTimeGMT)}
                        </span>
                        <span className="truncate max-w-[50%]" title={match.venue}>{match.venue}</span>
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              );
            }).filter(Boolean) // Remove null items (matches that aren't live)
          ) : (
            <div className="flex items-center justify-center w-full py-8 px-4">
              <p className="text-gray-500 dark:text-gray-400 text-center">
                No live matches at the moment. Check back during scheduled match times.
              </p>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};

export default LiveMatches;
