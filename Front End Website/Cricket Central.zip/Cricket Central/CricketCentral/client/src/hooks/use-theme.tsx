import React, { createContext, useContext, useEffect, useState, ReactNode } from "react";

type Theme = "light" | "dark";

interface ThemeContextType {
  theme: Theme;
  toggleTheme: () => void;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [theme, setTheme] = useState<Theme>("light");
  const [isClient, setIsClient] = useState(false);

  // This effect runs once on mount to indicate we're on the client
  useEffect(() => {
    setIsClient(true);
  }, []);

  // This effect runs when we confirm we're on the client and can access browser APIs
  useEffect(() => {
    if (isClient) {
      // Check for saved theme preference or prefer-color-scheme
      const savedTheme = localStorage.getItem("theme") as Theme | null;
      const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
      
      const initialTheme = savedTheme || (prefersDark ? "dark" : "light");
      setTheme(initialTheme);
      
      // Apply theme to document immediately
      applyThemeToDOM(initialTheme);
    }
  }, [isClient]);

  // Apply theme whenever it changes
  useEffect(() => {
    if (isClient) {
      applyThemeToDOM(theme);
      localStorage.setItem("theme", theme);
    }
  }, [theme, isClient]);

  // Function to apply theme to DOM elements
  const applyThemeToDOM = (currentTheme: Theme) => {
    const htmlElement = document.documentElement;
    
    if (currentTheme === "dark") {
      htmlElement.classList.add("dark");
      htmlElement.classList.remove("light");
    } else {
      htmlElement.classList.remove("dark");
      htmlElement.classList.add("light");
    }
  };

  const toggleTheme = () => {
    setTheme(prevTheme => {
      const newTheme = prevTheme === "light" ? "dark" : "light";
      return newTheme;
    });
  };

  return (
    <ThemeContext.Provider value={{ theme, toggleTheme }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const context = useContext(ThemeContext);
  
  if (context === undefined) {
    throw new Error("useTheme must be used within a ThemeProvider");
  }
  
  return context;
}
