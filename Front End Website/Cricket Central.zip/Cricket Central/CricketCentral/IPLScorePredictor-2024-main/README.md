# IPL Score Predictor 2024

This is a machine learning model that predicts the probability of winning in IPL matches based on historical data from 2008-2024.

## Project Structure
```
IPLScorePredictor-2024-main/
├── app.py              # Flask application
├── model_2024.pkl      # Trained Random Forest model
├── static/             # Static assets
│   ├── image.png      # Main banner image
│   └── min_c.png      # Mobile view image
└── templates/          # HTML templates
    ├── index.html     # Main prediction form
    └── result.html    # Results display page
```

## Model Details
- Algorithm: Random Forest Classifier
- Accuracy: 74%
- Features used:
  - Batting team
  - Bowling team
  - City (venue)
  - First innings score
  - Target (first innings score + 1)
- Target variable: Match result (1 if batting team wins, 0 if bowling team wins)

## Integration Instructions for Replit Agent

1. **Dependencies Required**:
   ```
   flask==2.0.1
   pandas==1.3.3
   numpy==1.21.2
   scikit-learn==0.24.2
   ```

2. **Setup Steps**:
   - Copy all files maintaining the directory structure
   - Install required dependencies using pip:
     ```bash
     pip install flask==2.0.1 pandas==1.3.3 numpy==1.21.2 scikit-learn==0.24.2
     ```
   - Ensure `model_2024.pkl` is in the root directory
   - Run `app.py` to start the Flask server:
     ```bash
     python app.py
     ```

3. **API Endpoints**:
   - GET `/`: Main prediction form
   - POST `/predict`: Prediction endpoint
     - Input parameters:
       - batting_team: string (e.g., "Mumbai Indians", "Chennai Super Kings")
       - bowling_team: string (e.g., "Royal Challengers Bangalore", "Rajasthan Royals")
       - selected_city: string (e.g., "Mumbai", "Chennai", "Bangalore")
       - first_innings_score: integer (e.g., 180, 200)
     - Returns: Win/loss probability for both teams

4. **Integration with Existing Website**:
   - The model can be integrated as a standalone service
   - Use the `/predict` endpoint to get predictions
   - Frontend can be customized while keeping the core prediction logic
   - Example integration code:
     ```javascript
     async function getPrediction(battingTeam, bowlingTeam, city, firstInningsScore) {
       const response = await fetch('/predict', {
         method: 'POST',
         headers: {
           'Content-Type': 'application/x-www-form-urlencoded',
         },
         body: new URLSearchParams({
           batting_team: battingTeam,
           bowling_team: bowlingTeam,
           selected_city: city,
           first_innings_score: firstInningsScore
         })
       });
       return await response.json();
     }
     ```

5. **Model Limitations**:
   - Predictions based on historical data (2008-2024)
   - Does not consider current team form or player availability
   - Best used as one of several prediction tools

## Example API Usage
```python
import requests

url = "http://your-domain/predict"
data = {
    "batting_team": "Mumbai Indians",
    "bowling_team": "Chennai Super Kings",
    "selected_city": "Mumbai",
    "first_innings_score": 180
}
response = requests.post(url, data=data)
predictions = response.json()
```

## Notes for Replit Agent
- The model is trained and ready to use
- No additional training or preprocessing needed
- Focus on integrating the prediction endpoint with your existing website
- The frontend can be customized to match your website's design
- The model file (`model_2024.pkl`) must be kept in the same directory as `app.py`
- Ensure all static files (images) are properly placed in the static directory
- The templates directory contains the HTML files for the prediction form and results

## Troubleshooting
1. If the model fails to load:
   - Verify that `model_2024.pkl` is in the correct location
   - Check if all dependencies are installed correctly
   - Ensure Python version is 3.7 or higher

2. If predictions seem incorrect:
   - Verify input data format
   - Check if team names match exactly with the training data
   - Ensure first_innings_score is a valid integer

3. If static files don't load:
   - Verify file paths in templates
   - Check if static directory structure is maintained
   - Ensure file permissions are correct

## Features

- Select the Batting Team, Bowling Team, Venue, Target, Score, Balls Left, and Wickets Down.
- Click the "Predict" button to get the winning probabilities for both the Batting and Bowling teams.
- Validation to ensure that the Batting Team and Bowling Team selected are different.
- Stylish UI with background images for an enhanced user experience.

## Setup and Run

1. Clone the repository:

    ```bash
    git clone https://github.com/zep-analytics/IPLScorePredictor-2024.git
    ```

2. Run the Flask app:

    ```bash
    python app.py
    ```

3. Open your browser and go to [http://localhost:5000](http://localhost:5000) to access the IPL Victory Predictor.

## Usage

1. Select the Batting Team, Bowling Team, Venue, Target, Score, Balls Left, and Wickets Down from the dropdowns and input fields.
2. Click the "Predict Winning Probability" button.
3. View the predicted winning probabilities for both the Batting and Bowling teams.

## Screenshots
<img width="948" alt="Screenshot 2024-01-19 123215" src="https://github.com/zep-analytics/IPLScorePredictor-2024/assets/103244316/fb369b8e-0ff2-43e8-9964-4d912a495e26">
