from flask import Flask, render_template, request
import pickle
import pandas as pd

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    if request.method == 'POST':
        batting_team = request.form['batting_team']
        bowling_team = request.form['bowling_team']
        selected_city = request.form['selected_city']
        first_innings_score = int(request.form['first_innings_score'])
        target = first_innings_score + 1  # Target is first innings score + 1

        input_data = pd.DataFrame({
            'batting_team': [batting_team],
            'bowling_team': [bowling_team],
            'city': [selected_city],
            'first_innings_score': [first_innings_score],
            'target': [target]
        })

        # Load the new model
        model = pickle.load(open('model_2024.pkl', 'rb'))
        result = model.predict_proba(input_data)

        win_probability = round(result[0][1] * 100)
        loss_probability = round(result[0][0] * 100)

        return render_template('result.html', 
                             batting_team=batting_team, 
                             bowling_team=bowling_team, 
                             win_probability=win_probability, 
                             loss_probability=loss_probability)

if __name__ == '__main__':
    app.run(debug=True)
