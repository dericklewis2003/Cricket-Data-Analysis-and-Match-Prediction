import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema (kept from original)
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Cricket team schema
export const teams = pgTable("teams", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  shortName: text("short_name").notNull(),
  flagUrl: text("flag_url"),
  countryCode: text("country_code"),
});

export const insertTeamSchema = createInsertSchema(teams).omit({ id: true });
export type InsertTeam = z.infer<typeof insertTeamSchema>;
export type Team = typeof teams.$inferSelect;

// Match schema
export const matches = pgTable("matches", {
  id: serial("id").primaryKey(),
  team1Id: integer("team1_id"),
  team2Id: integer("team2_id"),
  team1Score: text("team1_score"),
  team2Score: text("team2_score"),
  team1Overs: text("team1_overs"),
  team2Overs: text("team2_overs"),
  matchType: text("match_type").notNull(), // T20, ODI, Test
  status: text("status").notNull(), // live, upcoming, completed
  venue: text("venue"),
  date: timestamp("date").notNull(),
  result: text("result"),
  winningTeamId: integer("winning_team_id"),
  seriesName: text("series_name"),
  matchNumber: text("match_number"),
  additionalInfo: jsonb("additional_info")
});

export const insertMatchSchema = createInsertSchema(matches).omit({ id: true });
export type InsertMatch = z.infer<typeof insertMatchSchema>;
export type Match = typeof matches.$inferSelect;

// Match prediction schema
export const predictions = pgTable("predictions", {
  id: serial("id").primaryKey(),
  matchId: integer("match_id").notNull(),
  team1WinProbability: integer("team1_win_probability").notNull(),
  team2WinProbability: integer("team2_win_probability").notNull(),
  predictedScore: text("predicted_score"),
  keyPlayers: jsonb("key_players"),
  confidence: text("confidence"), // High, Medium, Low
  createdAt: timestamp("created_at").defaultNow()
});

export const insertPredictionSchema = createInsertSchema(predictions).omit({ id: true });
export type InsertPrediction = z.infer<typeof insertPredictionSchema>;
export type Prediction = typeof predictions.$inferSelect;

// Fantasy cricket player schema
export const fantasyPlayers = pgTable("fantasy_players", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  teamId: integer("team_id"),
  role: text("role").notNull(), // Batsman, Bowler, All-rounder, Wicket-keeper
  form: text("form"), // Hot form, Value pick, etc.
  rating: integer("rating"),
  imageUrl: text("image_url"),
  points: integer("points")
});

export const insertFantasyPlayerSchema = createInsertSchema(fantasyPlayers).omit({ id: true });
export type InsertFantasyPlayer = z.infer<typeof insertFantasyPlayerSchema>;
export type FantasyPlayer = typeof fantasyPlayers.$inferSelect;
