import os
import sys
import pickle
import pandas as pd
from flask import Flask, jsonify, request, make_response
from flask_cors import CORS

# Add the IPLScorePredictor directory to the path
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'IPLScorePredictor-2024-main'))

# Load the model
model_path = os.path.join(os.path.dirname(__file__), '..', 'IPLScorePredictor-2024-main', 'model_2024.pkl')
print(f"Looking for model at: {model_path}")

try:
    model = pickle.load(open(model_path, 'rb'))
    print("Successfully loaded IPL prediction model")
except Exception as e:
    print(f"Error loading model: {str(e)}")
    model = None

# Create Flask app
app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

@app.route('/api/ipl/predict', methods=['POST'])
def predict():
    if model is None:
        return jsonify({
            'error': 'Model not loaded properly'
        }), 500
        
    try:
        data = request.get_json()
        print(f"Received prediction request with data: {data}")
        
        # Extract parameters
        batting_team = data.get('batting_team')
        bowling_team = data.get('bowling_team')
        selected_city = data.get('city')
        first_innings_score = int(data.get('first_innings_score', 0))
        target = first_innings_score + 1  # Target is first innings score + 1
        
        # Validation
        if batting_team == bowling_team:
            return jsonify({
                'error': 'Batting team and bowling team cannot be the same'
            }), 400
            
        if not all([batting_team, bowling_team, selected_city]) or first_innings_score <= 0:
            return jsonify({
                'error': 'All fields are required. First innings score must be greater than 0.'
            }), 400
        
        # Prepare input for model
        input_data = pd.DataFrame({
            'batting_team': [batting_team],
            'bowling_team': [bowling_team],
            'city': [selected_city],
            'first_innings_score': [first_innings_score],
            'target': [target]
        })
        
        # Make prediction
        result = model.predict_proba(input_data)
        
        # Calculate probabilities
        win_probability = round(result[0][1] * 100)
        loss_probability = round(result[0][0] * 100)
        
        print(f"Prediction results: Win prob: {win_probability}%, Loss prob: {loss_probability}%")
        
        return jsonify({
            'batting_team': batting_team,
            'bowling_team': bowling_team,
            'city': selected_city,
            'first_innings_score': first_innings_score,
            'win_probability': win_probability,
            'loss_probability': loss_probability
        })
        
    except Exception as e:
        print(f"Error during prediction: {str(e)}")
        return jsonify({
            'error': str(e)
        }), 500

@app.route('/api/ipl/health', methods=['GET'])
def health_check():
    """Health check endpoint to verify the API is running"""
    return jsonify({
        'status': 'ok',
        'model_loaded': model is not None
    })

if __name__ == '__main__':
    print("Starting IPL Prediction Flask API on port 5001")
    app.run(host='0.0.0.0', port=5001, debug=True)