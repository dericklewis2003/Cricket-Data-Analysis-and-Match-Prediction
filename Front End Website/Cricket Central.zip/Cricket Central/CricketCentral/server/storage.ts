import { users, type User, type InsertUser } from "@shared/schema";
import { teams, type Team, type InsertTeam } from "@shared/schema";
import { matches, type Match, type InsertMatch } from "@shared/schema";
import { predictions, type Prediction, type InsertPrediction } from "@shared/schema";
import { fantasyPlayers, type FantasyPlayer, type InsertFantasyPlayer } from "@shared/schema";

// Extend the storage interface
export interface IStorage {
  // User methods (kept from original)
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Team methods
  getAllTeams(): Promise<Team[]>;
  getTeamById(id: number): Promise<Team | undefined>;
  createTeam(team: InsertTeam): Promise<Team>;
  
  // Match methods
  getAllMatches(): Promise<Match[]>;
  getLiveMatches(): Promise<Match[]>;
  getRecentMatches(limit: number): Promise<Match[]>;
  getUpcomingMatches(limit: number): Promise<Match[]>;
  getMatchById(id: number): Promise<Match | undefined>;
  createMatch(match: InsertMatch): Promise<Match>;
  updateMatch(id: number, match: Partial<InsertMatch>): Promise<Match | undefined>;
  
  // Prediction methods
  getPredictionByMatchId(matchId: number): Promise<Prediction | undefined>;
  createPrediction(prediction: InsertPrediction): Promise<Prediction>;
  
  // Fantasy player methods
  getTopFantasyPlayers(limit: number): Promise<FantasyPlayer[]>;
  getFantasyPlayerById(id: number): Promise<FantasyPlayer | undefined>;
  createFantasyPlayer(player: InsertFantasyPlayer): Promise<FantasyPlayer>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private teams: Map<number, Team>;
  private matches: Map<number, Match>;
  private predictions: Map<number, Prediction>;
  private fantasyPlayers: Map<number, FantasyPlayer>;
  private userCurrentId: number;
  private teamCurrentId: number;
  private matchCurrentId: number;
  private predictionCurrentId: number;
  private fantasyPlayerCurrentId: number;

  constructor() {
    this.users = new Map();
    this.teams = new Map();
    this.matches = new Map();
    this.predictions = new Map();
    this.fantasyPlayers = new Map();
    this.userCurrentId = 1;
    this.teamCurrentId = 1;
    this.matchCurrentId = 1;
    this.predictionCurrentId = 1;
    this.fantasyPlayerCurrentId = 1;
    
    // Initialize with some demo teams
    this.initializeTeams();
    // Initialize with some matches
    this.initializeMatches();
    // Initialize with some predictions
    this.initializePredictions();
    // Initialize with some fantasy players
    this.initializeFantasyPlayers();
  }

  // User methods (kept from original)
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userCurrentId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  // Team methods
  async getAllTeams(): Promise<Team[]> {
    return Array.from(this.teams.values());
  }
  
  async getTeamById(id: number): Promise<Team | undefined> {
    return this.teams.get(id);
  }
  
  async createTeam(insertTeam: InsertTeam): Promise<Team> {
    const id = this.teamCurrentId++;
    const team: Team = { ...insertTeam, id };
    this.teams.set(id, team);
    return team;
  }
  
  // Match methods
  async getAllMatches(): Promise<Match[]> {
    return Array.from(this.matches.values());
  }
  
  async getLiveMatches(): Promise<Match[]> {
    return Array.from(this.matches.values()).filter(
      (match) => match.status === 'live'
    );
  }
  
  async getRecentMatches(limit: number): Promise<Match[]> {
    return Array.from(this.matches.values())
      .filter((match) => match.status === 'completed')
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
      .slice(0, limit);
  }
  
  async getUpcomingMatches(limit: number): Promise<Match[]> {
    return Array.from(this.matches.values())
      .filter((match) => match.status === 'upcoming')
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
      .slice(0, limit);
  }
  
  async getMatchById(id: number): Promise<Match | undefined> {
    return this.matches.get(id);
  }
  
  async createMatch(insertMatch: InsertMatch): Promise<Match> {
    const id = this.matchCurrentId++;
    const match: Match = { ...insertMatch, id };
    this.matches.set(id, match);
    return match;
  }
  
  async updateMatch(id: number, match: Partial<InsertMatch>): Promise<Match | undefined> {
    const existingMatch = this.matches.get(id);
    if (!existingMatch) {
      return undefined;
    }
    
    const updatedMatch = { ...existingMatch, ...match };
    this.matches.set(id, updatedMatch);
    return updatedMatch;
  }
  
  // Prediction methods
  async getPredictionByMatchId(matchId: number): Promise<Prediction | undefined> {
    return Array.from(this.predictions.values()).find(
      (prediction) => prediction.matchId === matchId
    );
  }
  
  async createPrediction(insertPrediction: InsertPrediction): Promise<Prediction> {
    const id = this.predictionCurrentId++;
    const prediction: Prediction = { ...insertPrediction, id };
    this.predictions.set(id, prediction);
    return prediction;
  }
  
  // Fantasy player methods
  async getTopFantasyPlayers(limit: number): Promise<FantasyPlayer[]> {
    return Array.from(this.fantasyPlayers.values())
      .sort((a, b) => (b.rating || 0) - (a.rating || 0))
      .slice(0, limit);
  }
  
  async getFantasyPlayerById(id: number): Promise<FantasyPlayer | undefined> {
    return this.fantasyPlayers.get(id);
  }
  
  async createFantasyPlayer(insertPlayer: InsertFantasyPlayer): Promise<FantasyPlayer> {
    const id = this.fantasyPlayerCurrentId++;
    const player: FantasyPlayer = { ...insertPlayer, id };
    this.fantasyPlayers.set(id, player);
    return player;
  }
  
  // Initialize teams
  private initializeTeams() {
    // Sample teams - in real app these would be populated from an API
    const teamsData: InsertTeam[] = [
      { name: 'India', shortName: 'IND', flagUrl: 'https://cdn.britannica.com/97/1597-004-05816F4E/Flag-India.jpg', countryCode: 'IN' },
      { name: 'Australia', shortName: 'AUS', flagUrl: 'https://cdn.britannica.com/78/6078-004-77AF7322/Flag-Australia.jpg', countryCode: 'AU' },
      { name: 'England', shortName: 'ENG', flagUrl: 'https://cdn.britannica.com/44/1644-004-F5429F14/Flag-England.jpg', countryCode: 'GB' },
      { name: 'Pakistan', shortName: 'PAK', flagUrl: 'https://cdn.britannica.com/46/3346-004-D3BDE016/flag-symbolism-Pakistan-design-Islamic.jpg', countryCode: 'PK' },
      { name: 'New Zealand', shortName: 'NZ', flagUrl: 'https://cdn.britannica.com/44/34644-004-73DEF24F/Flag-New-Zealand.jpg', countryCode: 'NZ' },
      { name: 'South Africa', shortName: 'SA', flagUrl: 'https://cdn.britannica.com/27/4227-004-32423B42/Flag-South-Africa.jpg', countryCode: 'ZA' },
      { name: 'West Indies', shortName: 'WI', flagUrl: 'https://upload.wikimedia.org/wikipedia/commons/2/2b/Cricket_West_Indies_Flag.svg', countryCode: 'WI' },
      { name: 'Bangladesh', shortName: 'BAN', flagUrl: 'https://cdn.britannica.com/67/6267-004-10A21DF0/Flag-Bangladesh.jpg', countryCode: 'BD' },
      { name: 'Sri Lanka', shortName: 'SL', flagUrl: 'https://cdn.britannica.com/13/4413-004-3277D2EF/Flag-Sri-Lanka.jpg', countryCode: 'LK' }
    ];
    
    teamsData.forEach(team => {
      const id = this.teamCurrentId++;
      this.teams.set(id, { ...team, id });
    });
  }
  
  // Initialize matches
  private initializeMatches() {
    // Create some sample matches with varying statuses
    const now = new Date();
    
    // Live matches
    const liveMatches: InsertMatch[] = [
      {
        team1Id: 1, // India
        team2Id: 2, // Australia
        team1Score: '178/3',
        team2Score: '121/6',
        team1Overs: '20.0',
        team2Overs: '16.0',
        matchType: 'T20',
        status: 'live',
        venue: 'Melbourne Cricket Ground',
        date: now,
        seriesName: 'T20 World Cup',
        additionalInfo: { currentOver: '16.0', requiredRuns: 58, requiredBalls: 24 }
      },
      {
        team1Id: 3, // England
        team2Id: 6, // South Africa
        team1Score: '245/8',
        team2Score: '187/4',
        team1Overs: '50.0',
        team2Overs: '43.0',
        matchType: 'ODI',
        status: 'live',
        venue: 'Lords, London',
        date: now,
        seriesName: 'ODI Series',
        additionalInfo: { currentOver: '43.0', requiredRuns: 59, requiredBalls: 42 }
      },
      {
        team1Id: 4, // Pakistan
        team2Id: 5, // New Zealand
        team1Score: '312 & 87/3',
        team2Score: '276',
        team1Overs: '90.0 & 32.0',
        team2Overs: '85.2',
        matchType: 'Test',
        status: 'live',
        venue: 'Karachi, Pakistan',
        date: new Date(now.getTime() - 2 * 24 * 60 * 60 * 1000), // 2 days ago
        seriesName: 'Test Series',
        additionalInfo: { day: 3, session: 2, lead: 123 }
      }
    ];
    
    // Recent completed matches
    const recentMatches: InsertMatch[] = [
      {
        team1Id: 1, // India
        team2Id: 9, // Sri Lanka
        team1Score: '192/4',
        team2Score: '182/6',
        team1Overs: '20.0',
        team2Overs: '20.0',
        matchType: 'T20',
        status: 'completed',
        venue: 'R. Premadasa Stadium, Colombo',
        date: new Date(now.getTime() - 24 * 60 * 60 * 1000), // yesterday
        result: 'India won by 10 runs',
        winningTeamId: 1,
        seriesName: 'T20 Series'
      },
      {
        team1Id: 3, // England
        team2Id: 7, // West Indies
        team1Score: '315/8',
        team2Score: '318/7',
        team1Overs: '50.0',
        team2Overs: '49.2',
        matchType: 'ODI',
        status: 'completed',
        venue: 'Bridgetown, Barbados',
        date: new Date(now.getTime() - 2 * 24 * 60 * 60 * 1000), // 2 days ago
        result: 'West Indies won by 3 wickets',
        winningTeamId: 7,
        seriesName: 'ODI Series'
      },
      {
        team1Id: 2, // Australia
        team2Id: 6, // South Africa
        team1Score: '295 & 285',
        team2Score: '189 & 247',
        team1Overs: '80.4 & 75.2',
        team2Overs: '65.3 & 82.1',
        matchType: 'Test',
        status: 'completed',
        venue: 'Perth Stadium',
        date: new Date(now.getTime() - 4 * 24 * 60 * 60 * 1000), // 4 days ago
        result: 'Australia won by 144 runs',
        winningTeamId: 2,
        seriesName: 'Test Series'
      }
    ];
    
    // Upcoming matches
    const upcomingMatches: InsertMatch[] = [
      {
        team1Id: 4, // Pakistan
        team2Id: 8, // Bangladesh
        matchType: 'T20',
        status: 'upcoming',
        venue: 'Dubai International Stadium',
        date: new Date(now.getTime() + 24 * 60 * 60 * 1000), // tomorrow
        seriesName: 'T20 World Cup',
        additionalInfo: { startTime: '14:30 GMT' }
      },
      {
        team1Id: 5, // New Zealand
        team2Id: 9, // Sri Lanka
        matchType: 'ODI',
        status: 'upcoming',
        venue: 'Auckland',
        date: new Date(now.getTime() + 2 * 24 * 60 * 60 * 1000), // in 2 days
        seriesName: 'ODI Series',
        additionalInfo: { startTime: '03:00 GMT' }
      },
      {
        team1Id: 1, // India
        team2Id: 3, // England
        matchType: 'Test',
        status: 'upcoming',
        venue: 'Mumbai',
        date: new Date(now.getTime() + 4 * 24 * 60 * 60 * 1000), // in 4 days
        seriesName: 'Test Series',
        additionalInfo: { startTime: '09:30 GMT' }
      },
      {
        team1Id: 7, // West Indies
        team2Id: 6, // South Africa
        matchType: 'T20',
        status: 'upcoming',
        venue: 'Bridgetown',
        date: new Date(now.getTime() + 5 * 24 * 60 * 60 * 1000), // in 5 days
        seriesName: 'T20 Series',
        additionalInfo: { startTime: '18:00 GMT' }
      }
    ];
    
    // Add all matches to storage
    [...liveMatches, ...recentMatches, ...upcomingMatches].forEach(match => {
      const id = this.matchCurrentId++;
      this.matches.set(id, { ...match, id });
    });
  }
  
  // Initialize predictions
  private initializePredictions() {
    // Match predictions for upcoming matches
    const predictions: InsertPrediction[] = [
      {
        matchId: 7, // Pakistan vs Bangladesh
        team1WinProbability: 68,
        team2WinProbability: 32,
        predictedScore: 'PAK: 165-175',
        keyPlayers: ['Babar Azam', 'Shaheen Afridi'],
        confidence: 'High',
        createdAt: new Date()
      },
      {
        matchId: 9, // India vs England
        team1WinProbability: 53,
        team2WinProbability: 47,
        predictedScore: 'Day 1: IND 280-320',
        keyPlayers: ['Virat Kohli', 'Jasprit Bumrah'],
        confidence: 'Medium',
        createdAt: new Date()
      }
    ];
    
    predictions.forEach(prediction => {
      const id = this.predictionCurrentId++;
      this.predictions.set(id, { ...prediction, id });
    });
  }
  
  // Initialize fantasy players
  private initializeFantasyPlayers() {
    const players: InsertFantasyPlayer[] = [
      {
        name: 'Virat Kohli',
        teamId: 1, // India
        role: 'Batsman',
        form: 'TOP PICK',
        rating: 95,
        imageUrl: 'https://resources.pulse.icc-cricket.com/players/284/164.png',
        points: 350
      },
      {
        name: 'Pat Cummins',
        teamId: 2, // Australia
        role: 'Bowler',
        form: 'HOT FORM',
        rating: 92,
        imageUrl: 'https://resources.pulse.icc-cricket.com/players/284/488.png',
        points: 320
      },
      {
        name: 'Ben Stokes',
        teamId: 3, // England
        role: 'All-rounder',
        form: 'VALUE PICK',
        rating: 90,
        imageUrl: 'https://resources.pulse.icc-cricket.com/players/284/347.png',
        points: 310
      }
    ];
    
    players.forEach(player => {
      const id = this.fantasyPlayerCurrentId++;
      this.fantasyPlayers.set(id, { ...player, id });
    });
  }
}

export const storage = new MemStorage();
