import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import axios from "axios";
import { spawn } from "child_process";

export async function registerRoutes(app: Express): Promise<Server> {
  // prefix all routes with /api
  const baseUrl = "/api";
  
  // Get all teams
  app.get(`${baseUrl}/teams`, async (req, res) => {
    try {
      const teams = await storage.getAllTeams();
      res.json(teams);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch teams" });
    }
  });
  
  // Get team by ID
  app.get(`${baseUrl}/teams/:id`, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid team ID" });
      }
      
      const team = await storage.getTeamById(id);
      if (!team) {
        return res.status(404).json({ message: "Team not found" });
      }
      
      res.json(team);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch team" });
    }
  });
  
  // Get all matches
  app.get(`${baseUrl}/matches`, async (req, res) => {
    try {
      const matches = await storage.getAllMatches();
      res.json(matches);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch matches" });
    }
  });
  
  // Get live matches
  app.get(`${baseUrl}/matches/live`, async (req, res) => {
    try {
      const matches = await storage.getLiveMatches();
      res.json(matches);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch live matches" });
    }
  });
  
  // Get recent matches (completed)
  app.get(`${baseUrl}/matches/recent`, async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 5;
      const matches = await storage.getRecentMatches(limit);
      res.json(matches);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch recent matches" });
    }
  });
  
  // Get upcoming matches
  app.get(`${baseUrl}/matches/upcoming`, async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 5;
      const matches = await storage.getUpcomingMatches(limit);
      res.json(matches);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch upcoming matches" });
    }
  });
  
  // Get match by ID
  app.get(`${baseUrl}/matches/:id`, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid match ID" });
      }
      
      const match = await storage.getMatchById(id);
      if (!match) {
        return res.status(404).json({ message: "Match not found" });
      }
      
      res.json(match);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch match" });
    }
  });
  
  // Get match prediction by match ID
  app.get(`${baseUrl}/predictions/:matchId`, async (req, res) => {
    try {
      const matchId = parseInt(req.params.matchId);
      if (isNaN(matchId)) {
        return res.status(400).json({ message: "Invalid match ID" });
      }
      
      const prediction = await storage.getPredictionByMatchId(matchId);
      if (!prediction) {
        return res.status(404).json({ message: "Prediction not found for this match" });
      }
      
      res.json(prediction);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch prediction" });
    }
  });
  
  // Get top fantasy players
  app.get(`${baseUrl}/fantasy/players`, async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 3;
      const players = await storage.getTopFantasyPlayers(limit);
      res.json(players);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch fantasy players" });
    }
  });
  
  // Create a match (for admin purposes)
  app.post(`${baseUrl}/matches`, async (req, res) => {
    try {
      const match = await storage.createMatch(req.body);
      res.status(201).json(match);
    } catch (error) {
      res.status(500).json({ message: "Failed to create match" });
    }
  });
  
  // Update a match (for admin or to simulate live updates)
  app.put(`${baseUrl}/matches/:id`, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid match ID" });
      }
      
      const updatedMatch = await storage.updateMatch(id, req.body);
      if (!updatedMatch) {
        return res.status(404).json({ message: "Match not found" });
      }
      
      res.json(updatedMatch);
    } catch (error) {
      res.status(500).json({ message: "Failed to update match" });
    }
  });

  // NewsAPI endpoints
  // Get latest cricket news
  app.get(`${baseUrl}/news`, async (req, res) => {
    try {
      const page = parseInt(req.query.page as string) || 1;
      const pageSize = parseInt(req.query.pageSize as string) || 10;
      
      // Using the NEWS_API_KEY from environment variables
      const apiKey = process.env.NEWS_API_KEY;
      if (!apiKey) {
        return res.status(500).json({ message: "API key not configured" });
      }

      // We'll use NewsAPI to get top cricket news
      const response = await axios.get('https://newsapi.org/v2/everything', {
        params: {
          q: 'cricket',
          language: 'en',
          sortBy: 'publishedAt',
          pageSize,
          page,
          apiKey
        }
      });
      
      res.json(response.data);
    } catch (error) {
      console.error("Error fetching news:", error);
      res.status(500).json({ 
        message: "Failed to fetch news", 
        details: error instanceof Error ? error.message : "Unknown error" 
      });
    }
  });

  // Search cricket news
  app.get(`${baseUrl}/news/search`, async (req, res) => {
    try {
      const query = req.query.q as string;
      const page = parseInt(req.query.page as string) || 1;
      const pageSize = parseInt(req.query.pageSize as string) || 10;
      
      if (!query) {
        return res.status(400).json({ message: "Search query is required" });
      }
      
      // Using the NEWS_API_KEY from environment variables
      const apiKey = process.env.NEWS_API_KEY;
      if (!apiKey) {
        return res.status(500).json({ message: "API key not configured" });
      }

      // We'll use NewsAPI to search for cricket news
      const response = await axios.get('https://newsapi.org/v2/everything', {
        params: {
          q: `cricket AND ${query}`,
          language: 'en',
          sortBy: 'publishedAt',
          pageSize,
          page,
          apiKey
        }
      });
      
      res.json(response.data);
    } catch (error) {
      console.error("Error searching news:", error);
      res.status(500).json({ 
        message: "Failed to search news", 
        details: error instanceof Error ? error.message : "Unknown error" 
      });
    }
  });

  // Cricket Data API endpoints with improved error handling and retry logic
  
  /**
   * Helper function to make API requests with retry logic
   * @param url API URL
   * @param params Request parameters
   * @param maxRetries Maximum number of retries (default 2)
   * @returns API response data
   */
  async function fetchWithRetry(url: string, params: any, maxRetries = 2) {
    let retries = 0;
    let lastError: Error | null = null;
    
    while (retries <= maxRetries) {
      try {
        const response = await axios.get(url, { params });
        
        if (response.data.status !== "success") {
          const errorMessage = response.data.message || `API returned status: ${response.data.status}`;
          throw new Error(errorMessage);
        }
        
        return response.data.data;
      } catch (error) {
        lastError = error instanceof Error ? error : new Error(String(error));
        
        // Check if it's worth retrying (rate limiting or server errors)
        if (axios.isAxiosError(error) && error.response) {
          const status = error.response.status;
          if ([429, 500, 502, 503, 504].includes(status) && retries < maxRetries) {
            console.log(`Retrying API request (${retries + 1}/${maxRetries}) after error: ${error.message}`);
            retries++;
            // Exponential backoff
            await new Promise(resolve => setTimeout(resolve, 1000 * 2 ** retries));
            continue;
          }
        }
        
        // If we reached max retries or it's not a retriable error, give up
        console.error(`API request failed after ${retries} retries:`, error);
        throw lastError;
      }
    }
    
    // This should never be reached due to the throw in the catch block
    throw lastError || new Error('Unknown error occurred during API request');
  }
  
  // Cricket Stats API endpoints for statistics and performance metrics
  
  // Get top batsmen by format
  app.get(`${baseUrl}/cricket/stats/batting`, async (req, res) => {
    try {
      const apiKey = process.env.CRICKET_DATA_API_KEY;
      if (!validateApiKey(apiKey, res)) return;
      
      const format = (req.query.format as string) || 't20';
      const limit = parseInt(req.query.limit as string) || 10;
      
      // Format validation
      if (!['t20', 'odi', 'test'].includes(format.toLowerCase())) {
        return res.status(400).json({ message: "Invalid format. Use t20, odi, or test." });
      }
      
      // Cache key for better performance
      const cacheKey = `batting_${format}_${limit}`;
      
      // In a real app, this would make an API call to CricketData.org or another API
      // For now, we'll use mock data based on the format
      const endpoint = `https://api.cricapi.com/v1/players_stats`;
      
      try {
        const data = await fetchWithRetry(endpoint, {
          apikey: apiKey,
          format: format,
          statsType: 'batting',
          limit: limit
        });
        
        // Map the API response to our PlayerStats interface
        const battingStats = data.map((player: any) => ({
          id: player.id || String(Math.random().toString(36).substr(2, 9)),
          name: player.name,
          team: player.country,
          imageUrl: player.playerImg,
          battingStats: {
            matches: player.stats?.batting?.[format]?.matches || 0,
            innings: player.stats?.batting?.[format]?.innings || 0,
            runs: player.stats?.batting?.[format]?.runs || 0,
            average: player.stats?.batting?.[format]?.average || 0,
            strikeRate: player.stats?.batting?.[format]?.strikeRate || 0,
            fifties: player.stats?.batting?.[format]?.fifties || 0,
            hundreds: player.stats?.batting?.[format]?.hundreds || 0,
            highestScore: player.stats?.batting?.[format]?.highest || 0,
            fours: player.stats?.batting?.[format]?.fours || 0,
            sixes: player.stats?.batting?.[format]?.sixes || 0
          }
        }));
        
        res.json(battingStats);
      } catch (error) {
        console.error(`Error fetching batting stats: ${error instanceof Error ? error.message : String(error)}`);
        res.status(503).json({ 
          message: "Unable to fetch batting statistics at this time", 
          error: error instanceof Error ? error.message : String(error)
        });
      }
    } catch (error) {
      res.status(500).json({ 
        message: "Server error while fetching batting statistics",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });
  
  // Get top bowlers by format
  app.get(`${baseUrl}/cricket/stats/bowling`, async (req, res) => {
    try {
      const apiKey = process.env.CRICKET_DATA_API_KEY;
      if (!validateApiKey(apiKey, res)) return;
      
      const format = (req.query.format as string) || 't20';
      const limit = parseInt(req.query.limit as string) || 10;
      
      // Format validation
      if (!['t20', 'odi', 'test'].includes(format.toLowerCase())) {
        return res.status(400).json({ message: "Invalid format. Use t20, odi, or test." });
      }
      
      // In a real app, this would make an API call to CricketData.org or another API
      const endpoint = `https://api.cricapi.com/v1/players_stats`;
      
      try {
        const data = await fetchWithRetry(endpoint, {
          apikey: apiKey,
          format: format,
          statsType: 'bowling',
          limit: limit
        });
        
        // Map the API response to our PlayerStats interface
        const bowlingStats = data.map((player: any) => ({
          id: player.id || String(Math.random().toString(36).substr(2, 9)),
          name: player.name,
          team: player.country,
          imageUrl: player.playerImg,
          bowlingStats: {
            matches: player.stats?.bowling?.[format]?.matches || 0,
            innings: player.stats?.bowling?.[format]?.innings || 0,
            wickets: player.stats?.bowling?.[format]?.wickets || 0,
            average: player.stats?.bowling?.[format]?.average || 0,
            economy: player.stats?.bowling?.[format]?.economy || 0,
            bestFigures: player.stats?.bowling?.[format]?.bestInning || '0/0',
            fourWickets: player.stats?.bowling?.[format]?.fourWickets || 0,
            fiveWickets: player.stats?.bowling?.[format]?.fiveWickets || 0
          }
        }));
        
        res.json(bowlingStats);
      } catch (error) {
        console.error(`Error fetching bowling stats: ${error instanceof Error ? error.message : String(error)}`);
        res.status(503).json({ 
          message: "Unable to fetch bowling statistics at this time", 
          error: error instanceof Error ? error.message : String(error)
        });
      }
    } catch (error) {
      res.status(500).json({ 
        message: "Server error while fetching bowling statistics",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });
  
  // Get team performance stats by format
  app.get(`${baseUrl}/cricket/stats/teams`, async (req, res) => {
    try {
      const apiKey = process.env.CRICKET_DATA_API_KEY;
      if (!validateApiKey(apiKey, res)) return;
      
      const format = (req.query.format as string) || 't20';
      
      // Format validation
      if (!['t20', 'odi', 'test'].includes(format.toLowerCase())) {
        return res.status(400).json({ message: "Invalid format. Use t20, odi, or test." });
      }
      
      // In a real app, this would make an API call to CricketData.org or another API
      const endpoint = `https://api.cricapi.com/v1/teams_stats`;
      
      try {
        const data = await fetchWithRetry(endpoint, {
          apikey: apiKey,
          format: format
        });
        
        // Map the API response to our TeamStats interface
        const teamStats = data.map((team: any) => {
          const total = team.matches || 0;
          const won = team.matchesWon || 0;
          const lost = team.matchesLost || 0;
          const tied = team.matchesTied || 0;
          const noResult = team.matchesNoResult || 0;
          
          // Calculate win percentage
          const winPercentage = total > 0 
            ? Math.round((won / (total - noResult)) * 100) 
            : 0;
            
          return {
            id: team.id || String(Math.random().toString(36).substr(2, 9)),
            name: team.name,
            matches: total,
            won: won,
            lost: lost,
            tied: tied,
            noResult: noResult,
            winPercentage: winPercentage,
            imageUrl: team.teamImg
          };
        });
        
        res.json(teamStats);
      } catch (error) {
        console.error(`Error fetching team stats: ${error instanceof Error ? error.message : String(error)}`);
        res.status(503).json({ 
          message: "Unable to fetch team statistics at this time", 
          error: error instanceof Error ? error.message : String(error)
        });
      }
    } catch (error) {
      res.status(500).json({ 
        message: "Server error while fetching team statistics",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });
  
  // Search for player stats by name
  app.get(`${baseUrl}/cricket/stats/search`, async (req, res) => {
    try {
      const apiKey = process.env.CRICKET_DATA_API_KEY;
      if (!validateApiKey(apiKey, res)) return;
      
      const name = req.query.name as string;
      const format = (req.query.format as string) || 't20';
      
      if (!name || name.trim() === '') {
        return res.status(400).json({ message: "Player name is required for search" });
      }
      
      // Format validation
      if (!['t20', 'odi', 'test'].includes(format.toLowerCase())) {
        return res.status(400).json({ message: "Invalid format. Use t20, odi, or test." });
      }
      
      // In a real app, this would make an API call to CricketData.org or another API
      const endpoint = `https://api.cricapi.com/v1/players`;
      
      try {
        const data = await fetchWithRetry(endpoint, {
          apikey: apiKey,
          search: name,
          offset: 0
        });
        
        // Get player details for the found players
        const playerPromises = data.slice(0, 5).map(async (player: any) => {
          try {
            const playerData = await fetchWithRetry(`https://api.cricapi.com/v1/players_info`, {
              apikey: apiKey,
              id: player.id
            });
            
            return {
              id: playerData.id || player.id,
              name: playerData.name,
              team: playerData.country,
              imageUrl: playerData.playerImg,
              battingStats: playerData.stats?.batting?.[format] ? {
                matches: playerData.stats?.batting?.[format]?.matches || 0,
                innings: playerData.stats?.batting?.[format]?.innings || 0,
                runs: playerData.stats?.batting?.[format]?.runs || 0,
                average: playerData.stats?.batting?.[format]?.average || 0,
                strikeRate: playerData.stats?.batting?.[format]?.strikeRate || 0,
                fifties: playerData.stats?.batting?.[format]?.fifties || 0,
                hundreds: playerData.stats?.batting?.[format]?.hundreds || 0,
                highestScore: playerData.stats?.batting?.[format]?.highest || 0
              } : undefined,
              bowlingStats: playerData.stats?.bowling?.[format] ? {
                matches: playerData.stats?.bowling?.[format]?.matches || 0,
                innings: playerData.stats?.bowling?.[format]?.innings || 0,
                wickets: playerData.stats?.bowling?.[format]?.wickets || 0,
                average: playerData.stats?.bowling?.[format]?.average || 0,
                economy: playerData.stats?.bowling?.[format]?.economy || 0,
                bestFigures: playerData.stats?.bowling?.[format]?.bestInning || '0/0'
              } : undefined
            };
          } catch (error) {
            console.error(`Error fetching details for player ${player.name}: ${error instanceof Error ? error.message : String(error)}`);
            // Return basic player info if detailed fetch fails
            return {
              id: player.id,
              name: player.name,
              team: player.country || 'Unknown',
              imageUrl: player.playerImg
            };
          }
        });
        
        const players = await Promise.all(playerPromises);
        res.json(players);
      } catch (error) {
        console.error(`Error searching for players: ${error instanceof Error ? error.message : String(error)}`);
        res.status(503).json({ 
          message: "Unable to search for players at this time", 
          error: error instanceof Error ? error.message : String(error)
        });
      }
    } catch (error) {
      res.status(500).json({ 
        message: "Server error during player search",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });
  
  // Get detailed stats for a specific player
  app.get(`${baseUrl}/cricket/stats/player/:id`, async (req, res) => {
    try {
      const apiKey = process.env.CRICKET_DATA_API_KEY;
      if (!validateApiKey(apiKey, res)) return;
      
      const playerId = req.params.id;
      const format = (req.query.format as string) || 't20';
      
      if (!playerId) {
        return res.status(400).json({ message: "Player ID is required" });
      }
      
      // Format validation
      if (!['t20', 'odi', 'test'].includes(format.toLowerCase())) {
        return res.status(400).json({ message: "Invalid format. Use t20, odi, or test." });
      }
      
      // In a real app, this would make an API call to CricketData.org or another API
      const endpoint = `https://api.cricapi.com/v1/players_info`;
      
      try {
        const playerData = await fetchWithRetry(endpoint, {
          apikey: apiKey,
          id: playerId
        });
        
        const playerStats = {
          id: playerData.id,
          name: playerData.name,
          team: playerData.country,
          imageUrl: playerData.playerImg,
          battingStats: playerData.stats?.batting?.[format] ? {
            matches: playerData.stats?.batting?.[format]?.matches || 0,
            innings: playerData.stats?.batting?.[format]?.innings || 0,
            runs: playerData.stats?.batting?.[format]?.runs || 0,
            average: playerData.stats?.batting?.[format]?.average || 0,
            strikeRate: playerData.stats?.batting?.[format]?.strikeRate || 0,
            fifties: playerData.stats?.batting?.[format]?.fifties || 0,
            hundreds: playerData.stats?.batting?.[format]?.hundreds || 0,
            highestScore: playerData.stats?.batting?.[format]?.highest || 0,
            fours: playerData.stats?.batting?.[format]?.fours || 0,
            sixes: playerData.stats?.batting?.[format]?.sixes || 0
          } : undefined,
          bowlingStats: playerData.stats?.bowling?.[format] ? {
            matches: playerData.stats?.bowling?.[format]?.matches || 0,
            innings: playerData.stats?.bowling?.[format]?.innings || 0,
            wickets: playerData.stats?.bowling?.[format]?.wickets || 0,
            average: playerData.stats?.bowling?.[format]?.average || 0,
            economy: playerData.stats?.bowling?.[format]?.economy || 0,
            bestFigures: playerData.stats?.bowling?.[format]?.bestInning || '0/0',
            fourWickets: playerData.stats?.bowling?.[format]?.fourWickets || 0,
            fiveWickets: playerData.stats?.bowling?.[format]?.fiveWickets || 0
          } : undefined
        };
        
        res.json(playerStats);
      } catch (error) {
        console.error(`Error fetching player details: ${error instanceof Error ? error.message : String(error)}`);
        res.status(503).json({ 
          message: "Unable to fetch player details at this time", 
          error: error instanceof Error ? error.message : String(error)
        });
      }
    } catch (error) {
      res.status(500).json({ 
        message: "Server error while fetching player details",
        error: error instanceof Error ? error.message : String(error)
      });
    }
  });
  
  // Validate API key and handle missing key errors
  function validateApiKey(apiKey: string | undefined, res: any): boolean {
    if (!apiKey) {
      res.status(503).json({ 
        message: "Cricket Data API key not configured", 
        code: "API_KEY_MISSING",
        error: "Please configure the CRICKET_DATA_API_KEY environment variable."
      });
      return false;
    }
    return true;
  }
  
  // Get live cricket matches
  app.get(`${baseUrl}/cricket/matches/live`, async (req, res) => {
    try {
      const apiKey = process.env.CRICKET_DATA_API_KEY;
      if (!validateApiKey(apiKey, res)) return;

      const data = await fetchWithRetry('https://api.cricapi.com/v1/currentMatches', {
        apikey: apiKey,
        offset: 0
      });
      
      // Ensure we always return an array, even if the API doesn't
      if (!Array.isArray(data)) {
        res.json([]);
        return;
      }
      
      // Sort matches by date, most recent first
      const sortedMatches = [...data].sort((a, b) => {
        const dateA = new Date(a.dateTimeGMT);
        const dateB = new Date(b.dateTimeGMT);
        return dateB.getTime() - dateA.getTime();
      });
      
      res.json(sortedMatches);
    } catch (error) {
      console.error("Error fetching live cricket matches:", error);
      const statusCode = axios.isAxiosError(error) && error.response ? error.response.status : 500;
      res.status(statusCode).json({ 
        message: "Failed to fetch live cricket matches", 
        code: "LIVE_MATCHES_FETCH_FAILED",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Get upcoming cricket matches
  app.get(`${baseUrl}/cricket/matches/upcoming`, async (req, res) => {
    try {
      const apiKey = process.env.CRICKET_DATA_API_KEY;
      if (!validateApiKey(apiKey, res)) return;

      const data = await fetchWithRetry('https://api.cricapi.com/v1/matches', {
        apikey: apiKey,
        offset: 0
      });
      
      // Filter for upcoming matches (not started yet)
      const upcomingMatches = Array.isArray(data) 
        ? data.filter((match: any) => !match.matchStarted)
        : [];
      
      // Sort by date, closest first
      const sortedMatches = upcomingMatches.sort((a: any, b: any) => {
        const dateA = new Date(a.dateTimeGMT);
        const dateB = new Date(b.dateTimeGMT);
        return dateA.getTime() - dateB.getTime();
      });
      
      res.json(sortedMatches);
    } catch (error) {
      console.error("Error fetching upcoming cricket matches:", error);
      const statusCode = axios.isAxiosError(error) && error.response ? error.response.status : 500;
      res.status(statusCode).json({ 
        message: "Failed to fetch upcoming cricket matches", 
        code: "UPCOMING_MATCHES_FETCH_FAILED",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Get recent cricket matches
  app.get(`${baseUrl}/cricket/matches/recent`, async (req, res) => {
    try {
      const apiKey = process.env.CRICKET_DATA_API_KEY;
      if (!validateApiKey(apiKey, res)) return;

      const data = await fetchWithRetry('https://api.cricapi.com/v1/matches', {
        apikey: apiKey,
        offset: 0
      });
      
      // Filter for completed matches
      const recentMatches = Array.isArray(data)
        ? data.filter((match: any) => match.matchStarted && match.matchEnded)
        : [];
      
      // Sort by date, most recent first
      const sortedMatches = recentMatches.sort((a: any, b: any) => {
        const dateA = new Date(a.dateTimeGMT);
        const dateB = new Date(b.dateTimeGMT);
        return dateB.getTime() - dateA.getTime();
      });
      
      res.json(sortedMatches);
    } catch (error) {
      console.error("Error fetching recent cricket matches:", error);
      const statusCode = axios.isAxiosError(error) && error.response ? error.response.status : 500;
      res.status(statusCode).json({ 
        message: "Failed to fetch recent cricket matches", 
        code: "RECENT_MATCHES_FETCH_FAILED",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Get cricket match details by ID
  app.get(`${baseUrl}/cricket/matches/:id`, async (req, res) => {
    try {
      const matchId = req.params.id;
      if (!matchId || matchId.trim() === '') {
        return res.status(400).json({ 
          message: "Match ID is required",
          code: "INVALID_MATCH_ID" 
        });
      }
      
      const apiKey = process.env.CRICKET_DATA_API_KEY;
      if (!validateApiKey(apiKey, res)) return;

      const data = await fetchWithRetry('https://api.cricapi.com/v1/match_info', {
        apikey: apiKey,
        id: matchId
      });
      
      if (!data) {
        return res.status(404).json({ 
          message: "Match not found",
          code: "MATCH_NOT_FOUND" 
        });
      }
      
      res.json(data);
    } catch (error) {
      console.error(`Error fetching cricket match details for ID ${req.params.id}:`, error);
      
      // Determine if it's a "not found" error based on the error message
      const errorMessage = error instanceof Error ? error.message : "Unknown error";
      if (errorMessage.includes("not found") || errorMessage.includes("invalid id")) {
        return res.status(404).json({ 
          message: "Match not found",
          code: "MATCH_NOT_FOUND",
          error: errorMessage
        });
      }
      
      const statusCode = axios.isAxiosError(error) && error.response ? error.response.status : 500;
      res.status(statusCode).json({ 
        message: "Failed to fetch cricket match details", 
        code: "MATCH_DETAILS_FETCH_FAILED",
        error: errorMessage
      });
    }
  });

  // Search cricket players
  app.get(`${baseUrl}/cricket/players/search`, async (req, res) => {
    try {
      const name = req.query.name as string;
      
      if (!name || name.trim() === '') {
        return res.status(400).json({ 
          message: "Player name is required",
          code: "INVALID_PLAYER_NAME" 
        });
      }
      
      const apiKey = process.env.CRICKET_DATA_API_KEY;
      if (!validateApiKey(apiKey, res)) return;

      const data = await fetchWithRetry('https://api.cricapi.com/v1/players', {
        apikey: apiKey,
        offset: 0,
        search: name
      });
      
      res.json(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error(`Error searching cricket players for "${req.query.name}":`, error);
      const statusCode = axios.isAxiosError(error) && error.response ? error.response.status : 500;
      res.status(statusCode).json({ 
        message: "Failed to search cricket players", 
        code: "PLAYER_SEARCH_FAILED",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Get cricket player details by ID
  app.get(`${baseUrl}/cricket/players/:id`, async (req, res) => {
    try {
      const playerId = req.params.id;
      if (!playerId || playerId.trim() === '') {
        return res.status(400).json({ 
          message: "Player ID is required",
          code: "INVALID_PLAYER_ID" 
        });
      }
      
      const apiKey = process.env.CRICKET_DATA_API_KEY;
      if (!validateApiKey(apiKey, res)) return;

      const data = await fetchWithRetry('https://api.cricapi.com/v1/players_info', {
        apikey: apiKey,
        id: playerId
      });
      
      if (!data) {
        return res.status(404).json({ 
          message: "Player not found",
          code: "PLAYER_NOT_FOUND" 
        });
      }
      
      res.json(data);
    } catch (error) {
      console.error(`Error fetching cricket player details for ID ${req.params.id}:`, error);
      
      // Determine if it's a "not found" error based on the error message
      const errorMessage = error instanceof Error ? error.message : "Unknown error";
      if (errorMessage.includes("not found") || errorMessage.includes("invalid id")) {
        return res.status(404).json({ 
          message: "Player not found",
          code: "PLAYER_NOT_FOUND",
          error: errorMessage
        });
      }
      
      const statusCode = axios.isAxiosError(error) && error.response ? error.response.status : 500;
      res.status(statusCode).json({ 
        message: "Failed to fetch cricket player details", 
        code: "PLAYER_DETAILS_FETCH_FAILED",
        error: errorMessage
      });
    }
  });

  // Start the Python Flask app for IPL prediction
  const pythonProcess = spawn('python3', ['server/ipl_predictor_api.py']);
  
  // Log Python process output
  pythonProcess.stdout.on('data', (data) => {
    console.log(`IPL Predictor (Python): ${data}`);
  });
  
  pythonProcess.stderr.on('data', (data) => {
    console.error(`IPL Predictor Error (Python): ${data}`);
  });
  
  pythonProcess.on('close', (code) => {
    console.log(`IPL Predictor process exited with code ${code}`);
  });
  
  // Wait briefly for the Flask server to start
  await new Promise(resolve => setTimeout(resolve, 2000));
  
  // Integrate IPL predictor endpoint
  app.post(`${baseUrl}/ipl/predict`, async (req, res) => {
    try {
      // Forward the request to our Flask API
      const response = await axios.post('http://localhost:5001/api/ipl/predict', req.body, {
        headers: {
          'Content-Type': 'application/json'
        }
      });
      
      res.json(response.data);
    } catch (error) {
      console.error("Error with IPL prediction:", error);
      
      // Handle different types of errors
      if (axios.isAxiosError(error) && error.response) {
        // The request was made and the server responded with a status code
        // that falls out of the range of 2xx
        const status = error.response.status;
        const data = error.response.data;
        
        res.status(status).json({
          message: "IPL Prediction Error",
          details: data.error || error.message
        });
      } else {
        // Something happened in setting up the request that triggered an Error
        res.status(500).json({
          message: "IPL Prediction Service Error",
          details: error instanceof Error ? error.message : "Unknown error occurred"
        });
      }
    }
  });
  
  const httpServer = createServer(app);
  return httpServer;
}
