import os
import pandas as pd

# Define the path to the directory containing CSV files
csv_folder_path = r'D:\Major Project\Data Set\Test'
# Define the path for the combined CSV file
combined_csv_file_path = os.path.join(csv_folder_path, 'combined_match_results.csv')

# List to hold DataFrames for combining
dataframes = []

# Process each CSV file in the directory
for filename in os.listdir(csv_folder_path):
    if filename.endswith('.csv'):
        csv_file_path = os.path.join(csv_folder_path, filename)
        print(f'Processing file: {csv_file_path}')
        
        # Load the CSV data into a DataFrame
        try:
            df = pd.read_csv(csv_file_path)
            dataframes.append(df)
            print(f'Loaded CSV file: {csv_file_path}')
        except Exception as e:
            print(f'Error loading CSV file {csv_file_path}: {e}')

# Combine all DataFrames into a single DataFrame
if dataframes:
    combined_df = pd.concat(dataframes, ignore_index=True)
    
    # Save the combined DataFrame to a CSV file
    try:
        combined_df.to_csv(combined_csv_file_path, index=False)
        print(f'Combined CSV file saved: {combined_csv_file_path}')
    except Exception as e:
        print(f'Error saving combined CSV file {combined_csv_file_path}: {e}')
else:
    print('No CSV files found to combine.')