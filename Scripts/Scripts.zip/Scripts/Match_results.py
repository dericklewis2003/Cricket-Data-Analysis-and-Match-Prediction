import requests
from bs4 import BeautifulSoup
import json

BASE_URL = 'https://www.espncricinfo.com/records/year/team-match-results/2015-2015/twenty20-internationals-3'

def fetch_page_content(url):
    response = requests.get(url)
    if response.status_code == 200:
        return response.text
    else:
        print(f"Failed to fetch: {url}")
        return None

def extract_match_results(html_content):
    soup = BeautifulSoup(html_content, 'html.parser')
    table = soup.find('table', class_='ds-table')
    rows = table.find_all('tr')[1:]  # Skip header row
    
    match_results = []
    for row in rows:
        cells = row.find_all('td')
        if len(cells) >= 7:
            match_result = {
                "team1": cells[0].text.strip(),
                "team2": cells[1].text.strip(),
                "winner": cells[2].text.strip(),
                "margin": cells[3].text.strip(),
                "ground": cells[4].text.strip(),
                "matchDate": cells[5].text.strip(),
                "scorecard": cells[6].text.strip()
            }
            match_results.append(match_result)
    
    return match_results

def save_to_json(data, filename):
    with open(filename, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=4, ensure_ascii=False)

def main():
    html_content = fetch_page_content(BASE_URL)
    if html_content:
        match_results = extract_match_results(html_content)
        save_to_json(match_results, 'Match Results 2015-2024/Match results 2015.json')
        print(f"Saved {len(match_results)} match results to JSON file.")
    else:
        print("Failed to fetch data.")

if __name__ == "__main__":
    main()