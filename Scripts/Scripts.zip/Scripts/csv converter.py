import os
import json
import pandas as pd
import subprocess  # To open the CSV files

# Define the path to the directory containing JSON files
path = r'D:\DATA SET\Match Results 2015-2024'
# Define the new folder name for saving CSV files
new_folder_name = 'Converted_CSV_Files'
new_folder_path = os.path.join(path, new_folder_name)

# Create the new folder if it doesn't exist
if not os.path.exists(new_folder_path):
    os.makedirs(new_folder_path)
    print(f'Created folder: {new_folder_path}')
else:
    print(f'Folder already exists: {new_folder_path}')

# Process each JSON file in the directory
for filename in os.listdir(path):
    json_file_path = os.path.join(path, filename)
    
    # Skip the new CSV folder to avoid infinite loop or CSV file processing
    if filename == new_folder_name or not filename.endswith('.json'):
        continue
    
    print(f'Processing file: {json_file_path}')
    
    # Load the JSON data
    try:
        with open(json_file_path, 'r', encoding='utf-8') as json_file:
            data = json.load(json_file)
    except Exception as e:
        print(f'Error loading JSON file {json_file_path}: {e}')
        continue
    
    # Check if the JSON is a list of records
    if isinstance(data, dict):
        # If it's a dict, we need to wrap it in a list for the DataFrame
        data = [data]
    
    # Convert JSON data to DataFrame
    try:
        df = pd.DataFrame(data)
    except ValueError as e:
        print(f'Error converting JSON to DataFrame for file {json_file_path}: {e}')
        continue
    
    # Rename the 'scorecard' column to 'match_id' if it exists
    if 'scorecard' in df.columns:
        df.rename(columns={'scorecard': 'match_id'}, inplace=True)
        print(f'Renamed column "scorecard" to "match_id" in file: {filename}')
    
    # Define the CSV file path in the new folder
    csv_file_path = os.path.join(new_folder_path, f'{os.path.splitext(filename)[0]}.csv')
    
    # Save the DataFrame to a CSV file
    try:
        df.to_csv(csv_file_path, index=False)
        print(f'Saved CSV file: {csv_file_path}')
        
        # Optional: Open the CSV file in Excel after saving (this step is optional)
        # Uncomment if you want the files to open in Excel automatically
        # subprocess.Popen(['start', 'excel', csv_file_path], shell=True)
    except Exception as e:
        print(f'Error saving CSV file {csv_file_path}: {e}')
