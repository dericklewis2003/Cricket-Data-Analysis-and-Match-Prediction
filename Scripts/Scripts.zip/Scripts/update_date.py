import pandas as pd

# Paths for the CSV files
combined_match_results_path = r"D:\Major Project\Data Set\CSV_Files\Match_Results 2015-2024_CSV_Files\Match results 2015.csv"
batting_summary_path = r"D:\Major Project\Data Set\Test data\2015 Data\2015_batting_summary.csv"
bowling_summary_path = r"D:\Major Project\Data Set\Test data\2015 Data\2015_bowling_summary.csv"

# Function to update match date in batting and bowling summary
def update_match_date():
    print("Reading combined match results CSV...")
    combined_df = pd.read_csv(combined_match_results_path)
    
    # Check for 'match_id' column
    if 'match_id' not in combined_df.columns:
        raise ValueError("Column 'match_id' not found in combined match results.")
    
    # Strip whitespace and ensure consistent data type
    combined_df['match_id'] = combined_df['match_id'].str.strip().astype(str)

    print(f"Combined match results loaded with {len(combined_df)} records.")
    print("Columns in combined match results:", combined_df.columns.tolist())

    print("Reading batting summary CSV...")
    batting_df = pd.read_csv(batting_summary_path)
    
    # Check for 'match_id' column
    if 'match_id' not in batting_df.columns:
        raise ValueError("Column 'match_id' not found in batting summary.")
    
    # Strip whitespace and ensure consistent data type
    batting_df['match_id'] = batting_df['match_id'].str.strip().astype(str)

    print(f"Batting summary loaded with {len(batting_df)} records.")
    print("Columns in batting summary:", batting_df.columns.tolist())

    print("Reading bowling summary CSV...")
    bowling_df = pd.read_csv(bowling_summary_path)
    
    # Check for 'match_id' column
    if 'match_id' not in bowling_df.columns:
        raise ValueError("Column 'match_id' not found in bowling summary.")
    
    # Strip whitespace and ensure consistent data type
    bowling_df['match_id'] = bowling_df['match_id'].str.strip().astype(str)

    print(f"Bowling summary loaded with {len(bowling_df)} records.")
    print("Columns in bowling summary:", bowling_df.columns.tolist())

    # Create a DataFrame for match results with relevant columns
    match_results_df = combined_df[['match_id', 'matchDate']]  # Ensure correct column name

    # Check for duplicates in match_results_df
    if match_results_df['match_id'].duplicated().any():
        print("Warning: Duplicate match_id found in combined match results. This may cause issues during merging.")

    # Debugging: Print unique match_id values
    print("Unique match_id in batting summary:", batting_df['match_id'].unique())
    print("Unique match_id in match results:", match_results_df['match_id'].unique())

    # Update Match Date in batting summary
    print("Updating Match Date in batting summary...")
    batting_df = batting_df.merge(match_results_df, on='match_id', how='left', suffixes=('', '_new'))
    
    # Rename the new column to "Match Date"
    if 'match_date' in batting_df.columns:  # Ensure correct column name
        batting_df.rename(columns={'match_date': 'Match Date'}, inplace=True)  # Rename to "Match Date"
        print("Batting summary updated with match dates.")
    else:
        print("Column 'match_date' not found in batting summary after merge.")

    # Update Match Date in bowling summary
    print("Updating Match Date in bowling summary...")
    bowling_df = bowling_df.merge(match_results_df, on='match_id', how='left', suffixes=('', '_new'))
    
    # Rename the new column to "Match Date"
    if 'match_date' in bowling_df.columns:  # Ensure correct column name
        bowling_df.rename(columns={'match_date': 'Match Date'}, inplace=True)  # Rename to "Match Date"
        print("Bowling summary updated with match dates.")
    else:
        print("Column 'match_date' not found in bowling summary after merge.")

    # Display the final DataFrames
    print("\nUpdated Batting Summary:")
    print(batting_df.head())  # Display first few rows for inspection

    print("\nUpdated Bowling Summary:")
    print(bowling_df.head())  # Display first few rows for inspection

    # Return updated DataFrames
    return batting_df, bowling_df

# Run the function and get updated DataFrames
batting_df, bowling_df = update_match_date()

# Save the updated batting summary
batting_df.to_csv(batting_summary_path, index=False)

# Save the updated bowling summary
bowling_df.to_csv(bowling_summary_path, index=False)
