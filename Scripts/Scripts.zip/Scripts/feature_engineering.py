import pandas as pd
import numpy as np
from datetime import datetime

def add_last_5_overs_features(df):
    """
    Add Run_In_Last5 and Wickets_In_Last5 features
    """
    # Sort by match_id and over to ensure correct order
    df = df.sort_values(['match_id', 'over'])
    
    # Calculate rolling sums for last 5 overs
    df['Run_In_Last5'] = df.groupby('match_id')['runs'].rolling(window=30, min_periods=1).sum().reset_index(0, drop=True)
    df['Wickets_In_Last5'] = df.groupby('match_id')['wickets'].rolling(window=30, min_periods=1).sum().reset_index(0, drop=True)
    
    return df

def add_average_score_feature(df):
    """
    Add AverageScore feature based on venue
    """
    # Calculate average score for each venue
    venue_avg_scores = df.groupby('venue')['runs'].mean().reset_index()
    venue_avg_scores.columns = ['venue', 'AverageScore']
    
    # Merge with original dataframe
    df = df.merge(venue_avg_scores, on='venue', how='left')
    
    return df

def main():
    # Read the current dataset
    print("Reading dataset...")
    df = pd.read_csv("Model/Data/processed/ball_by_ball_data_20250319_004730.csv")
    
    # Add features
    print("Adding Last 5 Overs features...")
    df = add_last_5_overs_features(df)
    
    print("Adding Average Score feature...")
    df = add_average_score_feature(df)
    
    # Save the enhanced dataset
    output_file = "Model/Data/processed/enhanced_ball_by_ball_data.csv"
    print(f"Saving enhanced dataset to {output_file}...")
    df.to_csv(output_file, index=False)
    
    print("\nFeature Engineering Complete!")
    print(f"New features added: Run_In_Last5, Wickets_In_Last5, AverageScore")
    print(f"Total columns: {len(df.columns)}")
    print("\nSample of new features:")
    print(df[['Run_In_Last5', 'Wickets_In_Last5', 'AverageScore']].head())

if __name__ == "__main__":
    main() 