import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from bs4 import BeautifulSoup
import json
import os
import time
import random

BASE_URL = 'https://www.espncricinfo.com/records/year/team-match-results/2020-2020/twenty20-internationals-3'
YEAR = "2020"

def fetch_page_content(url, max_retries=5):
    print(f"Fetching: {url}")
    session = requests.Session()
    retries = Retry(total=max_retries, 
                    backoff_factor=1, 
                    status_forcelist=[500, 502, 503, 504])
    session.mount('https://', HTTPAdapter(max_retries=retries))
    
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
    }
    
    try:
        response = session.get(url, headers=headers, timeout=30)
        response.raise_for_status()
        return response.text
    except requests.exceptions.RequestException as e:
        print(f"Error fetching {url}: {e}")
        return None

def extract_match_links(html_content):
    soup = BeautifulSoup(html_content, 'html.parser')
    links = []
    rows = soup.select('table.ds-table tbody tr')
    for row in rows:
        scorecard_cell = row.select_one('td:last-child')
        if scorecard_cell:
            match_id = scorecard_cell.text.strip()
            if match_id.startswith('T20I #'):
                link = scorecard_cell.find('a')['href']
                full_link = f"https://www.espncricinfo.com{link}"
                links.append((match_id, full_link))
    print(f"Found {len(links)} matches")
    return links

def extract_match_info(soup):
    teams = [team.text.strip() for team in soup.select('.ds-text-tight-l.ds-font-bold')]
    team1, team2 = teams[:2] if len(teams) >= 2 else ("Team 1", "Team 2")
    return f"{team1} Vs {team2}"

def extract_batting_summary(soup, match_info):
    batting_summary = []
    innings_blocks = soup.select('.ds-rounded-lg.ds-mt-2')
    for i, block in enumerate(innings_blocks):
        team = match_info.split(' Vs ')[i]
        rows = block.select('table.ci-scorecard-table tbody tr')
        for pos, row in enumerate(rows, 1):
            cells = row.select('td')
            if len(cells) >= 8:
                batting_summary.append({
                    "match": match_info,
                    "teamInnings": team,
                    "battingPos": str(pos),
                    "batsmanName": cells[0].select_one('a > span > span').text.strip() if cells[0].select_one('a > span > span') else '',
                    "dismissal": cells[1].select_one('span > span').text.strip() if cells[1].select_one('span > span') else '',
                    "runs": cells[2].select_one('strong').text.strip() if cells[2].select_one('strong') else '',
                    "balls": cells[3].text.strip(),
                    "4s": cells[5].text.strip(),
                    "6s": cells[6].text.strip(),
                    "SR": cells[7].text.strip()
                })
    return batting_summary

def extract_bowling_summary(soup, match_info):
    bowling_summary = []
    innings_blocks = soup.select('.ds-rounded-lg.ds-mt-2')
    for i, block in enumerate(innings_blocks):
        bowling_team = match_info.split(' Vs ')[1 - i]
        rows = block.select('table.ds-table:not(.ci-scorecard-table) tbody tr')
        for row in rows:
            cells = row.select('td')
            if len(cells) >= 11:
                bowling_summary.append({
                    "match": match_info,
                    "bowlingTeam": bowling_team,
                    "bowlerName": cells[0].select_one('a > span').text.strip() if cells[0].select_one('a > span') else '',
                    "overs": cells[1].text.strip(),
                    "maiden": cells[2].text.strip(),
                    "runs": cells[3].text.strip(),
                    "wickets": cells[4].text.strip(),
                    "economy": cells[5].text.strip(),
                    "0s": cells[6].text.strip(),
                    "4s": cells[7].text.strip(),
                    "6s": cells[8].text.strip(),
                    "wides": cells[9].text.strip(),
                    "noBalls": cells[10].text.strip()
                })
    return bowling_summary

def save_to_json(data, file_name, summary_type):
    base_folder = f"{YEAR} Match Data"
    summary_folder = os.path.join(base_folder, f"{summary_type} Summary")
    if not os.path.exists(summary_folder):
        os.makedirs(summary_folder)
    file_path = os.path.join(summary_folder, file_name)
    with open(file_path, 'w') as json_file:
        json.dump(data, json_file, indent=4)

def main():
    os.makedirs(f"{YEAR} Match Data/Batting Summary", exist_ok=True)
    os.makedirs(f"{YEAR} Match Data/Bowling Summary", exist_ok=True)

    html_content = fetch_page_content(BASE_URL)
    if not html_content:
        print("Failed to fetch the main page. Exiting.")
        return

    match_links = extract_match_links(html_content)

    for i, (match_id, match_url) in enumerate(match_links, 1):
        print(f"Processing match {i}/{len(match_links)}: {match_id}")
        retries = 3
        while retries > 0:
            match_html = fetch_page_content(match_url)
            if match_html:
                break
            retries -= 1
            print(f"Retrying... ({retries} attempts left)")
            time.sleep(random.uniform(20, 30))  # Longer delay between retries
        
        if not match_html:
            print(f"Failed to fetch match data for {match_id} after multiple attempts. Skipping.")
            continue

        try:
            soup = BeautifulSoup(match_html, 'html.parser')
            match_info = extract_match_info(soup)

            batting_summary = extract_batting_summary(soup, match_info)
            bowling_summary = extract_bowling_summary(soup, match_info)

            batting_file_name = f"{match_id}_{match_info.replace(' ', '_')}_batting_summary.json"
            bowling_file_name = f"{match_id}_{match_info.replace(' ', '_')}_bowling_summary.json"

            save_to_json(batting_summary, batting_file_name, "Batting")
            save_to_json(bowling_summary, bowling_file_name, "Bowling")

            print(f"Saved data for {match_id}")

        except Exception as e:
            print(f"Error processing match {match_id}: {e}")

        # Random delay between successful requests
        time.sleep(random.uniform(10, 15))

    print(f"Process completed for {YEAR} T20I matches.")

if __name__ == "__main__":
    main()