import pandas as pd
import numpy as np
from pathlib import Path
from datetime import datetime

def get_latest_csv_files():
    """Get the latest processed CSV files."""
    processed_dir = Path('Model/Data/processed')
    ball_files = list(processed_dir.glob('ball_by_ball_data_*.csv'))
    match_files = list(processed_dir.glob('match_summary_data_*.csv'))
    
    if not ball_files or not match_files:
        raise FileNotFoundError("No processed CSV files found")
    
    # Get the latest files based on timestamp in filename
    latest_ball = max(ball_files, key=lambda x: x.stem.split('_')[-1])
    latest_match = max(match_files, key=lambda x: x.stem.split('_')[-1])
    
    return latest_ball, latest_match

def analyze_data():
    # Get the latest CSV files
    ball_file, match_file = get_latest_csv_files()
    
    # Read the processed data
    ball_df = pd.read_csv(ball_file)
    match_df = pd.read_csv(match_file)
    
    print("\n=== Data Analysis Report ===\n")
    
    # 1. Basic Information
    print("1. Basic Information:")
    print(f"Number of matches: {len(match_df)}")
    print(f"Number of ball-by-ball records: {len(ball_df)}")
    print(f"Date range: {ball_df['date'].min()} to {ball_df['date'].max()}")
    print(f"Number of unique venues: {ball_df['venue'].nunique()}")
    print(f"Number of unique teams: {len(set(ball_df['team1'].unique()) | set(ball_df['team2'].unique()))}")
    
    # 2. Data Quality
    print("\n2. Data Quality:")
    print("\nMissing values in ball-by-ball data:")
    print(ball_df.isnull().sum())
    print("\nMissing values in match summary data:")
    print(match_df.isnull().sum())
    
    # 3. Match Statistics
    print("\n3. Match Statistics:")
    print("\nAverage runs per match:")
    print(match_df['runs'].describe())
    print("\nAverage wickets per match:")
    print(match_df['wickets'].describe())
    
    # 4. Phase-wise Analysis
    print("\n4. Phase-wise Analysis:")
    phase_stats = ball_df.groupby('match_phase').agg({
        'runs': ['mean', 'sum'],
        'wickets': 'sum',
        'fours': 'sum',
        'sixes': 'sum'
    }).round(2)
    print(phase_stats)
    
    # 5. Team Performance
    print("\n5. Team Performance:")
    team_stats = pd.concat([
        ball_df.groupby('team1')['runs'].sum().reset_index().rename(columns={'team1': 'team'}),
        ball_df.groupby('team2')['runs'].sum().reset_index().rename(columns={'team2': 'team'})
    ]).groupby('team')['runs'].sum().sort_values(ascending=False)
    print(team_stats)
    
    # 6. Venue Analysis
    print("\n6. Venue Analysis:")
    venue_stats = ball_df.groupby('venue').agg({
        'runs': ['mean', 'sum'],
        'wickets': 'sum',
        'fours': 'sum',
        'sixes': 'sum'
    }).round(2)
    print(venue_stats)
    
    # 7. Wickets Analysis
    print("\n7. Wickets Analysis:")
    print("\nWickets by match phase:")
    wickets_by_phase = ball_df.groupby('match_phase')['wickets'].sum()
    print(wickets_by_phase)
    
    print("\nWickets by venue:")
    wickets_by_venue = ball_df.groupby('venue')['wickets'].sum()
    print(wickets_by_venue)

if __name__ == "__main__":
    analyze_data() 