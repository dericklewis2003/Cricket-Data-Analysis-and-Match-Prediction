import json
import pandas as pd
import numpy as np
from pathlib import Path
import logging
from datetime import datetime
from typing import Dict, List, Optional, Tuple

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class CricketDataPreprocessor:
    def __init__(self, input_dir: str, output_dir: str):
        """
        Initialize the preprocessor with input and output directories.
        
        Args:
            input_dir (str): Path to directory containing JSON files
            output_dir (str): Path to directory for saving processed data
        """
        self.input_dir = Path(input_dir)
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
    def determine_match_phase(self, over: int) -> str:
        """Determine the match phase based on the over number."""
        if over <= 6:
            return 'Powerplay'
        elif over <= 15:
            return 'Middle Overs'
        else:
            return 'Death Overs'
    
    def extract_match_metadata(self, match_data: Dict, file_path: Path) -> Dict:
        """Extract match-level metadata from the JSON data."""
        try:
            info = match_data.get('info', {})
            
            # Extract result information
            outcome = info.get('outcome', {})
            winner = outcome.get('winner', '')
            by_runs = outcome.get('by', {}).get('runs', '')
            by_wickets = outcome.get('by', {}).get('wickets', '')
            
            # Format result string
            if winner:
                if by_runs:
                    result = f"{winner} by {by_runs} runs"
                elif by_wickets:
                    result = f"{winner} by {by_wickets} wickets"
                else:
                    result = winner
            else:
                result = "No result"
            
            metadata = {
                'match_id': file_path.stem,
                'date': info.get('dates', [''])[0] if info.get('dates') else '',
                'venue': info.get('venue', ''),
                'series': info.get('event', {}).get('name', 'Unknown Series'),
                'toss_winner': info.get('toss', {}).get('winner', ''),
                'toss_decision': info.get('toss', {}).get('decision', ''),
                'result': result,
                'match_format': info.get('match_type', 'T20I'),
                'team1': info.get('teams', [''])[0] if info.get('teams') else '',
                'team2': info.get('teams', ['', ''])[1] if len(info.get('teams', [])) > 1 else ''
            }
            return metadata
        except Exception as e:
            logger.error(f"Error extracting match metadata: {str(e)}")
            return {}
    
    def process_ball_by_ball_data(self, match_data: Dict, metadata: Dict) -> List[Dict]:
        """Process ball-by-ball data for each innings."""
        ball_data = []
        
        try:
            for innings in match_data.get('innings', []):
                batting_team = innings.get('team', '')
                bowling_team = metadata['team2'] if batting_team == metadata['team1'] else metadata['team1']
                
                # Initialize cumulative metrics
                cumulative_runs = 0
                cumulative_overs = 0
                cumulative_wickets = 0
                
                for over in innings.get('overs', []):
                    over_number = over.get('over', 0)
                    
                    for delivery in over.get('deliveries', []):
                        # Update cumulative metrics
                        runs = delivery.get('runs', {}).get('total', 0)
                        extras = delivery.get('runs', {}).get('extras', 0)
                        cumulative_runs += runs
                        cumulative_overs += 0.1
                        
                        # Check for wickets - improved detection
                        wickets = delivery.get('wickets', [])
                        if wickets:  # If there are any wickets in this delivery
                            cumulative_wickets += len(wickets)  # Add the number of wickets
                        
                        # Calculate current run rate and projected score
                        current_run_rate = round(cumulative_runs / cumulative_overs, 2) if cumulative_overs > 0 else 0
                        remaining_overs = 20 - cumulative_overs
                        projected_score = round(current_run_rate * remaining_overs + cumulative_runs, 0)
                        
                        # Create ball-level record
                        ball_record = {
                            **metadata,  # Include match metadata
                            'innings_number': 1 if batting_team == metadata['team1'] else 2,
                            'batting_team': batting_team,
                            'bowling_team': bowling_team,
                            'over': over_number,
                            'ball': len(ball_data) % 6 + 1,
                            'runs': runs,
                            'wickets': cumulative_wickets,  # Use cumulative wickets for this innings
                            'extras': extras,
                            'fours': 1 if runs == 4 else 0,
                            'sixes': 1 if runs == 6 else 0,
                            'current_run_rate': current_run_rate,
                            'projected_score': projected_score,
                            'match_phase': self.determine_match_phase(over_number),
                            'batter': delivery.get('batter', ''),
                            'bowler': delivery.get('bowler', '')
                        }
                        
                        ball_data.append(ball_record)
                
        except Exception as e:
            logger.error(f"Error processing ball-by-ball data: {str(e)}")
        
        return ball_data
    
    def process_match_file(self, file_path: Path) -> Optional[pd.DataFrame]:
        """Process a single match JSON file."""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                match_data = json.load(f)
            
            # Extract metadata and ball-by-ball data
            metadata = self.extract_match_metadata(match_data, file_path)
            ball_data = self.process_ball_by_ball_data(match_data, metadata)
            
            if not ball_data:
                logger.warning(f"No ball-by-ball data found in {file_path}")
                return None
            
            return pd.DataFrame(ball_data)
            
        except Exception as e:
            logger.error(f"Error processing file {file_path}: {str(e)}")
            return None
    
    def process_files(self) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        Process all JSON files in the input directory.
        
        Returns:
            Tuple[pd.DataFrame, pd.DataFrame]: Ball-by-ball data and match-level data
        """
        json_files = list(self.input_dir.glob('*.json'))
        
        logger.info(f"Processing {len(json_files)} files...")
        
        # Process each file and combine results
        all_ball_data = []
        all_match_data = []
        
        for file_path in json_files:
            logger.info(f"Processing {file_path.name}")
            df = self.process_match_file(file_path)
            
            if df is not None:
                all_ball_data.append(df)
                
                # Create match-level summary
                match_summary = df.groupby('match_id').agg({
                    'runs': 'sum',
                    'wickets': 'max',  # Use max for final wicket count
                    'current_run_rate': 'mean',
                    'fours': 'sum',
                    'sixes': 'sum',
                    'extras': 'sum'
                }).reset_index()
                
                # Add match metadata
                match_metadata = df[['match_id', 'date', 'venue', 'team1', 'team2', 
                                   'toss_winner', 'toss_decision', 'result', 'series']].drop_duplicates()
                match_summary = match_summary.merge(match_metadata, on='match_id')
                
                all_match_data.append(match_summary)
        
        # Combine all data
        ball_df = pd.concat(all_ball_data, ignore_index=True) if all_ball_data else pd.DataFrame()
        match_df = pd.concat(all_match_data, ignore_index=True) if all_match_data else pd.DataFrame()
        
        # Fill missing values
        ball_df['series'] = ball_df['series'].fillna('Unknown Series')
        ball_df['result'] = ball_df['result'].fillna('No result')
        match_df['series'] = match_df['series'].fillna('Unknown Series')
        match_df['result'] = match_df['result'].fillna('No result')
        
        return ball_df, match_df
    
    def save_data(self, ball_df: pd.DataFrame, match_df: pd.DataFrame):
        """Save processed data to CSV files."""
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        
        # Save ball-by-ball data
        ball_file = self.output_dir / f'ball_by_ball_data_{timestamp}.csv'
        ball_df.to_csv(ball_file, index=False)
        logger.info(f"Saved ball-by-ball data to {ball_file}")
        
        # Save match-level data
        match_file = self.output_dir / f'match_summary_data_{timestamp}.csv'
        match_df.to_csv(match_file, index=False)
        logger.info(f"Saved match summary data to {match_file}")

def main():
    # Define paths
    input_dir = "Model/Data/t20_i"
    output_dir = "Model/Data/processed"
    
    # Initialize preprocessor
    preprocessor = CricketDataPreprocessor(input_dir, output_dir)
    
    # Process all files
    ball_df, match_df = preprocessor.process_files()
    
    # Save processed data
    preprocessor.save_data(ball_df, match_df)
    
    # Print summary statistics
    logger.info(f"\nProcessing Summary:")
    logger.info(f"Total matches processed: {len(match_df)}")
    logger.info(f"Total balls processed: {len(ball_df)}")
    if not ball_df.empty:
        logger.info(f"Date range: {ball_df['date'].min()} to {ball_df['date'].max()}")
        logger.info(f"Unique match IDs: {ball_df['match_id'].nunique()}")
        logger.info(f"Number of unique teams: {len(set(ball_df['team1'].unique()) | set(ball_df['team2'].unique()))}")
        logger.info(f"Number of unique venues: {ball_df['venue'].nunique()}")
        logger.info(f"Number of unique series: {ball_df['series'].nunique()}")

if __name__ == "__main__":
    main() 