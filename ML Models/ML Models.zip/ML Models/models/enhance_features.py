import pandas as pd
import numpy as np
from datetime import datetime
import os

def add_new_features(df):
    """Add new features to the dataset"""
    print("Adding new features...")
    enhanced_df = df.copy()
    
    # Calculate cumulative runs first
    print("Calculating cumulative runs...")
    enhanced_df['cumulative_runs'] = enhanced_df.groupby(['match_id', 'innings_number'])['runs'].transform('cumsum')
    
    # 1. chasing_or_setting
    print("Adding chasing_or_setting...")
    enhanced_df['chasing_or_setting'] = (enhanced_df['innings_number'] == 2).astype(int)
    
    # 2. target_score
    print("Adding target_score...")
    # For first innings, use projected_score
    enhanced_df.loc[enhanced_df['innings_number'] == 1, 'target_score'] = enhanced_df['projected_score']
    
    # For second innings, calculate first innings total for each match
    first_innings_totals = enhanced_df[enhanced_df['innings_number'] == 1].groupby('match_id')['runs'].sum()
    match_targets = pd.DataFrame({'match_id': first_innings_totals.index, 'first_innings_total': first_innings_totals.values})
    enhanced_df = enhanced_df.merge(match_targets, on='match_id', how='left')
    enhanced_df.loc[enhanced_df['innings_number'] == 2, 'target_score'] = enhanced_df['first_innings_total']
    enhanced_df = enhanced_df.drop('first_innings_total', axis=1)
    
    # Handle missing target scores
    print("Handling missing target scores...")
    enhanced_df['target_score'] = enhanced_df.groupby('match_id')['target_score'].transform(
        lambda x: x.fillna(x.mean() if not pd.isna(x.mean()) else 150)  # Use 150 as fallback
    )
    
    # 3. required_run_rate
    print("Adding required_run_rate...")
    # Calculate remaining runs and overs for second innings only
    enhanced_df['remaining_runs'] = np.where(
        enhanced_df['innings_number'] == 2,
        enhanced_df['target_score'] - enhanced_df['cumulative_runs'],
        0
    )
    
    # Calculate remaining overs (including partial overs)
    enhanced_df['remaining_overs'] = np.where(
        enhanced_df['innings_number'] == 2,
        20 - enhanced_df['over'] - (enhanced_df['ball'] / 6),
        0
    )
    
    # Calculate required run rate with proper handling of edge cases
    enhanced_df['required_run_rate'] = np.where(
        (enhanced_df['innings_number'] == 2) & (enhanced_df['remaining_overs'] > 0),
        np.clip(enhanced_df['remaining_runs'] / enhanced_df['remaining_overs'], 0, 36),  # Cap at 36 runs per over
        0
    )
    
    # Set required run rate to 0 when target is already achieved
    enhanced_df.loc[enhanced_df['cumulative_runs'] >= enhanced_df['target_score'], 'required_run_rate'] = 0
    
    # 4. partnership_runs
    print("Adding partnership_runs...")
    # Reset partnership runs when wicket falls
    enhanced_df['wicket_fell'] = enhanced_df['wickets'] > 0
    enhanced_df['partnership_id'] = enhanced_df.groupby(['match_id', 'innings_number'])['wicket_fell'].cumsum()
    enhanced_df['partnership_runs'] = enhanced_df.groupby(['match_id', 'innings_number', 'partnership_id'])['runs'].transform('sum')
    
    # 5. last_wicket_fall
    print("Adding last_wicket_fall...")
    # Calculate over number when wicket falls
    enhanced_df['wicket_over'] = np.where(enhanced_df['wickets'] > 0, enhanced_df['over'], np.nan)
    enhanced_df['last_wicket_fall'] = enhanced_df.groupby(['match_id', 'innings_number'])['wicket_over'].transform(lambda x: x.fillna(method='ffill'))
    enhanced_df['last_wicket_fall'] = enhanced_df['last_wicket_fall'].fillna(0)
    
    # Clean up intermediate columns
    enhanced_df = enhanced_df.drop(['wicket_fell', 'partnership_id', 'wicket_over', 'remaining_runs', 'remaining_overs'], axis=1)
    
    # Final validation
    print("\nPerforming final validation...")
    print(f"Missing values in target_score: {enhanced_df['target_score'].isnull().sum()}")
    print(f"Missing values in required_run_rate: {enhanced_df['required_run_rate'].isnull().sum()}")
    print(f"Required run rate range: {enhanced_df['required_run_rate'].min():.2f} to {enhanced_df['required_run_rate'].max():.2f}")
    
    # Save enhanced dataset
    output_dir = "Model/Data/processed"
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_file = os.path.join(output_dir, f"enhanced_t20i_ball_by_ball_features_{timestamp}.csv")
    
    enhanced_df.to_csv(output_file, index=False)
    print(f"\nEnhanced dataset saved to: {output_file}")
    
    # Save feature summary
    summary_file = os.path.join(output_dir, f"feature_summary_{timestamp}.txt")
    with open(summary_file, 'w') as f:
        f.write("=== New Features Summary ===\n\n")
        f.write("1. chasing_or_setting:\n")
        f.write(f"Unique values: {enhanced_df['chasing_or_setting'].nunique()}\n")
        f.write(f"Value counts:\n{enhanced_df['chasing_or_setting'].value_counts()}\n\n")
        
        f.write("2. target_score:\n")
        f.write(f"Min: {enhanced_df['target_score'].min()}\n")
        f.write(f"Max: {enhanced_df['target_score'].max()}\n")
        f.write(f"Mean: {enhanced_df['target_score'].mean():.2f}\n\n")
        
        f.write("3. required_run_rate:\n")
        f.write(f"Min: {enhanced_df['required_run_rate'].min()}\n")
        f.write(f"Max: {enhanced_df['required_run_rate'].max()}\n")
        f.write(f"Mean: {enhanced_df['required_run_rate'].mean():.2f}\n\n")
        
        f.write("4. partnership_runs:\n")
        f.write(f"Min: {enhanced_df['partnership_runs'].min()}\n")
        f.write(f"Max: {enhanced_df['partnership_runs'].max()}\n")
        f.write(f"Mean: {enhanced_df['partnership_runs'].mean():.2f}\n\n")
        
        f.write("5. last_wicket_fall:\n")
        f.write(f"Min: {enhanced_df['last_wicket_fall'].min()}\n")
        f.write(f"Max: {enhanced_df['last_wicket_fall'].max()}\n")
        f.write(f"Mean: {enhanced_df['last_wicket_fall'].mean():.2f}\n")
    
    print(f"Feature summary saved to: {summary_file}")
    
    return enhanced_df

def main():
    # Load the cleaned dataset
    print("Loading cleaned dataset...")
    df = pd.read_csv("Model/Data/processed/cleaned_t20i_ball_by_ball_features_20250319_172744.csv")
    
    # Add new features
    enhanced_df = add_new_features(df)
    
    print("\nFeature enhancement completed successfully!")

if __name__ == "__main__":
    main() 