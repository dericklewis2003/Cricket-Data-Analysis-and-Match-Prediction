import pandas as pd
import numpy as np
import os
from datetime import datetime

def clean_dataset(df):
    """Clean the dataset by capping outliers"""
    print("Starting data cleaning process...")
    
    # Create a copy of the dataframe
    cleaned_df = df.copy()
    
    # Store original statistics
    original_stats = {
        'runs': {
            'min': df['runs'].min(),
            'max': df['runs'].max(),
            'mean': df['runs'].mean(),
            'std': df['runs'].std()
        },
        'current_run_rate': {
            'min': df['current_run_rate'].min(),
            'max': df['current_run_rate'].max(),
            'mean': df['current_run_rate'].mean(),
            'std': df['current_run_rate'].std()
        },
        'projected_score': {
            'min': df['projected_score'].min(),
            'max': df['projected_score'].max(),
            'mean': df['projected_score'].mean(),
            'std': df['projected_score'].std()
        }
    }
    
    # Cap outliers
    print("\nCapping outliers...")
    
    # Cap runs at 6
    runs_capped = cleaned_df['runs'] > 6
    cleaned_df.loc[runs_capped, 'runs'] = 6
    print(f"Runs capped: {runs_capped.sum()} values")
    
    # Cap current_run_rate at 30
    rate_capped = cleaned_df['current_run_rate'] > 30
    cleaned_df.loc[rate_capped, 'current_run_rate'] = 30
    print(f"Current run rate capped: {rate_capped.sum()} values")
    
    # Cap projected_score at 400
    score_capped = cleaned_df['projected_score'] > 400
    cleaned_df.loc[score_capped, 'projected_score'] = 400
    print(f"Projected score capped: {score_capped.sum()} values")
    
    # Calculate new statistics
    new_stats = {
        'runs': {
            'min': cleaned_df['runs'].min(),
            'max': cleaned_df['runs'].max(),
            'mean': cleaned_df['runs'].mean(),
            'std': cleaned_df['runs'].std()
        },
        'current_run_rate': {
            'min': cleaned_df['current_run_rate'].min(),
            'max': cleaned_df['current_run_rate'].max(),
            'mean': cleaned_df['current_run_rate'].mean(),
            'std': cleaned_df['current_run_rate'].std()
        },
        'projected_score': {
            'min': cleaned_df['projected_score'].min(),
            'max': cleaned_df['projected_score'].max(),
            'mean': cleaned_df['projected_score'].mean(),
            'std': cleaned_df['projected_score'].std()
        }
    }
    
    # Save cleaned dataset
    output_dir = "Model/Data/processed"
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_file = os.path.join(output_dir, f"cleaned_t20i_ball_by_ball_features_{timestamp}.csv")
    
    cleaned_df.to_csv(output_file, index=False)
    print(f"\nCleaned dataset saved to: {output_file}")
    
    # Save cleaning report
    report_file = os.path.join(output_dir, f"cleaning_report_{timestamp}.txt")
    with open(report_file, 'w') as f:
        f.write("=== Data Cleaning Report ===\n\n")
        f.write("1. Original Statistics:\n")
        for col, stats in original_stats.items():
            f.write(f"\n{col}:\n")
            f.write(f"Min: {stats['min']:.2f}\n")
            f.write(f"Max: {stats['max']:.2f}\n")
            f.write(f"Mean: {stats['mean']:.2f}\n")
            f.write(f"Std: {stats['std']:.2f}\n")
        
        f.write("\n2. New Statistics:\n")
        for col, stats in new_stats.items():
            f.write(f"\n{col}:\n")
            f.write(f"Min: {stats['min']:.2f}\n")
            f.write(f"Max: {stats['max']:.2f}\n")
            f.write(f"Mean: {stats['mean']:.2f}\n")
            f.write(f"Std: {stats['std']:.2f}\n")
    
    print(f"Cleaning report saved to: {report_file}")
    
    return cleaned_df

def main():
    # Load the dataset
    print("Loading dataset...")
    df = pd.read_csv("Model/Data/processed/t20i_ball_by_ball_features_2005_2025.csv")
    
    # Clean the dataset
    cleaned_df = clean_dataset(df)
    
    print("\nData cleaning completed successfully!")

if __name__ == "__main__":
    main() 