import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime
import os

def analyze_data_quality(df):
    """Analyze data quality and generate report"""
    print("\n=== Data Quality Analysis Report ===\n")
    
    # Basic Information
    print("1. Basic Information:")
    print(f"Total records: {len(df)}")
    print(f"Total columns: {len(df.columns)}")
    print("\nColumns and their data types:")
    print(df.dtypes)
    
    # Missing Values
    print("\n2. Missing Values Analysis:")
    missing_values = df.isnull().sum()
    missing_percentages = (missing_values / len(df)) * 100
    missing_df = pd.DataFrame({
        'Missing Count': missing_values,
        'Missing Percentage': missing_percentages
    })
    print(missing_df[missing_df['Missing Count'] > 0])
    
    # Data Types and Conversions
    print("\n3. Data Type Analysis:")
    numeric_columns = df.select_dtypes(include=[np.number]).columns
    categorical_columns = df.select_dtypes(include=['object']).columns
    
    print("\nNumeric Columns:")
    for col in numeric_columns:
        print(f"\n{col}:")
        print(f"Min: {df[col].min()}")
        print(f"Max: {df[col].max()}")
        print(f"Mean: {df[col].mean():.2f}")
        print(f"Standard Deviation: {df[col].std():.2f}")
    
    print("\nCategorical Columns:")
    for col in categorical_columns:
        print(f"\n{col}:")
        print(f"Unique values: {df[col].nunique()}")
        print("Top 5 values:")
        print(df[col].value_counts().head())
    
    # Outlier Analysis
    print("\n4. Outlier Analysis (for numeric columns):")
    for col in numeric_columns:
        Q1 = df[col].quantile(0.25)
        Q3 = df[col].quantile(0.75)
        IQR = Q3 - Q1
        lower_bound = Q1 - 1.5 * IQR
        upper_bound = Q3 + 1.5 * IQR
        outliers = df[(df[col] < lower_bound) | (df[col] > upper_bound)][col]
        
        if len(outliers) > 0:
            print(f"\n{col}:")
            print(f"Number of outliers: {len(outliers)}")
            print(f"Outlier percentage: {(len(outliers)/len(df))*100:.2f}%")
            print(f"Lower bound: {lower_bound:.2f}")
            print(f"Upper bound: {upper_bound:.2f}")
    
    # Date Range Analysis
    if 'date' in df.columns:
        print("\n5. Date Range Analysis:")
        df['date'] = pd.to_datetime(df['date'])
        print(f"Date range: {df['date'].min()} to {df['date'].max()}")
        print(f"Number of unique dates: {df['date'].nunique()}")
    
    # Save plots
    save_dir = "Model/models/data_validation_results"
    if not os.path.exists(save_dir):
        os.makedirs(save_dir)
    
    # Plot numeric distributions
    plt.figure(figsize=(15, 10))
    for i, col in enumerate(numeric_columns, 1):
        plt.subplot(3, 3, i)
        sns.histplot(data=df, x=col, bins=50)
        plt.title(f'Distribution of {col}')
    plt.tight_layout()
    plt.savefig(os.path.join(save_dir, 'numeric_distributions.png'))
    plt.close()
    
    # Save report to file
    with open(os.path.join(save_dir, 'data_validation_report.txt'), 'w') as f:
        f.write("=== Data Quality Analysis Report ===\n\n")
        f.write("1. Basic Information:\n")
        f.write(f"Total records: {len(df)}\n")
        f.write(f"Total columns: {len(df.columns)}\n")
        f.write("\nColumns and their data types:\n")
        f.write(str(df.dtypes))
        
        f.write("\n\n2. Missing Values Analysis:\n")
        f.write(str(missing_df[missing_df['Missing Count'] > 0]))
        
        f.write("\n\n3. Data Type Analysis:\n")
        for col in numeric_columns:
            f.write(f"\n{col}:\n")
            f.write(f"Min: {df[col].min()}\n")
            f.write(f"Max: {df[col].max()}\n")
            f.write(f"Mean: {df[col].mean():.2f}\n")
            f.write(f"Standard Deviation: {df[col].std():.2f}\n")
    
    print(f"\nDetailed report and plots saved to: {save_dir}")

def main():
    # Load the dataset
    print("Loading dataset...")
    df = pd.read_csv("Model/Data/processed/t20i_ball_by_ball_features_2005_2025.csv")
    
    # Analyze data quality
    analyze_data_quality(df)

if __name__ == "__main__":
    main() 