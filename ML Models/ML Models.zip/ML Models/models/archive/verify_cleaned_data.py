import pandas as pd

def verify_cleaned_data():
    print("Loading cleaned dataset...")
    df = pd.read_csv("Model/Data/processed/cleaned_t20i_ball_by_ball_features_20250319_172744.csv")
    
    print("\n=== Verifying Cleaned Dataset ===\n")
    
    # Check runs
    print("1. Runs:")
    print(f"Max value: {df['runs'].max()}")
    print(f"Values above 6: {len(df[df['runs'] > 6])}")
    
    # Check current_run_rate
    print("\n2. Current Run Rate:")
    print(f"Max value: {df['current_run_rate'].max()}")
    print(f"Values above 30: {len(df[df['current_run_rate'] > 30])}")
    
    # Check projected_score
    print("\n3. Projected Score:")
    print(f"Max value: {df['projected_score'].max()}")
    print(f"Values above 400: {len(df[df['projected_score'] > 400])}")
    
    print("\nTotal records:", len(df))

if __name__ == "__main__":
    verify_cleaned_data() 