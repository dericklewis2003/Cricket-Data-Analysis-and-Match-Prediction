import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime
import os

def validate_dataset(df):
    """Validate the enhanced dataset"""
    print("=== Dataset Validation Report ===\n")
    
    # 1. Basic Information
    print("1. Basic Information:")
    print(f"Number of records: {len(df):,}")
    print(f"Number of features: {len(df.columns)}")
    print("\nFeature list:")
    for col in df.columns:
        print(f"- {col} ({df[col].dtype})")
    
    # 2. Missing Values
    print("\n2. Missing Values Check:")
    missing = df.isnull().sum()
    if missing.any():
        print("\nFeatures with missing values:")
        for col in missing[missing > 0].index:
            print(f"{col}: {missing[col]:,} missing values ({(missing[col]/len(df)*100):.2f}%)")
            print(f"Sample rows with missing values:")
            print(df[df[col].isnull()].head()[['match_id', 'innings_number', col]])
    else:
        print("No missing values found in any feature.")
    
    # 3. New Features Validation
    print("\n3. New Features Validation:")
    
    # chasing_or_setting
    print("\nchasing_or_setting:")
    print(df['chasing_or_setting'].value_counts(normalize=True).round(3))
    print("\nDistribution by innings:")
    print(pd.crosstab(df['innings_number'], df['chasing_or_setting']))
    
    # target_score
    print("\ntarget_score:")
    print(f"Range: {df['target_score'].min():.0f} to {df['target_score'].max():.0f}")
    print(f"Mean: {df['target_score'].mean():.2f}")
    print("\nSummary by innings:")
    print(df.groupby('innings_number')['target_score'].describe())
    
    # required_run_rate
    print("\nrequired_run_rate:")
    print(f"Range: {df['required_run_rate'].min():.2f} to {df['required_run_rate'].max():.2f}")
    print(f"Mean: {df['required_run_rate'].mean():.2f}")
    print("\nSummary by innings:")
    print(df.groupby('innings_number')['required_run_rate'].describe())
    
    # partnership_runs
    print("\npartnership_runs:")
    print(f"Range: {df['partnership_runs'].min():.0f} to {df['partnership_runs'].max():.0f}")
    print(f"Mean: {df['partnership_runs'].mean():.2f}")
    
    # last_wicket_fall
    print("\nlast_wicket_fall:")
    print(f"Range: {df['last_wicket_fall'].min():.1f} to {df['last_wicket_fall'].max():.1f}")
    print(f"Mean: {df['last_wicket_fall'].mean():.2f}")
    
    # 4. Data Quality Checks
    print("\n4. Data Quality Checks:")
    
    # Check if chasing_or_setting matches innings_number
    chasing_check = (df['chasing_or_setting'] == (df['innings_number'] == 2)).all()
    print(f"\nchasing_or_setting consistency: {'PASS' if chasing_check else 'FAIL'}")
    if not chasing_check:
        mismatches = df[df['chasing_or_setting'] != (df['innings_number'] == 2)]
        print(f"Found {len(mismatches)} mismatches. Sample:")
        print(mismatches[['match_id', 'innings_number', 'chasing_or_setting']].head())
    
    # Check if target_score is reasonable
    target_check = df['target_score'].between(0, 400).all()
    print(f"target_score range check: {'PASS' if target_check else 'FAIL'}")
    if not target_check:
        invalid_targets = df[~df['target_score'].between(0, 400)]
        print(f"Found {len(invalid_targets)} invalid target scores. Sample:")
        print(invalid_targets[['match_id', 'innings_number', 'target_score']].head())
    
    # Check if required_run_rate is reasonable
    rrr_check = df['required_run_rate'].between(0, 36).all()
    print(f"required_run_rate range check: {'PASS' if rrr_check else 'FAIL'}")
    if not rrr_check:
        invalid_rrr = df[~df['required_run_rate'].between(0, 36)]
        print(f"Found {len(invalid_rrr)} invalid required run rates. Sample:")
        print(invalid_rrr[['match_id', 'innings_number', 'required_run_rate']].head())
    
    # Check if partnership_runs is non-negative
    partnership_check = (df['partnership_runs'] >= 0).all()
    print(f"partnership_runs non-negative check: {'PASS' if partnership_check else 'FAIL'}")
    if not partnership_check:
        invalid_partnerships = df[df['partnership_runs'] < 0]
        print(f"Found {len(invalid_partnerships)} negative partnership runs. Sample:")
        print(invalid_partnerships[['match_id', 'innings_number', 'partnership_runs']].head())
    
    # Check if last_wicket_fall is within match
    wicket_check = df['last_wicket_fall'].between(0, 20).all()
    print(f"last_wicket_fall range check: {'PASS' if wicket_check else 'FAIL'}")
    if not wicket_check:
        invalid_wickets = df[~df['last_wicket_fall'].between(0, 20)]
        print(f"Found {len(invalid_wickets)} invalid last wicket fall overs. Sample:")
        print(invalid_wickets[['match_id', 'innings_number', 'last_wicket_fall']].head())
    
    # Save validation report
    output_dir = "Model/Data/processed"
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    report_file = os.path.join(output_dir, f"validation_report_{timestamp}.txt")
    
    with open(report_file, 'w') as f:
        f.write("=== Enhanced Dataset Validation Report ===\n\n")
        f.write(f"Dataset Size: {len(df):,} records, {len(df.columns)} features\n\n")
        
        f.write("Feature Statistics:\n")
        for col in ['chasing_or_setting', 'target_score', 'required_run_rate', 'partnership_runs', 'last_wicket_fall']:
            f.write(f"\n{col}:\n")
            f.write(f"Min: {df[col].min():.2f}\n")
            f.write(f"Max: {df[col].max():.2f}\n")
            f.write(f"Mean: {df[col].mean():.2f}\n")
            f.write(f"Std: {df[col].std():.2f}\n")
            f.write(f"Missing values: {df[col].isnull().sum():,}\n")
        
        f.write("\nData Quality Checks:\n")
        f.write(f"Missing Values: {'None' if not missing.any() else 'Present'}\n")
        f.write(f"chasing_or_setting consistency: {'PASS' if chasing_check else 'FAIL'}\n")
        f.write(f"target_score range check: {'PASS' if target_check else 'FAIL'}\n")
        f.write(f"required_run_rate range check: {'PASS' if rrr_check else 'FAIL'}\n")
        f.write(f"partnership_runs non-negative check: {'PASS' if partnership_check else 'FAIL'}\n")
        f.write(f"last_wicket_fall range check: {'PASS' if wicket_check else 'FAIL'}\n")
    
    print(f"\nDetailed validation report saved to: {report_file}")
    return True

def main():
    # Load the enhanced dataset
    print("Loading enhanced dataset...")
    df = pd.read_csv("Model/Data/processed/enhanced_t20i_ball_by_ball_features_20250319_174607.csv")
    
    # Validate the dataset
    validation_result = validate_dataset(df)
    
    if validation_result:
        print("\nValidation completed successfully! The dataset is ready for modeling.")
    else:
        print("\nValidation revealed issues that need to be addressed.")

if __name__ == "__main__":
    main() 