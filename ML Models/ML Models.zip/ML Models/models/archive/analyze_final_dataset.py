import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime
import os

def analyze_dataset(df):
    """Generate comprehensive analysis of the final dataset"""
    print("=== Final Dataset Analysis Report ===\n")
    
    # Create output directory if it doesn't exist
    output_dir = "Model/Data/final"
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    report_file = os.path.join(output_dir, f"final_dataset_analysis_{timestamp}.txt")
    
    with open(report_file, 'w') as f:
        # 1. Basic Information
        f.write("1. Basic Information\n")
        f.write("===================\n")
        f.write(f"Total records: {len(df):,}\n")
        f.write(f"Total features: {len(df.columns)}\n")
        f.write(f"Memory usage: {df.memory_usage(deep=True).sum() / 1024**2:.2f} MB\n\n")
        
        # 2. Feature Categories
        f.write("2. Feature Categories\n")
        f.write("====================\n")
        
        # Match Information
        match_features = ['match_id', 'date', 'venue', 'series', 'toss_winner', 'toss_decision', 'result', 'match_format', 'team1', 'team2']
        f.write("\nMatch Information:\n")
        for feature in match_features:
            f.write(f"- {feature}: {df[feature].dtype}\n")
        
        # Ball-by-Ball Information
        ball_features = ['innings_number', 'batting_team', 'bowling_team', 'over', 'ball', 'runs', 'wickets', 'extras', 'fours', 'sixes']
        f.write("\nBall-by-Ball Information:\n")
        for feature in ball_features:
            f.write(f"- {feature}: {df[feature].dtype}\n")
        
        # Player Information
        player_features = ['batter', 'bowler']
        f.write("\nPlayer Information:\n")
        for feature in player_features:
            f.write(f"- {feature}: {df[feature].dtype}\n")
        
        # Match Phase and Rate Information
        phase_features = ['match_phase', 'current_run_rate', 'projected_score']
        f.write("\nMatch Phase and Rate Information:\n")
        for feature in phase_features:
            f.write(f"- {feature}: {df[feature].dtype}\n")
        
        # Recent Performance Features
        recent_features = ['Run_In_Last5', 'Wickets_In_Last5', 'AverageScore']
        f.write("\nRecent Performance Features:\n")
        for feature in recent_features:
            f.write(f"- {feature}: {df[feature].dtype}\n")
        
        # Calculated Features
        calc_features = ['cumulative_runs', 'chasing_or_setting', 'target_score', 'required_run_rate', 'partnership_runs', 'last_wicket_fall']
        f.write("\nCalculated Features:\n")
        for feature in calc_features:
            f.write(f"- {feature}: {df[feature].dtype}\n")
        
        # 3. Data Quality
        f.write("\n3. Data Quality\n")
        f.write("==============\n")
        
        # Missing Values
        missing = df.isnull().sum()
        f.write("\nMissing Values:\n")
        if missing.any():
            for col in missing[missing > 0].index:
                f.write(f"{col}: {missing[col]:,} ({(missing[col]/len(df)*100):.2f}%)\n")
        else:
            f.write("No missing values found.\n")
        
        # Value Ranges
        f.write("\nValue Ranges:\n")
        numeric_cols = df.select_dtypes(include=[np.number]).columns
        for col in numeric_cols:
            f.write(f"{col}:\n")
            f.write(f"  Min: {df[col].min():.2f}\n")
            f.write(f"  Max: {df[col].max():.2f}\n")
            f.write(f"  Mean: {df[col].mean():.2f}\n")
            f.write(f"  Std: {df[col].std():.2f}\n")
        
        # 4. Feature Distributions
        f.write("\n4. Feature Distributions\n")
        f.write("======================\n")
        
        # Innings Distribution
        f.write("\nInnings Distribution:\n")
        f.write(df['innings_number'].value_counts().to_string())
        f.write("\n")
        
        # Match Phase Distribution
        f.write("\nMatch Phase Distribution:\n")
        f.write(df['match_phase'].value_counts().to_string())
        f.write("\n")
        
        # Chasing vs Setting Distribution
        f.write("\nChasing vs Setting Distribution:\n")
        f.write(df['chasing_or_setting'].value_counts().to_string())
        f.write("\n")
        
        # 5. Data Validation
        f.write("\n5. Data Validation\n")
        f.write("================\n")
        
        # Check for logical constraints
        f.write("\nLogical Constraints:\n")
        
        # Check if runs are non-negative
        runs_check = (df['runs'] >= 0).all()
        f.write(f"Runs non-negative: {'PASS' if runs_check else 'FAIL'}\n")
        
        # Check if wickets are non-negative
        wickets_check = (df['wickets'] >= 0).all()
        f.write(f"Wickets non-negative: {'PASS' if wickets_check else 'FAIL'}\n")
        
        # Check if over numbers are valid
        over_check = (df['over'] >= 0).all() and (df['over'] <= 20).all()
        f.write(f"Over numbers valid: {'PASS' if over_check else 'FAIL'}\n")
        
        # Check if ball numbers are valid
        ball_check = (df['ball'] >= 1).all() and (df['ball'] <= 6).all()
        f.write(f"Ball numbers valid: {'PASS' if ball_check else 'FAIL'}\n")
        
        # Check if required run rate is valid
        rrr_check = (df['required_run_rate'] >= 0).all() and (df['required_run_rate'] <= 36).all()
        f.write(f"Required run rate valid: {'PASS' if rrr_check else 'FAIL'}\n")
        
        # 6. Recommendations
        f.write("\n6. Recommendations\n")
        f.write("=================\n")
        
        if not runs_check:
            f.write("- Investigate negative runs values\n")
        if not wickets_check:
            f.write("- Investigate negative wickets values\n")
        if not over_check:
            f.write("- Investigate invalid over numbers\n")
        if not ball_check:
            f.write("- Investigate invalid ball numbers\n")
        if not rrr_check:
            f.write("- Investigate invalid required run rates\n")
        
        if missing.any():
            f.write("- Address missing values in the following features:\n")
            for col in missing[missing > 0].index:
                f.write(f"  * {col}\n")
        
        f.write("\nDataset is ready for modeling if all validation checks pass.\n")
    
    print(f"Analysis report saved to: {report_file}")
    
    # Generate visualizations
    plt.figure(figsize=(15, 10))
    
    # Plot 1: Runs Distribution
    plt.subplot(2, 2, 1)
    sns.histplot(data=df, x='runs', bins=30)
    plt.title('Distribution of Runs')
    
    # Plot 2: Current Run Rate by Innings
    plt.subplot(2, 2, 2)
    sns.boxplot(data=df, x='innings_number', y='current_run_rate')
    plt.title('Current Run Rate by Innings')
    
    # Plot 3: Required Run Rate Distribution
    plt.subplot(2, 2, 3)
    sns.histplot(data=df[df['innings_number'] == 2], x='required_run_rate', bins=30)
    plt.title('Required Run Rate Distribution (2nd Innings)')
    
    # Plot 4: Partnership Runs Distribution
    plt.subplot(2, 2, 4)
    sns.histplot(data=df, x='partnership_runs', bins=30)
    plt.title('Distribution of Partnership Runs')
    
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, f"feature_distributions_{timestamp}.png"))
    plt.close()
    
    print(f"Visualizations saved to: {os.path.join(output_dir, f'feature_distributions_{timestamp}.png')}")

def main():
    # Load the final dataset
    print("Loading final dataset...")
    df = pd.read_csv("Model/Data/final/final_enhanced_dataset.csv")
    
    # Analyze the dataset
    analyze_dataset(df)
    
    print("\nAnalysis completed successfully!")

if __name__ == "__main__":
    main() 