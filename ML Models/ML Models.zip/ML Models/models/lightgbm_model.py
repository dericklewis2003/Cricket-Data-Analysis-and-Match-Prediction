import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
import lightgbm as lgb
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
import joblib
import os

class LightGBMModel:
    def __init__(self):
        self.model = None
        self.label_encoders = {}
        self.feature_columns = [
            'over', 'ball', 'innings', 'cumulative_runs', 'cumulative_wickets',
            'current_run_rate', 'Run_In_Last5', 'Wickets_In_Last5', 'AverageScore',
            'venue_encoded', 'team1_encoded', 'team2_encoded'
        ]
        self.target_column = 'runs'
        
    def preprocess_data(self, df):
        """Preprocess the data for training"""
        # Create a copy of the dataframe
        data = df.copy()
        
        # Encode categorical variables
        categorical_columns = ['venue', 'team1', 'team2']
        for col in categorical_columns:
            if col not in self.label_encoders:
                self.label_encoders[col] = LabelEncoder()
                data[f'{col}_encoded'] = self.label_encoders[col].fit_transform(data[col])
            else:
                data[f'{col}_encoded'] = self.label_encoders[col].transform(data[col])
        
        return data
    
    def train(self, data, test_size=0.2):
        """Train the LightGBM model"""
        # Preprocess data
        processed_data = self.preprocess_data(data)
        
        # Split features and target
        X = processed_data[self.feature_columns]
        y = processed_data[self.target_column]
        
        # Split into train and test sets
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=test_size, random_state=42
        )
        
        # Create LightGBM dataset
        train_data = lgb.Dataset(X_train, label=y_train)
        test_data = lgb.Dataset(X_test, label=y_test, reference=train_data)
        
        # Set parameters
        params = {
            'objective': 'regression',
            'metric': 'rmse',
            'boosting_type': 'gbdt',
            'num_leaves': 31,
            'learning_rate': 0.05,
            'feature_fraction': 0.9,
            'bagging_fraction': 0.8,
            'bagging_freq': 5,
            'verbose': -1
        }
        
        # Train the model
        self.model = lgb.train(
            params,
            train_data,
            num_boost_round=1000,
            valid_sets=[train_data, test_data],
            early_stopping_rounds=50,
            verbose_eval=100
        )
        
        # Make predictions
        y_pred = self.model.predict(X_test)
        
        # Calculate metrics
        metrics = {
            'mse': mean_squared_error(y_test, y_pred),
            'rmse': np.sqrt(mean_squared_error(y_test, y_pred)),
            'mae': mean_absolute_error(y_test, y_pred),
            'r2': r2_score(y_test, y_pred)
        }
        
        return metrics
    
    def predict(self, data):
        """Make predictions on new data"""
        if self.model is None:
            raise ValueError("Model not trained yet!")
        
        # Preprocess data
        processed_data = self.preprocess_data(data)
        
        # Make predictions
        predictions = self.model.predict(processed_data[self.feature_columns])
        return predictions
    
    def save_model(self, path):
        """Save the model and label encoders"""
        if not os.path.exists(path):
            os.makedirs(path)
        
        # Save the model
        self.model.save_model(os.path.join(path, 'lightgbm_model.txt'))
        
        # Save label encoders
        joblib.dump(self.label_encoders, os.path.join(path, 'label_encoders.pkl'))
    
    def load_model(self, path):
        """Load the model and label encoders"""
        # Load the model
        self.model = lgb.Booster(model_file=os.path.join(path, 'lightgbm_model.txt'))
        
        # Load label encoders
        self.label_encoders = joblib.load(os.path.join(path, 'label_encoders.pkl'))
    
    def get_feature_importance(self):
        """Get feature importance scores"""
        if self.model is None:
            raise ValueError("Model not trained yet!")
        
        importance = self.model.feature_importance()
        feature_importance = pd.DataFrame({
            'feature': self.feature_columns,
            'importance': importance
        })
        return feature_importance.sort_values('importance', ascending=False) 