import pandas as pd
import numpy as np
from datetime import datetime
import os

def split_dataset(df):
    """Split dataset into training, validation, and test sets while maintaining time-series continuity"""
    print("=== Dataset Splitting Process ===\n")
    
    # Create output directory if it doesn't exist
    output_dir = "Model/Data/final"
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    # Sort by date to maintain time-series continuity
    df = df.sort_values('date')
    
    # Get unique match IDs
    match_ids = df['match_id'].unique()
    np.random.seed(42)  # For reproducibility
    np.random.shuffle(match_ids)
    
    # Calculate split indices
    n_matches = len(match_ids)
    train_size = int(0.7 * n_matches)
    val_size = int(0.15 * n_matches)
    
    # Split match IDs
    train_matches = match_ids[:train_size]
    val_matches = match_ids[train_size:train_size + val_size]
    test_matches = match_ids[train_size + val_size:]
    
    # Create splits
    train_df = df[df['match_id'].isin(train_matches)]
    val_df = df[df['match_id'].isin(val_matches)]
    test_df = df[df['match_id'].isin(test_matches)]
    
    # Print split information
    print("Split Information:")
    print(f"Total matches: {n_matches}")
    print(f"Training matches: {len(train_matches)} ({len(train_df):,} records)")
    print(f"Validation matches: {len(val_matches)} ({len(val_df):,} records)")
    print(f"Test matches: {len(test_matches)} ({len(test_df):,} records)")
    
    # Save splits
    train_df.to_csv(os.path.join(output_dir, f"train_dataset_{timestamp}.csv"), index=False)
    val_df.to_csv(os.path.join(output_dir, f"val_dataset_{timestamp}.csv"), index=False)
    test_df.to_csv(os.path.join(output_dir, f"test_dataset_{timestamp}.csv"), index=False)
    
    # Save split information
    with open(os.path.join(output_dir, f"split_info_{timestamp}.txt"), 'w') as f:
        f.write("=== Dataset Split Information ===\n\n")
        f.write(f"Total matches: {n_matches}\n")
        f.write(f"Training matches: {len(train_matches)} ({len(train_df):,} records)\n")
        f.write(f"Validation matches: {len(val_matches)} ({len(val_df):,} records)\n")
        f.write(f"Test matches: {len(test_matches)} ({len(test_df):,} records)\n\n")
        
        f.write("Date Ranges:\n")
        f.write(f"Training: {train_df['date'].min()} to {train_df['date'].max()}\n")
        f.write(f"Validation: {val_df['date'].min()} to {val_df['date'].max()}\n")
        f.write(f"Test: {test_df['date'].min()} to {test_df['date'].max()}\n\n")
        
        f.write("Feature Statistics:\n")
        for col in train_df.select_dtypes(include=[np.number]).columns:
            f.write(f"\n{col}:\n")
            f.write(f"Training - Mean: {train_df[col].mean():.2f}, Std: {train_df[col].std():.2f}\n")
            f.write(f"Validation - Mean: {val_df[col].mean():.2f}, Std: {val_df[col].std():.2f}\n")
            f.write(f"Test - Mean: {test_df[col].mean():.2f}, Std: {test_df[col].std():.2f}\n")
    
    print(f"\nSplit datasets and information saved to: {output_dir}")
    return train_df, val_df, test_df

def main():
    # Load the final dataset
    print("Loading final dataset...")
    df = pd.read_csv("Model/Data/final/final_enhanced_dataset.csv")
    
    # Split the dataset
    train_df, val_df, test_df = split_dataset(df)
    
    print("\nDataset splitting completed successfully!")

if __name__ == "__main__":
    main() 