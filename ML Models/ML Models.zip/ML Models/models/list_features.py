import pandas as pd

def list_features():
    # Load the dataset
    print("Loading dataset...")
    df = pd.read_csv("Model/Data/processed/cleaned_t20i_ball_by_ball_features_20250319_172744.csv")
    
    print("\n=== Dataset Features ===\n")
    print("1. Match Information:")
    match_features = ['match_id', 'date', 'venue', 'series', 'toss_winner', 'toss_decision', 'result', 'match_format']
    for feature in match_features:
        print(f"- {feature}")
    
    print("\n2. Team Information:")
    team_features = ['team1', 'team2', 'batting_team', 'bowling_team']
    for feature in team_features:
        print(f"- {feature}")
    
    print("\n3. Ball-by-Ball Information:")
    ball_features = ['innings_number', 'over', 'ball', 'runs', 'wickets', 'extras', 'fours', 'sixes']
    for feature in ball_features:
        print(f"- {feature}")
    
    print("\n4. Player Information:")
    player_features = ['batter', 'bowler']
    for feature in player_features:
        print(f"- {feature}")
    
    print("\n5. Match Phase Information:")
    phase_features = ['match_phase']
    for feature in phase_features:
        print(f"- {feature}")
    
    print("\n6. Calculated Features:")
    calculated_features = ['current_run_rate', 'projected_score', 'Run_In_Last5', 'Wickets_In_Last5', 'AverageScore']
    for feature in calculated_features:
        print(f"- {feature}")
    
    print("\nTotal number of features:", len(df.columns))
    
    # Print data types
    print("\nFeature Data Types:")
    print(df.dtypes)

if __name__ == "__main__":
    list_features() 