import pandas as pd
import numpy as np
import pickle
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score, explained_variance_score
import os
from datetime import datetime

class ModelEvaluator:
    def __init__(self, model_name, model_path):
        self.model_name = model_name
        self.model = pickle.load(open(model_path, 'rb'))
        self.results = None
        
    def evaluate(self, test_scenarios):
        results = []
        for scenario in test_scenarios:
            # Calculate features
            balls_left = 120 - (scenario['overs'] * 6)
            wicket_left = 10 - scenario['wickets']
            current_run_rate = scenario['current_score'] / scenario['overs'] if scenario['overs'] > 0 else 0
            
            # Create input DataFrame
            input_df = pd.DataFrame({
                'batting_team': [scenario['batting_team']],
                'bowling_team': [scenario['bowling_team']],
                'city': [scenario['city']],
                'current_score': [scenario['current_score']],
                'balls_left': [balls_left],
                'wicket_left': [wicket_left],
                'current_run_rate': [current_run_rate],
                'last_five': [scenario['last_five']]
            })
            
            # Make prediction
            predicted_score = int(self.model.predict(input_df)[0])
            
            # Store results
            results.append({
                'Scenario': f"Scenario {len(results) + 1}",
                'Batting_Team': scenario['batting_team'],
                'Bowling_Team': scenario['bowling_team'],
                'City': scenario['city'],
                'Current_Score': scenario['current_score'],
                'Overs': scenario['overs'],
                'Wickets': scenario['wickets'],
                'Last_Five': scenario['last_five'],
                'Actual': scenario['actual_score'],
                'Predicted': predicted_score,
                'Error': predicted_score - scenario['actual_score'],
                'Abs_Error': abs(predicted_score - scenario['actual_score']),
                'Error_Percentage': abs(predicted_score - scenario['actual_score']) / scenario['actual_score'] * 100
            })
        
        self.results = pd.DataFrame(results)
        return self.results
    
    def calculate_metrics(self):
        if self.results is None:
            raise ValueError("Must run evaluate() first")
            
        metrics = {
            'Model Name': self.model_name,
            'RMSE': np.sqrt(mean_squared_error(self.results['Actual'], self.results['Predicted'])),
            'MAE': mean_absolute_error(self.results['Actual'], self.results['Predicted']),
            'R²': r2_score(self.results['Actual'], self.results['Predicted']),
            'MAPE': self.results['Error_Percentage'].mean(),
            'Explained Variance': explained_variance_score(self.results['Actual'], self.results['Predicted']),
            'Max Error': self.results['Abs_Error'].max(),
            'Average Error': self.results['Error'].mean(),
            'Standard Deviation of Error': self.results['Error'].std()
        }
        return metrics
    
    def plot_results(self, save_path=None):
        if self.results is None:
            raise ValueError("Must run evaluate() first")
            
        plt.style.use('default')
        
        # Create a directory for individual plots
        if save_path:
            plot_dir = os.path.dirname(save_path)
            os.makedirs(plot_dir, exist_ok=True)
        
        # 1. Main Performance Dashboard
        fig = plt.figure(figsize=(20, 15))
        
        # 1.1 Actual vs Predicted Scores with Perfect Prediction Line
        plt.subplot(2, 3, 1)
        plt.scatter(self.results['Actual'], self.results['Predicted'], alpha=0.6)
        min_val = min(self.results['Actual'].min(), self.results['Predicted'].min())
        max_val = max(self.results['Actual'].max(), self.results['Predicted'].max())
        plt.plot([min_val, max_val], [min_val, max_val], 'r--', label='Perfect Prediction')
        plt.xlabel('Actual Score')
        plt.ylabel('Predicted Score')
        plt.title(f'Actual vs Predicted Scores\n{self.model_name}')
        plt.legend()
        
        # 1.2 Error Distribution
        plt.subplot(2, 3, 2)
        sns.histplot(self.results['Error'], bins=15, kde=True)
        plt.axvline(x=0, color='r', linestyle='--', alpha=0.5)
        plt.xlabel('Prediction Error')
        plt.ylabel('Count')
        plt.title('Distribution of Prediction Errors')
        
        # 1.3 Error by Scenario
        plt.subplot(2, 3, 3)
        plt.bar(self.results['Scenario'], self.results['Error'])
        plt.axhline(y=0, color='r', linestyle='--', alpha=0.5)
        plt.xticks(rotation=45)
        plt.xlabel('Scenario')
        plt.ylabel('Error (Predicted - Actual)')
        plt.title('Error by Scenario')
        
        # 1.4 Actual vs Predicted by Scenario
        plt.subplot(2, 3, 4)
        width = 0.35
        x = np.arange(len(self.results['Scenario']))
        plt.bar(x - width/2, self.results['Actual'], width, label='Actual')
        plt.bar(x + width/2, self.results['Predicted'], width, label='Predicted')
        plt.xlabel('Scenario')
        plt.ylabel('Score')
        plt.title('Actual vs Predicted Scores by Scenario')
        plt.xticks(x, self.results['Scenario'], rotation=45)
        plt.legend()
        
        # 1.5 Error Percentage by Scenario
        plt.subplot(2, 3, 5)
        plt.bar(self.results['Scenario'], self.results['Error_Percentage'])
        plt.axhline(y=10, color='g', linestyle='--', alpha=0.5, label='10% Error')
        plt.axhline(y=20, color='y', linestyle='--', alpha=0.5, label='20% Error')
        plt.axhline(y=30, color='r', linestyle='--', alpha=0.5, label='30% Error')
        plt.xticks(rotation=45)
        plt.xlabel('Scenario')
        plt.ylabel('Error Percentage')
        plt.title('Error Percentage by Scenario')
        plt.legend()
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path)
            plt.close()
            
            # Additional Analysis Plots
            
            # 2. Error Analysis by Match Phase
            plt.figure(figsize=(15, 8))
            phase_data = self.results.copy()
            phase_data['Phase'] = pd.cut(phase_data['Overs'], 
                                       bins=[0, 6, 15, 20],
                                       labels=['Powerplay', 'Middle', 'Death'])
            sns.boxplot(x='Phase', y='Error_Percentage', data=phase_data)
            plt.title('Error Distribution by Match Phase')
            plt.ylabel('Error Percentage')
            if save_path:
                plt.savefig(f"{plot_dir}/phase_analysis.png")
                plt.close()
            
            # 3. Error Analysis by Wickets Lost
            plt.figure(figsize=(15, 8))
            wicket_data = self.results.copy()
            wicket_data['Wicket_Group'] = pd.cut(wicket_data['Wickets'],
                                                bins=[-1, 2, 5, 9],
                                                labels=['Few (0-2)', 'Medium (3-5)', 'Many (6-9)'])
            sns.boxplot(x='Wicket_Group', y='Error_Percentage', data=wicket_data)
            plt.title('Error Distribution by Wickets Lost')
            plt.ylabel('Error Percentage')
            if save_path:
                plt.savefig(f"{plot_dir}/wickets_analysis.png")
                plt.close()
            
            # 4. Score Range Analysis
            plt.figure(figsize=(15, 8))
            score_data = self.results.copy()
            score_data['Score_Range'] = pd.cut(score_data['Actual'],
                                             bins=[0, 140, 170, 250],
                                             labels=['Low (<140)', 'Medium (140-170)', 'High (>170)'])
            sns.boxplot(x='Score_Range', y='Error_Percentage', data=score_data)
            plt.title('Error Distribution by Score Range')
            plt.ylabel('Error Percentage')
            if save_path:
                plt.savefig(f"{plot_dir}/score_range_analysis.png")
                plt.close()
            
            # 5. Run Rate Impact
            plt.figure(figsize=(12, 8))
            plt.scatter(self.results['Current_Score']/self.results['Overs'], 
                      self.results['Error_Percentage'], 
                      alpha=0.6)
            plt.xlabel('Current Run Rate')
            plt.ylabel('Error Percentage')
            plt.title('Error Percentage vs Current Run Rate')
            if save_path:
                plt.savefig(f"{plot_dir}/run_rate_analysis.png")
                plt.close()
            
            # 6. Last Five Overs Impact
            plt.figure(figsize=(12, 8))
            plt.scatter(self.results['Last_Five'], 
                      self.results['Error_Percentage'], 
                      alpha=0.6)
            plt.xlabel('Runs in Last 5 Overs')
            plt.ylabel('Error Percentage')
            plt.title('Error Percentage vs Last 5 Overs Performance')
            if save_path:
                plt.savefig(f"{plot_dir}/last_five_analysis.png")
                plt.close()
        else:
            plt.show()
            
    def generate_report(self, save_dir):
        """Generate a comprehensive analysis report."""
        if self.results is None:
            raise ValueError("Must run evaluate() first")
            
        metrics = self.calculate_metrics()
        
        # Create report directory
        os.makedirs(save_dir, exist_ok=True)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # Save all plots
        self.plot_results(f"{save_dir}/plots_{timestamp}/main_dashboard.png")
        
        # Format metrics table rows
        metrics_rows = ""
        for k, v in metrics.items():
            if isinstance(v, float):
                metrics_rows += f"<tr><td>{k}</td><td>{v:.4f}</td></tr>"
            else:
                metrics_rows += f"<tr><td>{k}</td><td>{v}</td></tr>"
        
        # Generate HTML report
        html_report = f"""
        <html>
        <head>
            <title>Cricket Score Prediction Model Evaluation Report</title>
            <style>
                body {{ font-family: Arial, sans-serif; margin: 40px; }}
                h1, h2 {{ color: #2c3e50; }}
                .metric {{ margin: 20px 0; padding: 10px; background-color: #f8f9fa; }}
                .plot {{ margin: 20px 0; }}
                .analysis {{ margin: 20px 0; }}
                table {{ border-collapse: collapse; width: 100%; }}
                th, td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
                th {{ background-color: #f2f2f2; }}
            </style>
        </head>
        <body>
            <h1>Cricket Score Prediction Model Evaluation Report</h1>
            <div class="metric">
                <h2>Model Performance Metrics</h2>
                <table>
                    <tr><th>Metric</th><th>Value</th></tr>
                    {metrics_rows}
                </table>
            </div>
            
            <div class="analysis">
                <h2>Key Findings</h2>
                <ul>
                    <li>Overall Model Performance: {self._get_performance_summary(metrics)}</li>
                    <li>Best Predictions: {self._get_best_predictions()}</li>
                    <li>Worst Predictions: {self._get_worst_predictions()}</li>
                    <li>Phase Analysis: {self._get_phase_analysis()}</li>
                </ul>
            </div>
            
            <div class="plot">
                <h2>Visualization Dashboard</h2>
                <img src="plots_{timestamp}/main_dashboard.png" style="width: 100%;">
            </div>
            
            <div class="plot">
                <h2>Detailed Analysis Plots</h2>
                <img src="plots_{timestamp}/phase_analysis.png" style="width: 100%;">
                <img src="plots_{timestamp}/wickets_analysis.png" style="width: 100%;">
                <img src="plots_{timestamp}/score_range_analysis.png" style="width: 100%;">
                <img src="plots_{timestamp}/run_rate_analysis.png" style="width: 100%;">
                <img src="plots_{timestamp}/last_five_analysis.png" style="width: 100%;">
            </div>
            
            <div class="analysis">
                <h2>Recommendations</h2>
                <ul>
                    <li>Consider using non-linear models (Random Forest, XGBoost) to capture complex relationships</li>
                    <li>Add more features like team rankings and head-to-head records</li>
                    <li>Increase training data size for better generalization</li>
                    <li>Add interaction terms between features</li>
                    <li>Consider separate models for different match phases</li>
                </ul>
            </div>
        </body>
        </html>
        """
        
        with open(f"{save_dir}/report_{timestamp}.html", 'w') as f:
            f.write(html_report)
        
        return f"{save_dir}/report_{timestamp}.html"
    
    def _get_performance_summary(self, metrics):
        """Generate overall performance summary."""
        if metrics['R²'] < 0.3:
            performance = "poor"
        elif metrics['R²'] < 0.6:
            performance = "moderate"
        else:
            performance = "good"
            
        return f"The model shows {performance} performance with R² of {metrics['R²']:.4f} and MAPE of {metrics['MAPE']:.2f}%"
    
    def _get_best_predictions(self):
        """Get summary of best predictions."""
        best = self.results.nsmallest(3, 'Error_Percentage')
        return f"Best predictions were for {', '.join(best['Batting_Team'] + ' vs ' + best['Bowling_Team'])} with errors of {', '.join(f'{x:.1f}%' for x in best['Error_Percentage'])}"
    
    def _get_worst_predictions(self):
        """Get summary of worst predictions."""
        worst = self.results.nlargest(3, 'Error_Percentage')
        return f"Worst predictions were for {', '.join(worst['Batting_Team'] + ' vs ' + worst['Bowling_Team'])} with errors of {', '.join(f'{x:.1f}%' for x in worst['Error_Percentage'])}"
    
    def _get_phase_analysis(self):
        """Analyze performance across different match phases."""
        phase_data = self.results.copy()
        phase_data['Phase'] = pd.cut(phase_data['Overs'], 
                                   bins=[0, 6, 15, 20],
                                   labels=['Powerplay', 'Middle', 'Death'])
        phase_errors = phase_data.groupby('Phase')['Error_Percentage'].mean()
        worst_phase = phase_errors.idxmax()
        best_phase = phase_errors.idxmin()
        return f"Model performs best in {best_phase} overs ({phase_errors[best_phase]:.1f}% error) and worst in {worst_phase} overs ({phase_errors[worst_phase]:.1f}% error)"

# Test scenarios (comprehensive T20 match scenarios)
test_scenarios = [
    # Powerplay Scenarios (1-6 overs)
    {
        'batting_team': 'India',
        'bowling_team': 'Pakistan',
        'city': 'Mumbai',
        'current_score': 45,
        'overs': 5.0,
        'wickets': 1,
        'last_five': 45,
        'actual_score': 185
    },
    {
        'batting_team': 'Australia',
        'bowling_team': 'England',
        'city': 'Sydney',
        'current_score': 25,
        'overs': 4.0,
        'wickets': 3,
        'last_five': 25,
        'actual_score': 145
    },
    
    # Middle Overs Scenarios (7-15)
    {
        'batting_team': 'England',
        'bowling_team': 'South Africa',
        'city': 'London',
        'current_score': 85,
        'overs': 10.0,
        'wickets': 2,
        'last_five': 35,
        'actual_score': 180
    },
    {
        'batting_team': 'New Zealand',
        'bowling_team': 'Australia',
        'city': 'Wellington',
        'current_score': 70,
        'overs': 12.0,
        'wickets': 5,
        'last_five': 25,
        'actual_score': 140
    },
    
    # Death Overs Scenarios (16-20)
    {
        'batting_team': 'West Indies',
        'bowling_team': 'India',
        'city': 'Barbados',
        'current_score': 145,
        'overs': 17.0,
        'wickets': 4,
        'last_five': 50,
        'actual_score': 190
    },
    {
        'batting_team': 'Pakistan',
        'bowling_team': 'Bangladesh',
        'city': 'Lahore',
        'current_score': 130,
        'overs': 18.0,
        'wickets': 7,
        'last_five': 35,
        'actual_score': 155
    },
    
    # Low Scoring Games
    {
        'batting_team': 'Bangladesh',
        'bowling_team': 'Sri Lanka',
        'city': 'Mirpur',
        'current_score': 50,
        'overs': 10.0,
        'wickets': 4,
        'last_five': 20,
        'actual_score': 135
    },
    {
        'batting_team': 'South Africa',
        'bowling_team': 'New Zealand',
        'city': 'Cape Town',
        'current_score': 60,
        'overs': 12.0,
        'wickets': 6,
        'last_five': 15,
        'actual_score': 125
    },
    
    # High Scoring Games
    {
        'batting_team': 'England',
        'bowling_team': 'Afghanistan',
        'city': 'Manchester',
        'current_score': 110,
        'overs': 12.0,
        'wickets': 1,
        'last_five': 55,
        'actual_score': 220
    },
    {
        'batting_team': 'Australia',
        'bowling_team': 'West Indies',
        'city': 'Melbourne',
        'current_score': 95,
        'overs': 10.0,
        'wickets': 2,
        'last_five': 48,
        'actual_score': 205
    },
    
    # Different Wicket Situations
    {
        'batting_team': 'India',
        'bowling_team': 'Sri Lanka',
        'city': 'Kolkata',
        'current_score': 80,
        'overs': 10.0,
        'wickets': 0,
        'last_five': 40,
        'actual_score': 195
    },
    {
        'batting_team': 'Pakistan',
        'bowling_team': 'Afghanistan',
        'city': 'Karachi',
        'current_score': 75,
        'overs': 10.0,
        'wickets': 5,
        'last_five': 30,
        'actual_score': 160
    },
    {
        'batting_team': 'South Africa',
        'bowling_team': 'England',
        'city': 'Johannesburg',
        'current_score': 65,
        'overs': 10.0,
        'wickets': 8,
        'last_five': 20,
        'actual_score': 130
    },
    
    # Different Run Rates
    {
        'batting_team': 'Australia',
        'bowling_team': 'India',
        'city': 'Adelaide',
        'current_score': 100,
        'overs': 10.0,
        'wickets': 3,
        'last_five': 50,
        'actual_score': 200
    },
    {
        'batting_team': 'New Zealand',
        'bowling_team': 'Pakistan',
        'city': 'Auckland',
        'current_score': 60,
        'overs': 10.0,
        'wickets': 3,
        'last_five': 25,
        'actual_score': 150
    },
    
    # Different Venues
    {
        'batting_team': 'India',
        'bowling_team': 'England',
        'city': 'Delhi',
        'current_score': 90,
        'overs': 10.0,
        'wickets': 2,
        'last_five': 45,
        'actual_score': 185
    },
    {
        'batting_team': 'Australia',
        'bowling_team': 'South Africa',
        'city': 'Sydney',
        'current_score': 85,
        'overs': 10.0,
        'wickets': 2,
        'last_five': 40,
        'actual_score': 175
    },
    
    # Extreme Scenarios
    {
        'batting_team': 'West Indies',
        'bowling_team': 'Sri Lanka',
        'city': 'Barbados',
        'current_score': 120,
        'overs': 10.0,
        'wickets': 1,
        'last_five': 60,
        'actual_score': 230
    },
    {
        'batting_team': 'Bangladesh',
        'bowling_team': 'Afghanistan',
        'city': 'Mirpur',
        'current_score': 40,
        'overs': 10.0,
        'wickets': 7,
        'last_five': 15,
        'actual_score': 110
    },
    
    # Recent Form Impact
    {
        'batting_team': 'England',
        'bowling_team': 'New Zealand',
        'city': 'London',
        'current_score': 80,
        'overs': 10.0,
        'wickets': 2,
        'last_five': 55,
        'actual_score': 190
    },
    {
        'batting_team': 'Pakistan',
        'bowling_team': 'India',
        'city': 'Karachi',
        'current_score': 75,
        'overs': 10.0,
        'wickets': 2,
        'last_five': 25,
        'actual_score': 165
    }
]

def main():
    # Create results directory if it doesn't exist
    results_dir = "model_evaluation_results"
    if not os.path.exists(results_dir):
        os.makedirs(results_dir)
    
    # Initialize and evaluate Linear Regression model
    model_path = "C:/Users/Devona/Desktop/Derick/Final Year Project/final year project/pipe.pkl"
    evaluator = ModelEvaluator("Linear Regression", model_path)
    
    # Run evaluation
    results = evaluator.evaluate(test_scenarios)
    
    # Generate comprehensive report
    report_path = evaluator.generate_report(results_dir)
    
    print(f"\nEvaluation complete! Report saved to: {report_path}")

if __name__ == "__main__":
    main() 