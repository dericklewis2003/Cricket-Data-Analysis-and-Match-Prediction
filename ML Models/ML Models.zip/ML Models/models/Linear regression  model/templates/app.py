import pandas as pd
import numpy as np
from flask import Flask, render_template, request, flash
import pickle
import os

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'  # Required for flashing messages

# Load the model from the current directory
try:
    pipe = pickle.load(open("C:/Users/Devona/Desktop/Derick/Final Year Project/final year project/pipe.pkl", 'rb'))
    print("Model loaded successfully!")
    print(f"Type of model: {type(pipe)}")
except FileNotFoundError:
    print("Model file not found. Please check the path.")
    print(f"Files in current directory:")
    print(os.listdir('.'))

# Load the dataset to get actual cities
df = pd.read_csv("C:/Users/Devona/Desktop/Derick/Final Year Project/final year project/t20i_info.csv")
cities = sorted([city for city in df['city'].unique() if pd.notna(city)])

teams = [
    'Australia', 'India', 'Bangladesh', 'New Zealand', 'South Africa',
    'England', 'West Indies', 'Afghanistan', 'Pakistan', 'Sri Lanka'
]

@app.route('/', methods=['GET', 'POST'])
def index():
    prediction = None
    error_message = None
    if request.method == 'POST':
        try:
            # Retrieve form data
            batting_team = request.form['batting_team']
            bowling_team = request.form['bowling_team']
            city = request.form['city']
            current_score = int(request.form['current_score'])
            overs = float(request.form['overs'])
            wickets = int(request.form['wickets'])
            last_five = int(request.form['last_five'])

            # Print input data for debugging
            print("\nInput Data:")
            print(f"Batting Team: {batting_team}")
            print(f"Bowling Team: {bowling_team}")
            print(f"City: {city}")
            print(f"Current Score: {current_score}")
            print(f"Overs: {overs}")
            print(f"Wickets: {wickets}")
            print(f"Last Five: {last_five}")

            # Validate inputs
            if batting_team == bowling_team:
                raise ValueError("Batting team and bowling team cannot be the same")
            
            if overs > 20:
                raise ValueError("Overs cannot be more than 20")
            
            if wickets >= 10:
                raise ValueError("Wickets cannot be 10 or more")
            
            if current_score < 0:
                raise ValueError("Current score cannot be negative")

            # Calculate required features
            balls_left = 120 - (overs * 6)
            wicket_left = 10 - wickets
            current_run_rate = current_score / overs if overs > 0 else 0

            # Print calculated features
            print("\nCalculated Features:")
            print(f"Balls Left: {balls_left}")
            print(f"Wickets Left: {wicket_left}")
            print(f"Current Run Rate: {current_run_rate}")

            # Create DataFrame with column names expected by the pipeline
            input_df = pd.DataFrame({
                'batting_team': [batting_team],
                'bowling_team': [bowling_team],
                'city': [city],
                'current_score': [current_score],
                'balls_left': [balls_left],
                'wicket_left': [wicket_left],
                'current_run_rate': [current_run_rate],
                'last_five': [last_five]
            })

            # Print the input DataFrame
            print("\nInput DataFrame:")
            print(input_df)

            # Make prediction
            result = pipe.predict(input_df)
            prediction = int(result[0])
            print(f"\nPrediction made: {prediction}")
            
            # Print the type and shape of the prediction
            print(f"Prediction type: {type(result)}")
            print(f"Prediction shape: {result.shape if hasattr(result, 'shape') else 'N/A'}")
            print(f"Raw prediction value: {result}")

        except ValueError as e:
            error_message = str(e)
            print(f"Validation error: {e}")
        except Exception as e:
            error_message = "An error occurred while making the prediction. Please try different values."
            print(f"Error during prediction: {e}")
            import traceback
            print(traceback.format_exc())

    return render_template('index.html', 
                         teams=sorted(teams), 
                         cities=cities, 
                         prediction=prediction,
                         error_message=error_message)

if __name__ == '__main__':
    print("Starting Flask app...")
    app.run(debug=True)