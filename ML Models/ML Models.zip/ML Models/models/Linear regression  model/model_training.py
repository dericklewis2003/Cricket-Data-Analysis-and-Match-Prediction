import pandas as pd
import numpy as np
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
import pickle
import os

# Get the current directory path
current_dir = os.path.dirname(os.path.abspath(__file__))

# Load the dataset
df = pd.read_csv(os.path.join(current_dir, 't20i_info.csv'))

# Process the data to create features
df['over'] = df['ball'].apply(lambda x: int(str(x).split('.')[0]))
df['ball_in_over'] = df['ball'].apply(lambda x: int(str(x).split('.')[1]) if '.' in str(x) else 0)
df['total_balls'] = df['over'] * 6 + df['ball_in_over']

# Group by match_id and calculate features
match_features = []
for match_id, group in df.groupby('match_id'):
    current_score = group['runs'].cumsum()
    balls_left = 120 - group['total_balls']
    wickets = group['player_dismissed'].notna().cumsum()
    wickets_left = 10 - wickets
    
    # Calculate current run rate
    overs_completed = group['total_balls'] / 6
    current_run_rate = current_score / overs_completed.replace(0, 1)  # Avoid division by zero
    
    # Calculate runs in last 5 overs (30 balls)
    last_five_runs = []
    for idx in range(len(group)):
        if idx < 30:
            last_five_runs.append(group['runs'].iloc[:idx+1].sum())
        else:
            last_five_runs.append(group['runs'].iloc[idx-29:idx+1].sum())
    
    # Create match features
    for idx in range(len(group)):
        if group['total_balls'].iloc[idx] < 120:  # Only consider incomplete innings
            match_features.append({
                'match_id': match_id,
                'batting_team': group['batting_team'].iloc[0],
                'bowling_team': group['bowling_team'].iloc[0],
                'city': group['city'].iloc[0],
                'current_score': current_score.iloc[idx],
                'balls_left': balls_left.iloc[idx],
                'wicket_left': wickets_left.iloc[idx],
                'current_run_rate': current_run_rate.iloc[idx],
                'last_five': last_five_runs[idx],
                'final_score': current_score.iloc[-1]  # Target variable
            })

# Create features DataFrame
features_df = pd.DataFrame(match_features)

# Features we'll use for prediction
features = ['batting_team', 'bowling_team', 'city', 'current_score', 'balls_left', 'wicket_left', 'current_run_rate', 'last_five']
X = features_df[features]
y = features_df['final_score']

# Split the data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Create preprocessing steps
numeric_features = ['current_score', 'balls_left', 'wicket_left', 'current_run_rate', 'last_five']
categorical_features = ['batting_team', 'bowling_team', 'city']

# Create preprocessing steps
preprocessor = ColumnTransformer(
    transformers=[
        ('num', StandardScaler(), numeric_features),
        ('cat', OneHotEncoder(drop='first', sparse_output=False), categorical_features)
    ])

# Create pipeline
model = Pipeline([
    ('preprocessor', preprocessor),
    ('regressor', LinearRegression())
])

# Fit the pipeline
model.fit(X_train, y_train)

# Save the model
model_path = os.path.join(current_dir, 'pipe.pkl')
with open(model_path, 'wb') as f:
    pickle.dump(model, f)

# Print model score and statistics
train_score = model.score(X_train, y_train)
test_score = model.score(X_test, y_test)
print(f"Training R² score: {train_score:.4f}")
print(f"Testing R² score: {test_score:.4f}")
print(f"Model saved to: {model_path}")

# Print some sample predictions
print("\nSample Predictions:")
sample_indices = np.random.randint(0, len(X_test), 5)
for idx in sample_indices:
    actual = y_test.iloc[idx]
    pred = model.predict(X_test.iloc[[idx]])[0]
    print(f"Actual: {actual:.0f}, Predicted: {pred:.0f}, Difference: {abs(actual-pred):.0f}") 