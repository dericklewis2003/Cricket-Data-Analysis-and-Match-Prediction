import pandas as pd
import numpy as np
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
import lightgbm as lgb
from datetime import datetime
import os
import joblib
import warnings
import sys
from collections import Counter
import time

# Custom warning handler
warning_count = Counter()
MAX_WARNINGS = 50  # Maximum number of warnings before stopping

def print_progress(message, start_time=None):
    """Print progress message with timestamp and elapsed time if start_time is provided"""
    current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    if start_time:
        elapsed = time.time() - start_time
        elapsed_minutes = int(elapsed / 60)
        elapsed_seconds = int(elapsed % 60)
        print(f"[{current_time}] [{elapsed_minutes}m {elapsed_seconds}s] {message}")
    else:
        print(f"[{current_time}] {message}")

def warning_handler(message, category, filename, lineno, file=None, line=None):
    warning_count[category.__name__] += 1
    if warning_count[category.__name__] >= MAX_WARNINGS:
        print_progress(f"=== WARNING: Too many {category.__name__} warnings detected! ===")
        print_progress("Stopping training to prevent potential issues.")
        sys.exit(1)
    return warnings.showwarning(message, category, filename, lineno, file, line)

warnings.showwarning = warning_handler
warnings.filterwarnings('always')

def prepare_features(df):
    """Prepare features for training"""
    print_progress("Starting feature preparation...")
    start_time = time.time()
    
    # Define categorical and numerical features
    categorical_features = [
        'venue', 'series', 'toss_winner', 'toss_decision', 'result', 'match_format',
        'team1', 'team2', 'batting_team', 'bowling_team', 'match_phase',
        'batter', 'bowler'
    ]
    
    numerical_features = [
        'innings_number', 'over', 'ball', 'runs', 'wickets', 'extras',
        'fours', 'sixes', 'current_run_rate', 'projected_score',
        'Run_In_Last5', 'Wickets_In_Last5', 'AverageScore',
        'cumulative_runs', 'chasing_or_setting', 'target_score',
        'required_run_rate', 'partnership_runs', 'last_wicket_fall'
    ]
    
    print_progress("Converting categorical features...")
    for col in categorical_features:
        df[col] = df[col].astype('category')
    
    X = df[categorical_features + numerical_features]
    y = df['runs']
    
    print_progress(f"Feature preparation completed: {len(categorical_features)} categorical, {len(numerical_features)} numerical features", start_time)
    return X, y, categorical_features

def train_model(X_train, y_train, X_val, y_val, categorical_features):
    """Train LightGBM model with hyperparameter tuning"""
    print_progress("\n=== Starting LightGBM Model Training ===")
    print_progress("This process may take 20-40 minutes depending on your system...")
    print_progress(f"Training will stop if more than {MAX_WARNINGS} warnings of any type are detected.")
    start_time = time.time()
    
    # Define parameter grid for GridSearchCV with updated values
    param_grid = {
        'num_leaves': [40, 60],
        'max_depth': [8, 10],
        'learning_rate': [0.01, 0.03],
        'n_estimators': [500, 1000],
        'subsample': [0.8, 0.9],
        'colsample_bytree': [0.8, 0.9],
        'min_child_samples': [20],
        'min_child_weight': [1e-3],
        'reg_alpha': [0.0, 0.1],
        'reg_lambda': [0.0, 0.1]
    }
    
    total_combinations = len(param_grid['num_leaves']) * len(param_grid['max_depth']) * \
                        len(param_grid['learning_rate']) * len(param_grid['n_estimators']) * \
                        len(param_grid['subsample']) * len(param_grid['colsample_bytree']) * \
                        len(param_grid['min_child_samples']) * len(param_grid['min_child_weight']) * \
                        len(param_grid['reg_alpha']) * len(param_grid['reg_lambda'])
    
    print_progress(f"Total parameter combinations to try: {total_combinations}")
    print_progress(f"With 3-fold cross-validation: {total_combinations * 3} total fits")
    
    base_model = lgb.LGBMRegressor(
        objective='regression',
        metric='rmse',
        random_state=42,
        n_jobs=-1,
        max_bin=1024,
        max_cat_threshold=64,
        cat_feature_bin_size=128,
        cat_smooth=20,
        cat_l2=15,
        cat_freq_threshold=5,
        min_data_in_leaf=20,
        min_sum_hessian_in_leaf=1e-3,
        min_gain_to_split=0.01,
        min_data_per_group=10,
        is_unbalance=True,
        boost_from_average=True,
        verbose=-1
    )
    
    grid_search = GridSearchCV(
        estimator=base_model,
        param_grid=param_grid,
        cv=3,
        scoring='neg_root_mean_squared_error',
        n_jobs=-1,
        verbose=2
    )
    
    print_progress("\nStarting hyperparameter tuning...")
    print_progress("You can monitor the progress in the output below.")
    print_progress("This may take a while - please be patient...\n")
    
    try:
        eval_set = [(X_val, y_val)]
        callbacks = [lgb.early_stopping(stopping_rounds=50)]
        
        print_progress("Fitting GridSearchCV...")
        grid_search.fit(X_train, y_train)
        
        print_progress("Retraining best model with early stopping...")
        best_params = grid_search.best_params_
        best_model = lgb.LGBMRegressor(**best_params)
        best_model.fit(
            X_train, y_train,
            eval_set=eval_set,
            callbacks=callbacks,
            categorical_feature=categorical_features
        )
        
    except Exception as e:
        print_progress(f"\n=== ERROR: Training failed with error: {str(e)} ===")
        print_progress("Please check the error message and try again.")
        sys.exit(1)
    
    print_progress("\n=== Hyperparameter Tuning Completed ===")
    print_progress("Best parameters found:")
    for param, value in grid_search.best_params_.items():
        print_progress(f"{param}: {value}")
    
    print_progress(f"Total training time: {int((time.time() - start_time) / 60)} minutes")
    return best_model, grid_search.best_params_

def evaluate_model(model, X, y, dataset_name):
    """Evaluate model performance"""
    print_progress(f"\nEvaluating {dataset_name} set performance...")
    start_time = time.time()
    
    y_pred = model.predict(X)
    
    mse = mean_squared_error(y, y_pred)
    rmse = np.sqrt(mse)
    mae = mean_absolute_error(y, y_pred)
    r2 = r2_score(y, y_pred)
    
    print_progress(f"\n{dataset_name} Set Performance:")
    print_progress(f"RMSE: {rmse:.4f}")
    print_progress(f"MAE: {mae:.4f}")
    print_progress(f"R2 Score: {r2:.4f}")
    
    print_progress(f"Evaluation completed in {int(time.time() - start_time)} seconds")
    return rmse, mae, r2

def main():
    try:
        start_time = time.time()
        print_progress("=== Starting LightGBM Training Process ===")
        
        output_dir = "Model/models/LightGBM"
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        print_progress("Loading datasets...")
        train_df = pd.read_csv("../../Data/final/train_dataset_20250319_180028.csv")
        val_df = pd.read_csv("../../Data/final/val_dataset_20250319_180028.csv")
        test_df = pd.read_csv("../../Data/final/test_dataset_20250319_180028.csv")
        print_progress("Datasets loaded successfully!")
        
        X_train, y_train, categorical_features = prepare_features(train_df)
        X_val, y_val, _ = prepare_features(val_df)
        X_test, y_test, _ = prepare_features(test_df)
        
        best_model, best_params = train_model(X_train, y_train, X_val, y_val, categorical_features)
        
        print_progress("\n=== Starting Model Evaluation ===")
        train_metrics = evaluate_model(best_model, X_train, y_train, "Training")
        val_metrics = evaluate_model(best_model, X_val, y_val, "Validation")
        test_metrics = evaluate_model(best_model, X_test, y_test, "Test")
        
        print_progress("\n=== Saving Model and Results ===")
        model_path = os.path.join(output_dir, f"lightgbm_model_{timestamp}.joblib")
        results_path = os.path.join(output_dir, f"training_results_{timestamp}.txt")
        
        joblib.dump(best_model, model_path)
        
        with open(results_path, 'w') as f:
            f.write("=== LightGBM Model Training Results ===\n\n")
            f.write("Best Parameters:\n")
            for param, value in best_params.items():
                f.write(f"{param}: {value}\n")
            
            f.write("\nPerformance Metrics:\n")
            f.write("\nTraining Set:\n")
            f.write(f"RMSE: {train_metrics[0]:.4f}\n")
            f.write(f"MAE: {train_metrics[1]:.4f}\n")
            f.write(f"R2 Score: {train_metrics[2]:.4f}\n")
            
            f.write("\nValidation Set:\n")
            f.write(f"RMSE: {val_metrics[0]:.4f}\n")
            f.write(f"MAE: {val_metrics[1]:.4f}\n")
            f.write(f"R2 Score: {val_metrics[2]:.4f}\n")
            
            f.write("\nTest Set:\n")
            f.write(f"RMSE: {test_metrics[0]:.4f}\n")
            f.write(f"MAE: {test_metrics[1]:.4f}\n")
            f.write(f"R2 Score: {test_metrics[2]:.4f}\n")
        
        print_progress(f"Model saved to: {model_path}")
        print_progress(f"Training results saved to: {results_path}")
        print_progress(f"\n=== Training Process Completed Successfully! ===")
        print_progress(f"Total process time: {int((time.time() - start_time) / 60)} minutes")
        
    except Exception as e:
        print_progress(f"\n=== ERROR: Training Process Failed ===")
        print_progress(f"Error message: {str(e)}")
        print_progress("\nPlease check the error message and try again.")

if __name__ == "__main__":
    main() 