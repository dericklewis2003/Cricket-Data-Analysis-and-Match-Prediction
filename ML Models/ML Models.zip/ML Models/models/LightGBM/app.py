# Update the HTML form to match the UI in the image
html_form = """
<!DOCTYPE html>
<html lang=\"en\">
<head>
  <meta charset=\"UTF-8\" />
  <title>Cricket Score Predictor</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 20px;
      background: #f9f9f9;
    }
    h1 {
      color: #2E86C1;
    }
    form {
      background: #fff;
      padding: 20px;
      border-radius: 8px;
      max-width: 500px;
      margin: auto;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }
    label {
      display: inline-block;
      width: 150px;
      margin-bottom: 10px;
    }
    select, input[type=\"text\"], input[type=\"number\"] {
      width: calc(100% - 160px);
      padding: 5px;
      margin-bottom: 10px;
    }
    button {
      padding: 10px 20px;
      background: #2E86C1;
      color: #fff;
      border: none;
      border-radius: 4px;
      cursor: pointer;
    }
    .result {
      background: #fff;
      max-width: 500px;
      margin: 20px auto;
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
      text-align: center;
    }
  </style>
</head>
<body>
  <h1>Cricket Score Predictor</h1>
  <form method=\"POST\" action=\"/\">
    <label for=\"batting_team\">Select batting team</label>
    <select name=\"batting_team\" id=\"batting_team\" required>
      <option value=\"\">--Select Batting Team--</option>
      <option value=\"New Zealand\">New Zealand</option>
      <option value=\"Bangladesh\">Bangladesh</option>
      <option value=\"India\">India</option>
      <option value=\"Australia\">Australia</option>
    </select><br/>

    <label for=\"bowling_team\">Select bowling team</label>
    <select name=\"bowling_team\" id=\"bowling_team\" required>
      <option value=\"\">--Select Bowling Team--</option>
      <option value=\"Bangladesh\">Bangladesh</option>
      <option value=\"New Zealand\">New Zealand</option>
      <option value=\"India\">India</option>
      <option value=\"Australia\">Australia</option>
    </select><br/>

    <label for=\"city\">Select city</label>
    <select name=\"city\" id=\"city\" required>
      <option value=\"\">--Select City--</option>
      <option value=\"Abu Dhabi\">Abu Dhabi</option>
      <option value=\"Dubai\">Dubai</option>
      <option value=\"Melbourne\">Melbourne</option>
    </select><br/>

    <label for=\"current_score\">Current Score</label>
    <input type=\"number\" name=\"current_score\" id=\"current_score\" min=\"0\" required /><br/>

    <label for=\"overs_done\">Overs Done (works for over > 5)</label>
    <input type=\"number\" name=\"overs_done\" id=\"overs_done\" min=\"0\" step=\"0.1\" required /><br/>

    <label for=\"wickets_out\">Wickets Out</label>
    <input type=\"number\" name=\"wickets_out\" id=\"wickets_out\" min=\"0\" max=\"10\" required /><br/>

    <label for=\"runs_in_last5\">Runs scored in last 5 overs</label>
    <input type=\"number\" name=\"runs_in_last5\" id=\"runs_in_last5\" min=\"0\" required /><br/>

    <button type=\"submit\">Predict Score</button>
  </form>
  {% if prediction %}
  <div class=\"result\">
    <h2>Predicted Final Score: {{ prediction }} runs</h2>
  </div>
  {% endif %}
</body>
</html>
"""

# Ensure the Flask route handles the form submission and prediction
@app.route("/", methods=["GET", "POST"])
def predict():
    if request.method == "POST":
        # Get data from form
        batting_team = request.form.get("batting_team")
        bowling_team = request.form.get("bowling_team")
        city = request.form.get("city")
        current_score = float(request.form.get("current_score"))
        overs_done = float(request.form.get("overs_done"))
        wickets_out = float(request.form.get("wickets_out"))
        runs_in_last5 = float(request.form.get("runs_in_last5"))

        # Prepare data for prediction
        data_dict = {
            "batting_team": [batting_team],
            "bowling_team": [bowling_team],
            "city": [city],
            "current_score": [current_score],
            "overs_done": [overs_done],
            "wickets_out": [wickets_out],
            "runs_in_last5": [runs_in_last5]
        }

        # Convert to DataFrame
        input_df = pd.DataFrame(data_dict)

        # Make prediction
        final_score_pred = lgb_model.predict(input_df)[0]

        # Round or format as needed
        final_score_pred = round(final_score_pred, 2)

        return render_template_string(html_form, prediction=final_score_pred)

    # If GET request, just show the form
    return render_template_string(html_form)